# README
# must ensure the JDK is in correct path

cp ../target/tailbaseSampling-1.0-SNAPSHOT.jar .
docker build -t registry.cn-shanghai.aliyuncs.com/huigan/laobing001:0.7 .