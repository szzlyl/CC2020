package com.alibaba.tailbase;

import com.alibaba.tailbase.backendprocess.BackendProcessData;
import com.alibaba.tailbase.clientprocess.ClientProcessData;
import com.alibaba.tailbase.utils.Utils;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@EnableAutoConfiguration
@ComponentScan(basePackages = "com.alibaba.tailbase")
public class MultiEntry {
    public static void main(String[] args) {
        if (Utils.isBackendProcess()) {
            BackendProcessData.init();
            BackendProcessData.start();
        }
        if (Utils.isClientProcess()) {
            ClientProcessData.init();
        }
        String port = System.getProperty("server.port", "8080");
        SpringApplication.run(MultiEntry.class,
                "--server.port=" + port
        );

    }


}
