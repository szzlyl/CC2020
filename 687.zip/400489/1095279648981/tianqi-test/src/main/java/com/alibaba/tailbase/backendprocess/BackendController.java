package com.alibaba.tailbase.backendprocess;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class BackendController {

    /**
     * receive error trace ID from client.
     *
     * @param traceIdListJson json
     * @param index thread index
     * @param batchPos batch position
     * @return wrong trace ids
     */
    @RequestMapping("/setWrongTraceId")
    public String setWrongTraceId(@RequestParam String traceIdListJson, @RequestParam int index, @RequestParam int batchPos) {
        return BackendProcessData.setWrongTraceId(traceIdListJson, index, batchPos);
    }

    /**
     * receive finish signal from Client.
     *
     * @param index thread index
     * @return is finished?
     */
    @RequestMapping("/finish")
    public String finish(@RequestParam int index) {
        return BackendProcessData.finish(index);
    }
}
