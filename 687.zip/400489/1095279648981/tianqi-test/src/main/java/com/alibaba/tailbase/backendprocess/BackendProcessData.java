package com.alibaba.tailbase.backendprocess;

import static com.alibaba.tailbase.Constants.CLIENT_PROCESS_PORT1;
import static com.alibaba.tailbase.Constants.CLIENT_PROCESS_PORT2;
import static com.alibaba.tailbase.Constants.PROCESS_COUNT;
import static com.alibaba.tailbase.Constants.PROCESS_THREAD_COUNT;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.tailbase.CommonController;
import com.alibaba.tailbase.Constants;
import com.alibaba.tailbase.utils.Utils;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import okhttp3.FormBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Class to process BE process.
 */
public class BackendProcessData implements Runnable {

    private static final Logger LOGGER = LoggerFactory.getLogger(BackendController.class.getName());

    private static AtomicInteger[] FINISH_PROCESS_COUNT = new AtomicInteger[PROCESS_THREAD_COUNT];

    private static AtomicInteger[] CURRENT_BATCH = new AtomicInteger[PROCESS_THREAD_COUNT];

    private static int BATCH_COUNT = 90;

    private static List<TraceIdBatch>[] ARRAY_OF_TRACE_ID_BATCH_LIST = new ArrayList[PROCESS_THREAD_COUNT];

    private static Map<String, String> TRACE_CHECKSUM_MAP = new ConcurrentHashMap<>();

    private int index = 0;

    private static AtomicInteger FINISH_COUNT = new AtomicInteger(0);

    public static void init() {
        for (int j = 0; j < PROCESS_THREAD_COUNT; j++) {
            FINISH_PROCESS_COUNT[j] = new AtomicInteger(0);
            CURRENT_BATCH[j] = new AtomicInteger(0);

            List<TraceIdBatch> TRACE_ID_BATCH_LIST = new ArrayList<>(BATCH_COUNT);
            for (int i = 0; i < BATCH_COUNT; i++) {
                TRACE_ID_BATCH_LIST.add(new TraceIdBatch());
            }
            ARRAY_OF_TRACE_ID_BATCH_LIST[j] = TRACE_ID_BATCH_LIST;
        }

    }

    /**
     * Start a backend process.
     *
     * @param index thread index
     */
    public BackendProcessData(int index) {
        this.index = index;
    }

    public static void start() {
        // using multiple thread to improve performance
        new Thread(new BackendProcessData(0), "BackendProcessThread1").start();
        new Thread(new BackendProcessData(1), "BackendProcessThread1").start();
    }

    @Override
    public void run() {
        TraceIdBatch traceIdBatch = null;
        String[] ports = new String[]{CLIENT_PROCESS_PORT1, CLIENT_PROCESS_PORT2};
        while (true) {
            try {
                traceIdBatch = getFinishedBatch();

                if (traceIdBatch == null) {
                    // send checksum when client process has all finished.
                    if (isFinished()) {
                        FINISH_COUNT.addAndGet(1);
                        if (FINISH_COUNT.get() >= PROCESS_THREAD_COUNT) {
                            if (sendCheckSum()) {
                                break;
                            }
                        } else {
                            break;
                        }
                    }
                    continue;
                }
                Map<String, Set<String>> map = new HashMap<>();
                // if (traceIdBatch.getTraceIdList().size() > 0) {
                int index = traceIdBatch.getIndex();
                int batchPos = traceIdBatch.getBatchPos();
                // to get all spans from remote
                for (String port : ports) {
                    Map<String, List<String>> processMap =
                            getWrongTrace(JSON.toJSONString(traceIdBatch.getTraceIdList()), port, index, batchPos);
                    if (processMap != null) {
                        for (Map.Entry<String, List<String>> entry : processMap.entrySet()) {
                            String traceId = entry.getKey();
                            // Because it is using Set, duplicate records are deleted.
                            map.computeIfAbsent(traceId, k -> new HashSet<>()).addAll(entry.getValue());
                        }
                    }
                }
//                    LOGGER.info("getWrong:" + batchPos + ", traceIdsize:" + traceIdBatch.getTraceIdList().size() + ",result:" + map.size());
                // }

                for (Map.Entry<String, Set<String>> entry : map.entrySet()) {
                    String traceId = entry.getKey();
                    Set<String> spanSet = entry.getValue();
                    // order span with startTime
                    String spans = spanSet.stream().sorted(
                            Comparator.comparing(BackendProcessData::getStartTime)).collect(Collectors.joining("\n"));
                    spans = spans + "\n";
                    // output all span to check
                    TRACE_CHECKSUM_MAP.put(traceId, Utils.MD5(spans));
                }
            } catch (Exception e) {
                // record batchPos when an exception  occurs.
                int index = 0;
                int batchPos = 0;
                if (traceIdBatch != null) {
                    index = traceIdBatch.getIndex();
                    batchPos = traceIdBatch.getBatchPos();
                }
                LOGGER.warn(String.format("fail to getWrongTrace, index:%d, batchPos:%d", index, batchPos), e);
            } finally {
                if (traceIdBatch == null) {
                    try {
                        Thread.sleep(100);
                    } catch (Throwable e) {
                        // quiet
                    }
                }
            }
        }
    }

    /**
     * Get wrong trace details from client.
     *
     * @param traceIdList list
     * @param port client port
     * @param index thread index
     * @param batchPos batch number
     * @return map of wrong traces
     */
    private Map<String, List<String>> getWrongTrace(@RequestParam String traceIdList, String port, int index, int batchPos) {
        try {
            RequestBody body = new FormBody.Builder()
                    .add("traceIdList", traceIdList)
                    .add("index", String.valueOf(index))
                    .add("batchPos", String.valueOf(batchPos)).build();
            String url = String.format("http://localhost:%s/getWrongTrace", port);
            Request request = new Request.Builder().url(url).post(body).build();
            Response response = Utils.callHttp(request);
            assert response.body() != null;
            Map<String, List<String>> resultMap = JSON.parseObject(response.body().string(),
                    new TypeReference<Map<String, List<String>>>() {
                    });
            response.close();
            return resultMap;
        } catch (Exception e) {
            LOGGER.warn("fail to getWrongTrace,batchPos:" + batchPos, e);
        }
        return null;
    }


    /**
     * send checksum MD5 to scoring server.
     *
     * @return
     */
    private boolean sendCheckSum() {
        try {
            String result = JSON.toJSONString(TRACE_CHECKSUM_MAP);
            RequestBody body = new FormBody.Builder()
                    .add("result", result).build();
            String url = String.format("http://localhost:%s/api/finished", CommonController.getDataSourcePort());
            Request request = new Request.Builder().url(url).post(body).build();
            Response response = Utils.callHttp(request);
            if (response.isSuccessful()) {
                response.close();
                LOGGER.warn("suc to sendCheckSum");
                return true;
            }
            LOGGER.warn("fail to sendCheckSum:" + response.message());
            response.close();
            return false;
        } catch (Exception e) {
            LOGGER.warn("fail to call finish", e);
        }
        return false;
    }

    public static long getStartTime(String span) {
        if (span != null) {
            String[] cols = span.split("\\|");
            if (cols.length > 8) {
                return Utils.toLong(cols[1], -1);
            }
        }
        return -1;
    }

    /**
     * is the whole batch finished.
     *
     * @return is finished?
     */
    public boolean isFinished() {
        List<TraceIdBatch> TRACE_ID_BATCH_LIST = ARRAY_OF_TRACE_ID_BATCH_LIST[index];
        for (int i = 0; i < BATCH_COUNT; i++) {
            TraceIdBatch currentBatch = TRACE_ID_BATCH_LIST.get(i);
            if (currentBatch.getBatchPos() != 0) {
                return false;
            }
        }
        return FINISH_PROCESS_COUNT[index].get() >= Constants.PROCESS_COUNT;
    }


    /**
     * Calculate if a batch is finished.
     *
     * @return batch
     */
    public TraceIdBatch getFinishedBatch() {
        int next = CURRENT_BATCH[index].get() + 1;
        if (next >= BATCH_COUNT) {
            next = 0;
        }
        List<TraceIdBatch> TRACE_ID_BATCH_LIST = ARRAY_OF_TRACE_ID_BATCH_LIST[index];
        TraceIdBatch nextBatch = TRACE_ID_BATCH_LIST.get(next);
        TraceIdBatch currentBatch = TRACE_ID_BATCH_LIST.get(CURRENT_BATCH[index].get());

        // when client process is finished, or then next trace batch is finished. to get checksum for wrong traces.
        boolean cond1 = FINISH_PROCESS_COUNT[index].get() >= PROCESS_COUNT && currentBatch.getBatchPos() > 0;
        boolean cond2 = currentBatch.getProcessCount() >= PROCESS_COUNT && nextBatch.getProcessCount() >= PROCESS_COUNT;
        if (cond1 || cond2) {
            TraceIdBatch newTraceIdBatch = new TraceIdBatch();
            TRACE_ID_BATCH_LIST.set(CURRENT_BATCH[index].get(), newTraceIdBatch);
            CURRENT_BATCH[index].set(next);
            return currentBatch;
        }
        return null;
    }

    /**
     * Receive error trace ID.
     *
     * @param traceIdListJson trace id
     * @param index thread index
     * @param batchPos batch number
     * @return trace ids
     */
    public static String setWrongTraceId(@RequestParam String traceIdListJson, @RequestParam int index, @RequestParam int batchPos) {
        int pos = batchPos % BATCH_COUNT;
        List<String> traceIdList = JSON.parseObject(traceIdListJson, new TypeReference<List<String>>() {
        });
        LOGGER.info(String.format("setWrongTraceId had called, index:%d, batchPos:%d", index, batchPos));
        List<TraceIdBatch> TRACE_ID_BATCH_LIST = ARRAY_OF_TRACE_ID_BATCH_LIST[index];
        TraceIdBatch traceIdBatch = TRACE_ID_BATCH_LIST.get(pos);

        // 不能有 traceIdList.size() > 0
        if (traceIdList != null) {
            traceIdBatch.setIndex(index);
            traceIdBatch.setBatchPos(batchPos);
            traceIdBatch.setProcessCount(traceIdBatch.getProcessCount() + 1);
            traceIdBatch.getTraceIdList().addAll(traceIdList);
        }
        return "suc";
    }

    public static String finish(@RequestParam int index) {
        FINISH_PROCESS_COUNT[index].addAndGet(1);
        LOGGER.warn("receive call 'finish', count:" + FINISH_PROCESS_COUNT[index]);
        return "suc";
    }
}
