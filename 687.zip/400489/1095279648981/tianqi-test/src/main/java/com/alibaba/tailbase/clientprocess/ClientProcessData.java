package com.alibaba.tailbase.clientprocess;

import static com.alibaba.tailbase.Constants.BATCH_SIZE;
import static com.alibaba.tailbase.Constants.PROCESS_THREAD_COUNT;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.tailbase.CommonController;
import com.alibaba.tailbase.Constants;
import com.alibaba.tailbase.utils.Utils;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import okhttp3.FormBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ClientProcessData implements Runnable {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClientProcessData.class.getName());

    private static List<Map<String, List<String>>>[] ARRAY_OF_BATCH_TRACE_LIST = new ArrayList[PROCESS_THREAD_COUNT];

    private static int BATCH_COUNT = 20;

    private int index = 0;
    private long start = 0;
    private long end = 0;
    private String path = null;

    /**
     * initial all stuff.
     */
    public static void init() {
        for (int j = 0; j < PROCESS_THREAD_COUNT; j++) {
            List<Map<String, List<String>>> BATCH_TRACE_LIST = new ArrayList<>(BATCH_COUNT);
            for (int i = 0; i < BATCH_COUNT; i++) {
                BATCH_TRACE_LIST.add(new ConcurrentHashMap<>(BATCH_SIZE));
            }
            ARRAY_OF_BATCH_TRACE_LIST[j] = BATCH_TRACE_LIST;
        }
    }

    public ClientProcessData(String path, int index, long start, long end) {
        this.path = path;
        this.index = index;
        this.start = start;
        this.end = end;
    }

    public static void start() {
        Response response = null;
        try {
            // handle multiple threads
            String path = getPath();

            Request request = new Request.Builder().url(path).head().build();
            response = Utils.callHttp(request);
            long length = Utils.toLong(response.header("content-length"), 0);
            // assume per line max length is 500
            int redundancy = 1024 * 1024 * 16; //BATCH_SIZE * 500; //
            long half = length / PROCESS_THREAD_COUNT;

            //TODO: using for loop to start multiple thread, according to number of CPU
            new Thread(new ClientProcessData(path, 0, 0, half + redundancy), "ProcessDataThread1").start();
            new Thread(new ClientProcessData(path, 1, half - redundancy, length - 1), "ProcessDataThread2").start();

        } catch (Exception e) {
            LOGGER.warn("fail to process data", e);
        } finally {
            if (response != null) {
                response.close();
            }
        }
    }

    /**
     * Get wrong tracing.
     * @param wrongTraceIdList wrong id list
     * @param index thread index
     * @param batchPos batch number
     * @return a list of details
     */
    public static String getWrongTracing(String wrongTraceIdList, int index, int batchPos) {
//        LOGGER.info(String.format("getWrongTracing, index:%d, batchPos:%d, wrongTraceIdList:\n %s",
//                index, batchPos, wrongTraceIdList));
        List<String> traceIdList = JSON.parseObject(wrongTraceIdList, new TypeReference<List<String>>() {
        });
        Map<String, List<String>> wrongTraceMap = new HashMap<>();
        int pos = batchPos % BATCH_COUNT;
        int previous = pos - 1;
        if (previous == -1) {
            previous = BATCH_COUNT - 1;
        }
        int next = pos + 1;
        if (next == BATCH_COUNT) {
            next = 0;
        }
        List<Map<String, List<String>>> BATCH_TRACE_LIST = ARRAY_OF_BATCH_TRACE_LIST[index];
        getWrongTraceWithBatch(BATCH_TRACE_LIST, previous, traceIdList, wrongTraceMap);
        getWrongTraceWithBatch(BATCH_TRACE_LIST, pos, traceIdList, wrongTraceMap);
        getWrongTraceWithBatch(BATCH_TRACE_LIST, next, traceIdList, wrongTraceMap);
        // to clear spans, don't block client process thread.// TODO to use lock/notify
        BATCH_TRACE_LIST.get(previous).clear();

//        LOGGER.info("getWrongTrace, batchPos:" + batchPos);
        return JSON.toJSONString(wrongTraceMap);
    }

    /**
     * Get wrong trace by batch.
     * @param batchTraceList List of trace
     * @param batchPos batch number
     * @param traceIdList trace id list
     * @param wrongTraceMap wrong trace in a map
     */
    private static void getWrongTraceWithBatch(List<Map<String, List<String>>> batchTraceList, int batchPos, List<String> traceIdList, Map<String, List<String>> wrongTraceMap) {
        // donot lock traceMap,  traceMap may be clear anytime.
        Map<String, List<String>> traceMap = batchTraceList.get(batchPos);
        for (String traceId : traceIdList) {
            List<String> spanList = traceMap.get(traceId);
            if (spanList != null) {
                // one trace may cross to batch (e.g batch size 20000, span1 in line 19999, span2 in line 20001)
                List<String> existSpanList = wrongTraceMap.get(traceId);
                if (existSpanList != null) {
                    existSpanList.addAll(spanList);
                } else {
                    wrongTraceMap.put(traceId, spanList);
                }
            }
        }
    }

    @Override
    public void run() {
        try {

            URL url = new URL(path);
            LOGGER.info("data path:" + path);
            HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY);

            // Using Range header to download the data file in 2 pieces and using 2 thread to process

            httpConnection.setRequestProperty("Range", "bytes=" + start + "-" + end);
            InputStream input = httpConnection.getInputStream();

            BufferedReader bf = new BufferedReader(new InputStreamReader(input));
            String line;
            long count = 0;
            int pos = 0;
            Set<String> badTraceIdList = new HashSet<>(1000);
            List<Map<String, List<String>>> BATCH_TRACE_LIST = ARRAY_OF_BATCH_TRACE_LIST[index];
            Map<String, List<String>> traceMap = BATCH_TRACE_LIST.get(pos);
            while ((line = bf.readLine()) != null) {
                count++;

                int firstPos = line.indexOf("|");
                if (firstPos > 0) {
                    String traceId = line.substring(0, firstPos);
                    traceMap.computeIfAbsent(traceId, k -> new ArrayList<>()).add(line);


                    if (hasError(line)) {
                        badTraceIdList.add(traceId);
                    }
                }

                if (count % BATCH_SIZE == 0) {
                    pos++;
                    // loop cycle
                    if (pos >= BATCH_COUNT) {
                        pos = 0;
                    }
                    traceMap = BATCH_TRACE_LIST.get(pos);
                    // donot produce data, wait backend to consume data
                    // TODO to use lock/notify
                    if (traceMap.size() > 0) {
                        LOGGER.warn("wait BE consume data...");
//                        ARRAY_OF_BATCH_TRACE_LIST[index].wait();
                        while (true) {
                            Thread.sleep(10);
                            if (traceMap.size() == 0) {
                                break;
                            }
                        }
                    }
                    // batchPos begin from 0, so need to minus 1
                    int batchPos = (int) count / BATCH_SIZE - 1;

                    final Set<String> badTraceIdList0 = badTraceIdList;
                    final int index0 = index;
                    final int batchPos0 = batchPos;
                    Thread t = new Thread() {
                        @Override
                        public void run() {
                            updateWrongTraceId(badTraceIdList0, index0, batchPos0);
                        }
                    };
                    t.start();
                    badTraceIdList = new HashSet<>(1000);
                    LOGGER.info("suc to updateBadTraceId, batchPos:" + batchPos);
                }
            }
            updateWrongTraceId(badTraceIdList, index, (int) (count / BATCH_SIZE - 1));
            bf.close();
            input.close();
        } catch (Exception e) {
            LOGGER.warn("fail to process data", e);
        } finally {
            callFinish();
        }
    }

    /**
     * check if a line of log has error, using byte to compare.
     *
     * @param line line of log
     * @return if has error
     */
    private static boolean hasError(String line) {
        byte[] d = line.getBytes();
        int i = 18; // no need to start from beginning
        boolean hasError = false;

        while (++i < d.length) {
            if (d[i] == '=') {
                if (i < 6) { // prevent Index problem
                    break;
                }
                if (d[i - 5] == '_') {
                    if (d[i + 1] != '2') {
                        hasError = true;
                    }
                    break;
                } else if (d[i - 6] == '&' || d[i - 6] == '|') {
                    if (d[i + 1] == '1') {
                        hasError = true;
                    }
                    break;
                }
            }
        }
        return hasError;
    }

    /**
     * call backend controller to update wrong tradeId list.
     *
     * @param badTraceIdSet batchPos批次的所有wrongTraceId
     * @param index         Thread index
     * @param batchPos batch number
     */
    private void updateWrongTraceId(Set<String> badTraceIdSet, int index, int batchPos) {
        String json = JSON.toJSONString(badTraceIdSet);
        // 无论List是否为空都必须发起一次Request，因为Backend需要统计操作次数
        try {
            LOGGER.info("updateBadTraceId, index:" + index + ", batchPos:" + batchPos);
            RequestBody body = new FormBody.Builder()
                    .add("traceIdListJson", json)
                    .add("index", String.valueOf(index))
                    .add("batchPos", String.valueOf(batchPos)).build();
            Request request = new Request.Builder().url("http://localhost:8002/setWrongTraceId").post(body).build();
            Response response = Utils.callHttp(request);
            response.close();
        } catch (Exception e) {
            LOGGER.warn("fail to updateBadTraceId, json:" + json + ", batch:" + batchPos);
        }
    }


    /**
     * notify backend process when client process has finished.
     */
    private void callFinish() {
        try {
            RequestBody body = new FormBody.Builder()
                    .add("index", String.valueOf(index)).build();
            Request request = new Request.Builder().url("http://localhost:8002/finish").post(body).build();
            Response response = Utils.callHttp(request);
            response.close();
        } catch (Exception e) {
            LOGGER.warn("fail to callFinish");
        }
    }

    /**
     * Get data from backend.
     * (8000 => trace1.data)
     * (8001 => trace2.data)
     * @return path of data file
     */
    private static String getPath() {

        String port = System.getProperty("server.port", "8080");
        if (Constants.CLIENT_PROCESS_PORT1.equals(port)) {
            return "http://localhost:" + CommonController.getDataSourcePort() + "/trace1.data";
        } else if (Constants.CLIENT_PROCESS_PORT2.equals(port)) {
            return "http://localhost:" + CommonController.getDataSourcePort() + "/trace2.data";
        } else {
            return null;
        }
    }

    /**
     * Debug locally, can host with http-server by node.js.
     * @return path of data file
     */
    private static String getPathNative() {
        String port = System.getProperty("server.port", "8080");
        if (Constants.CLIENT_PROCESS_PORT1.equals(port)) {
            return "http://localhost:8080/trace1.data";
        } else if (Constants.CLIENT_PROCESS_PORT2.equals(port)) {
            return "http://localhost:8080/trace2.data";
        } else {
            return "http://localhost:8080/trace1.data";
        }
    }

    /**
     * Debug locally, can host with http-server by node.js.
     * @return path of data file
     */
    private static String getPath8002() {
        String port = System.getProperty("server.port", "8080");
        if (Constants.CLIENT_PROCESS_PORT1.equals(port)) {
            return "http://localhost:8002/trace1.data";
        } else if (Constants.CLIENT_PROCESS_PORT2.equals(port)) {
            return "http://localhost:8002/trace2.data";
        } else {
            return null;
        }
    }

}
