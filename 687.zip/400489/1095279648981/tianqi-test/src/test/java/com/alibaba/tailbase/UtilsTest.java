package com.alibaba.tailbase;

import com.alibaba.tailbase.utils.Utils;
import org.junit.Assert;
import org.junit.Test;

import static org.hamcrest.core.Is.is;

public class UtilsTest {

    @Test
    public void callHttp() {
    }

    @Test
    public void isClientProcess() {
        Assert.assertThat(Utils.isClientProcess(), is(equals(false)));
    }

    @Test
    public void isBackendProcess() {
        Assert.assertThat(Utils.isBackendProcess(), is(equals(false)));
    }
}