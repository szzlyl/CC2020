package com.alibaba.tailbase.utils;

import org.junit.Assert;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

public class MD5Test {

    @Test
    public void update() {
        MD5 md5 = new MD5();
        byte bs[] = new byte[]{'a', 'b', 'c', 'd', 'e'};
        md5.update(bs, 1, 3);
        byte result[] = new byte[32];
        md5.digest(result, 0);
        String hash = new String(result);
        Assert.assertEquals(hash, "D4B7C284882CA9E208BB65E8ABD5F4C8");
    }
}