# Tail Base Sampling

## 团队

Ray Y Z HONG, Thomas Y J SHAO, Amos Q X LI


## 说明

### 多线程

因为服务器多核，把下载文件分成两个线程，分别下载一半的文件，即是分块下载，同时允许在切割位有一定的冗余

### 出错检查

使用byte[]计算以提高速度

### 待改进

可使用TCP, Socket连接Client和Host，避免多次握手，提高速度

## 代码质量

使用Checkstyle插件来保证 Google coding style


## 整体流程交互
本demo主要是用于演示数据交互过程，性能很一般，仅供各选手参考
![enter image description here](https://tianchi-public.oss-cn-hangzhou.aliyuncs.com/public/files/forum/158937741003137571589377409737.png)
