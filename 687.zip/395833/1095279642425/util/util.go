package util

import (
	"bytes"
	"fmt"
	"github.com/valyala/fasthttp"
	"os"
	"tailsampling/config"
	"time"
)

type Duration int64

const (
	Nanosecond  Duration = 1
	Microsecond          = 1000 * Nanosecond
	Millisecond          = 1000 * Microsecond
	Second               = 1000 * Millisecond
	Minute               = 60 * Second
	Hour                 = 60 * Minute
)

var (
	c = &fasthttp.Client{
		MaxConnsPerHost:     10000,
		MaxIdleConnDuration: 5 * time.Second,
		ReadTimeout:         500 * time.Millisecond,
		WriteTimeout:        500 * time.Millisecond,
	}
)

func RemoveDuplicateValues(intSlice []string) []string {
	keys := make(map[string]bool)
	var list []string

	// If the key(values of the slice) is not equal
	// to the already present value in new slice (list)
	// then we append it. else we jump on another element.
	for _, entry := range intSlice {
		if _, value := keys[entry]; !value {
			keys[entry] = true
			list = append(list, entry)
		}
	}
	return list
}

func CheckSpanIfError(line []byte) bool {
	lastIndexOfSEq := -1
	nextStartPoint := 0
	for {
		lastIndexOfSEq = bytes.IndexByte(line[nextStartPoint:], byte('='))
		//fmt.Println(lastIndexOfSEq)
		if lastIndexOfSEq == -1 {
			return false
		}
		oLastIndexOfSEq := nextStartPoint + lastIndexOfSEq
		nextStartPoint = oLastIndexOfSEq + 1
		// check: http.status_code= and http.status_code=200
		if line[oLastIndexOfSEq-16] == 'h' && line[oLastIndexOfSEq-15] == 't' && line[oLastIndexOfSEq-14] == 't' && line[oLastIndexOfSEq-13] == 'p' && line[oLastIndexOfSEq-12] == '.' && line[oLastIndexOfSEq-11] == 's' && line[oLastIndexOfSEq-10] == 't' && line[oLastIndexOfSEq-9] == 'a' && line[oLastIndexOfSEq-8] == 't' && line[oLastIndexOfSEq-7] == 'u' && line[oLastIndexOfSEq-6] == 's' {
			//str2 := string(line[oLastIndexOfSEq-16:oLastIndexOfSEq+4])
			//fmt.Println("msg: " + str2)
			if line[oLastIndexOfSEq+1] == '2' && line[oLastIndexOfSEq+2] == '0' && line[oLastIndexOfSEq+3] == '0' {
				continue
			}
			return true
		}
		// check error=1
		if line[oLastIndexOfSEq-5] == 'e' && line[oLastIndexOfSEq-4] == 'r' && line[oLastIndexOfSEq-3] == 'r' && line[oLastIndexOfSEq-2] == 'o' && line[oLastIndexOfSEq-1] == 'r' && line[oLastIndexOfSEq+1] == '1' {
			//str2 := string(line[oLastIndexOfSEq-5:oLastIndexOfSEq+2])
			//fmt.Println("msg: " + str2)
			return true
		}
	}

}

//func WarmUp(port string, wg sync.WaitGroup) {
//	wg.Add(1)
//	defer wg.Done()
//	notifyUrl := fmt.Sprintf("http://127.0.0.1:%s/warmup", port)
//
//	req := fasthttp.AcquireRequest()
//	defer fasthttp.ReleaseRequest(req)
//
//	req.SetRequestURI(notifyUrl)
//	req.Header.SetMethod("GET")
//
//	resp := fasthttp.AcquireResponse()
//	defer fasthttp.ReleaseResponse(resp)
//
//	if err := c.Do(req, resp); err != nil {
//		return
//	}
//	if resp.StatusCode() != fasthttp.StatusOK {
//		return
//	}
//}

func WarmUp(port string) bool {
	notifyUrl := fmt.Sprintf("http://127.0.0.1:%s/warmup", port)

	req := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(req)

	req.SetRequestURI(notifyUrl)
	req.Header.SetMethod("GET")

	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)

	if err := c.Do(req, resp); err != nil {
		return false
	}
	if resp.StatusCode() != fasthttp.StatusOK {
		return false
	}
	return true
}

func FindNextBatchPos(currentBatchId int, bucketNumber int) int {
	next := currentBatchId + 1
	if next >= bucketNumber {
		next = 0
	}
	return next
}

func FindPreviousBatchPos(currentBatchId int, bucketNumber int) int {
	prePos := currentBatchId - 1
	if prePos < 0 {
		prePos = bucketNumber - 1
	}
	return prePos
}

func GetUrl() string {
	var dataUrl = os.Getenv("dataUrl")
	var port = os.Getenv("port")
	if dataUrl == "" {
		if port == config.CLIENT_PROCESS_PORT1 {
			return "http://localhost:" + config.DataSourcePort + "/trace1.data"
		}
		if port == config.CLIENT_PROCESS_PORT2 {
			return "http://localhost:" + config.DataSourcePort + "/trace2.data"
		}
	} else {
		if port == config.CLIENT_PROCESS_PORT1 {
			return dataUrl + "trace1.data"
		}
		if port == config.CLIENT_PROCESS_PORT2 {
			return dataUrl + "trace2.data"
		}
		return ""
	}

	return ""
}
