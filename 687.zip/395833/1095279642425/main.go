package main

import (
	"fmt"
	"log"
	"net/http"
	"os"
	"tailsampling/backendprocess"
	"tailsampling/clientprocess"
	"tailsampling/config"
	"tailsampling/util"
	"time"
)

var (
	port = os.Getenv("port")
)

func main() {
	if port == config.CLIENT_PROCESS_PORT1 || port == config.CLIENT_PROCESS_PORT2 {
		clientprocess.Init()
	} else {
		backendprocess.Init()
	}

	//http.HandleFunc("/ready", func(writer http.ResponseWriter, request *http.Request) {
	//	btime := time.Now()
	//	wg := sync.WaitGroup{}
	//
	//	for i := 0; i < 500; i++ {
	//		go util.WarmUp("8000", wg)
	//	}
	//	for i := 0; i < 500; i++ {
	//		go util.WarmUp("8001", wg)
	//	}
	//	wg.Wait()
	//	log.Printf("ReadyHandler done on port: %s, cost: %s", port, time.Since(btime))
	//
	//})

	http.HandleFunc("/ready", func(writer http.ResponseWriter, request *http.Request) {
		btime := time.Now()
		allok := false
		i := 0
		for {
			i++
			if util.WarmUp("8000") && util.WarmUp("8001") && util.WarmUp("8002") {
				allok = true
				break
			}
			if i > 10 {
				break
			}
		}

		if allok {
			log.Printf("ReadyHandler done on port: %s, cost: %s", port, time.Since(btime))
		} else {
			writer.WriteHeader(403)
		}
	})

	http.HandleFunc("/warmup", func(writer http.ResponseWriter, request *http.Request) {
		time.Sleep(1 * time.Millisecond)
	})

	http.HandleFunc("/setParameter", func(writer http.ResponseWriter, request *http.Request) {
		log.Printf("setParameter at %s", time.Now())
		config.DataSourcePort = request.URL.Query().Get("port")
		if port == config.CLIENT_PROCESS_PORT1 || port == config.CLIENT_PROCESS_PORT2 {
			go clientprocess.ProcessSpan()
		}
	})
	log.Printf("SERVICE START on %s", port)

	err := http.ListenAndServe(":"+port, nil)
	if err != nil {
		fmt.Println(err)
		return
	}
}
