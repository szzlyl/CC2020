package backendprocess

import (
	"testing"
)

func Test_sendCheckSum(t *testing.T) {
	tests := []struct {
		name string
		want bool
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := sendCheckSum(); got != tt.want {
				t.Errorf("sendCheckSum() = %v, want %v", got, tt.want)
			}
		})
	}

}
