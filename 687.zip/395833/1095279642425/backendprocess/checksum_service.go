package backendprocess

import (
	"bytes"
	"crypto/md5"
	"encoding/hex"
	"encoding/json"
	"io/ioutil"
	"net/http"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"sync"
	"tailsampling/config"
	"tailsampling/entity"
	"tailsampling/util"
)

func run() {
	ports := []string{config.CLIENT_PROCESS_PORT1, config.CLIENT_PROCESS_PORT2}
	var traceIdBatch *TraceIdBatch
	for {
		if !READY {
			continue
		}
		traceIdBatch = getFinishedBatch()
		if traceIdBatch == nil {
			if isFinish() {
				if sendCheckSum() {
					break
				}
			}
			continue
		}

		errorIdList := util.RemoveDuplicateValues(traceIdBatch.traceIdList)
		data := make(map[string]map[string]bool)

		var wg sync.WaitGroup
		var mux sync.Mutex
		wg.Add(config.PROCESS_COUNT)

		for i := range ports {
			port := ports[i]
			go func() {
				processData := getWrongTrace(errorIdList, port, traceIdBatch.batchId)
				mux.Lock()
				for key, value := range processData {
					if _, ok := data[key]; !ok {
						data[key] = make(map[string]bool)
					}
					for i := range value {
						v := value[i]
						if _, ok := data[key][v]; !ok {
							data[key][v] = true
						}
					}
				}
				mux.Unlock()
				wg.Done()
			}()
		}
		wg.Wait()

		spanDataList := make([]string, 0, 256)
		for traceId, spanData := range data {
			for k, _ := range spanData {
				spanDataList = append(spanDataList, k)
			}
			sort.SliceStable(spanDataList, func(i, j int) bool {
				return getStartTime(spanDataList[i]) < getStartTime(spanDataList[j])
			})
			spans := strings.Join(spanDataList, "\n") + "\n"
			spansBytes := md5.Sum([]byte(spans))
			TRACE_CHUCKSUM_MAP[traceId] = strings.ToUpper(hex.EncodeToString(spansBytes[:]))

			spanDataList = make([]string, 0, 256)
		}

		CURRENT_BATCH++
	}
}

func getWrongTrace(traceIdList []string, port string, batchPos int) map[string][]string {
	data, _ := json.Marshal(entity.WrongTrace{traceIdList, batchPos})
	response, _ := http.Post("http://localhost:"+port+"/getWrongTrace", "application/json", bytes.NewBuffer(data))

	var result map[string][]string
	body, _ := ioutil.ReadAll(response.Body)
	_ = json.Unmarshal(body, &result)
	return result
}

func sendCheckSum() bool {
	result, _ := json.Marshal(TRACE_CHUCKSUM_MAP)
	response, err := http.PostForm("http://localhost:"+config.DataSourcePort+"/api/finished", url.Values{
		"result": []string{string(result)},
	})
	if err != nil {
		return false
	}
	if response.StatusCode != 200 {
		return false
	}
	return true
}

func getStartTime(spanData string) int64 {
	startIndex := 0
	matchCount := 0
	for i := range spanData {
		if spanData[i] == config.SEPERACTOR {
			if matchCount == 0 {
				startIndex = i + 1
			}
			if matchCount == 1 {
				startTime, _ := strconv.ParseInt(spanData[startIndex:i], 10, 64)
				return startTime
			}
			matchCount++
		}
	}
	return -1
}
