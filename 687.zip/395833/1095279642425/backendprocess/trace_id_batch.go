package backendprocess

import "sync"

type TraceIdBatch struct {
	batchId      int
	processCount int32
	traceIdList  []string
	mux          sync.Mutex
}
