package backendprocess

import (
	"encoding/json"
	"io/ioutil"
	"log"
	"net/http"
	"sync/atomic"
	"tailsampling/config"
	"tailsampling/entity"
)

var (
	// FINISH_PROCESS_COUNT will add one, when process call finish();
	FINISH_PROCESS_COUNT int32 = 0

	//indicator for ready for backend get wrong trace from frontend
	READY = false

	CURRENT_BATCH = 0

	TRACEID_BATCH_LIST []*TraceIdBatch
	TRACE_CHUCKSUM_MAP map[string]string
)

func Init() {
	TRACEID_BATCH_LIST = make([]*TraceIdBatch, 0, config.TRACE_MAP_BUCKET_NUMBER)
	TRACE_CHUCKSUM_MAP = make(map[string]string)

	for i := 0; i < config.TRACE_MAP_BUCKET_NUMBER; i++ {
		traceIdBatch := &TraceIdBatch{
			batchId:      -1,
			processCount: 0,
			traceIdList:  make([]string, 0, config.MAX_ERROR_PER_BATCH),
		}
		TRACEID_BATCH_LIST = append(TRACEID_BATCH_LIST, traceIdBatch)
	}

	http.HandleFunc("/setWrongTraceId", setWrongTraceId)

	http.HandleFunc("/finish", finish)

	go run()
}

func finish(writer http.ResponseWriter, request *http.Request) {
	log.Println("Receive finish")
	atomic.AddInt32(&FINISH_PROCESS_COUNT, 1)
}

func setWrongTraceId(writer http.ResponseWriter, request *http.Request) {
	body, _ := ioutil.ReadAll(request.Body)

	var wrongTrace entity.WrongTrace
	_ = json.Unmarshal(body, &wrongTrace)

	if wrongTrace.BatchId < 0 {
		return
	}

	batchPos := wrongTrace.BatchId % config.TRACE_MAP_BUCKET_NUMBER

	traceIdBatch := TRACEID_BATCH_LIST[batchPos]
	traceIdBatch.batchId = wrongTrace.BatchId
	atomic.AddInt32(&traceIdBatch.processCount, 1)

	list := &traceIdBatch.traceIdList

	traceIdBatch.mux.Lock()
	*list = append(*list, wrongTrace.TraceIdList...)
	traceIdBatch.mux.Unlock()

	if batchPos == 1 && traceIdBatch.processCount >= 2 {
		READY = true
	}
}

func getFinishedBatch() *TraceIdBatch {
	current := CURRENT_BATCH % config.TRACE_MAP_BUCKET_NUMBER
	next := current + 1
	if next >= config.TRACE_MAP_BUCKET_NUMBER {
		next = 0
	}
	currentBucket := TRACEID_BATCH_LIST[current]
	nextBucket := TRACEID_BATCH_LIST[next]
	if FINISH_PROCESS_COUNT >= config.PROCESS_COUNT && currentBucket.batchId >= 0 ||
		nextBucket.processCount >= config.PROCESS_COUNT && currentBucket.processCount >= config.PROCESS_COUNT {
		TRACEID_BATCH_LIST[current] = &TraceIdBatch{
			batchId:      -1,
			processCount: 0,
			traceIdList:  make([]string, 0, config.MAX_ERROR_PER_BATCH),
		}
		return currentBucket
	}

	return nil
}

func isFinish() bool {
	if FINISH_PROCESS_COUNT < config.PROCESS_COUNT {
		return false
	}

	for i := range TRACEID_BATCH_LIST {
		if TRACEID_BATCH_LIST[i].batchId != -1 {
			return false
		}
	}

	return true
}
