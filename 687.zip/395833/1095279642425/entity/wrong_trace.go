package entity

//backend send the wrong trace id for one batch
type WrongTrace struct {
	TraceIdList []string
	BatchId     int
}
