#!/bin/bash

if   [  $SERVER_PORT  ];
then
   port=$SERVER_PORT tailsampling &
else
   port=8000 tailsampling &
fi

tail -f startup.sh