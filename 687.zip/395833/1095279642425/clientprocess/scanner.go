package clientprocess

import (
	"bytes"
	"github.com/valyala/fasthttp"
	"log"
	"net/http"
	"os"
	"strconv"
	"sync"
	"tailsampling/util"
	"time"
)

const DefaultRoutineNum = 1
const DefaultDownloadBlockSize = 1024 * 1024 * 10

type SpanGet struct {
	url           string
	blockSize     int64
	routineNum    int
	GetClient     *http.Client
	isFinished    bool
	contentLength int64
	WG            sync.WaitGroup
}

type Span struct {
	batchId             int
	routineId           int
	rowId               int
	traceIdUint64       uint64
	traceId             string
	startTime           uint64
	traceIdSeparatorPos int
	spanBytes           []byte
	hasError            bool
	isFullSpan          bool
}

func check(e error) {
	if e != nil {
		panic(e)
	}
}

func getenv(key, fallback string) string {
	value := os.Getenv(key)
	if len(value) == 0 {
		return fallback
	}
	return value
}

func timeTrack(start time.Time, name string) {
	elapsed := time.Since(start)
	log.Printf("%s took %s", name, elapsed)
}

func Scan(dataFile string) {
	defer timeTrack(time.Now(), "All")

	//dataFile := os.Args[1]
	log.Printf("scan file %s\n", dataFile)

	spanGet := new(SpanGet)
	spanGet.GetClient = new(http.Client)
	blockSize, _ := strconv.Atoi(getenv("DownloadBlockSize", strconv.Itoa(DefaultDownloadBlockSize)))
	spanGet.blockSize = int64(blockSize)
	routineNum, _ := strconv.Atoi(getenv("DefaultRoutineNum", strconv.Itoa(DefaultRoutineNum)))
	spanGet.routineNum = routineNum
	spanGet.url = dataFile

	spanGet.initDataFileSize(dataFile)
	log.Printf("data file size: %d\n", spanGet.contentLength)

	for batchId := 0; !spanGet.isFinished; batchId++ {
		spanGet.batchPullSpan(batchId)
		//log.Print("sleep 300ms")
		//time.Sleep(time.Duration(500)*time.Millisecond)
	}

	log.Print("all batch completed")
	callFinish()
}

func (spanGet *SpanGet) initDataFileSize(url string) {
	req, err := http.NewRequest("GET", url, nil)
	req.Header.Set("Range", "bytes=0-")
	//req.Header.Set("Keep-Alive", "timeout=1000, max=1000")
	resp, err := spanGet.GetClient.Do(req)
	defer resp.Body.Close()
	dataFileSize := int64(0)
	if err != nil {
		log.Printf("Get data file size error %s\n", err)
	} else {
		dataFileSize = resp.ContentLength
	}
	spanGet.contentLength = dataFileSize
}

func (spanGet *SpanGet) batchPullSpan(batchId int) {
	for rid := 0; rid < spanGet.routineNum; rid++ {
		offsetSize := int64(spanGet.routineNum) * spanGet.blockSize * int64(batchId)
		if spanGet.isFinished {
			break
		}
		rangeStart := offsetSize + int64(rid)*spanGet.blockSize
		rangeEnd := offsetSize + spanGet.blockSize*(int64(rid)+1) - 1
		// Validate the range
		if rangeStart > spanGet.contentLength+1 {
			spanGet.isFinished = true
			continue
		}
		if rangeEnd > spanGet.contentLength {
			rangeEnd = spanGet.contentLength
		}
		spanGet.WG.Add(1)
		//log.Printf("BID[%d] RID[%d] - Start download range from %d to %d", batchId, rid, rangeStart, rangeEnd)
		go spanGet.download(batchId, rid, rangeStart, rangeEnd)

	}
	spanGet.WG.Wait()
}

func (spanGet *SpanGet) download(batchId int, routineId int, start int64, end int64) {
	//defer timeTrack(time.Now(), "Download data part and check")
	if start > end {
		return
	}
	req := fasthttp.AcquireRequest()
	resp := fasthttp.AcquireResponse()
	defer func() {
		fasthttp.ReleaseResponse(resp)
		fasthttp.ReleaseRequest(req)
	}()
	req.SetRequestURI(spanGet.url)
	req.Header.SetByteRange(int(start), int(end))
	req.Header.SetMethod("GET")

	err := fasthttp.DoTimeout(req, resp, 300*time.Second)
	if err != nil {
		log.Printf("BID[%d] RID[%d] - Download error %v.\n", batchId, routineId, err)
	} else {
		bodyBytes := resp.Body()
		rowId := 0
		spanList := make([]Span, 200000)
		//spanList := []Span{}
		for {
			if bodyBytes == nil || len(bodyBytes) == 0 {
				break
			}
			lineSeparatorPos := bytes.IndexByte(bodyBytes, '\n')
			if lineSeparatorPos == -1 {
				line := bodyBytes
				span := processOneLineByte(batchId, routineId, rowId, line)
				spanList[rowId] = span
				//spanList = append(spanList, span)
				rowId++
				break
			}

			line := bodyBytes[:lineSeparatorPos+1]
			//println(string(line))
			bodyBytes = bodyBytes[lineSeparatorPos+1:]

			span := processOneLineByte(batchId, routineId, rowId, line)
			//if span != nil {
			spanList[rowId] = span
			//spanList = append(spanList, span)
			//}

			rowId++
		}
		//ProcessSpan(batchId*DefaultRoutineNum+routineId, spanList, rowId)
	}
	defer spanGet.WG.Done()

}

func processOneLineByte(batchId int, routineId int, rowId int, line []byte) Span {
	span := Span{}
	span.batchId = batchId
	span.routineId = routineId
	span.rowId = rowId
	span.spanBytes = line

	len := len(line)
	if len < 2 {
		return span
	} else if span.batchId == 0 && span.routineId == 0 && span.rowId == 0 && line[len-1] == '\n' {
		span.isFullSpan = true
	} else if span.rowId > 0 && line[len-1] == '\n' {
		span.isFullSpan = true
	} else {
		span.isFullSpan = false
	}

	//if span.isFullSpan {
	//	span.spanBytes = line[:len - 1]
	//	log.Printf("BID[%d] RID[%d] - Full SPAN: hasError=%t, Line: %s", batchId, routineId, span.hasError, string(line))
	//} else {
	//	log.Printf("BID[%d] RID[%d] - Not Full SPAN: hasError=%t, Line: %s", batchId, routineId, span.hasError, string(line))
	//}

	if span.isFullSpan {
		span.traceIdSeparatorPos = bytes.IndexByte(line, byte('|'))
		span.traceId = string(line[:bytes.IndexByte(line, byte('|'))])
		//fmt.Printf("Trace Id: %s\n", span.traceId)
		if util.CheckSpanIfError(line) {
			span.hasError = true
		}
	}
	return span
}
