package clientprocess

import (
	"tailsampling/config"
	"tailsampling/entity"
	"tailsampling/util"
)

//for backend to call to get all error span for one batch
func getWrongTracing(data *entity.WrongTrace) map[string][]string {
	wrongTraceIdList := data.TraceIdList
	pos := data.BatchId % config.TRACE_MAP_BUCKET_NUMBER
	prePos := util.FindPreviousBatchPos(pos, config.TRACE_MAP_BUCKET_NUMBER)

	nextPos := util.FindNextBatchPos(pos, config.TRACE_MAP_BUCKET_NUMBER)

	wrongTraceData := make(map[string][]string)
	if len(wrongTraceIdList) > 0 {
		for i := range wrongTraceIdList {
			traceId := wrongTraceIdList[i]
			//traceIdHash := hash([]byte(traceId), 0)
			wrongTraceData[traceId] = append(wrongTraceData[traceId], BATCH_TRACE_LIST[prePos][traceId]...)
			wrongTraceData[traceId] = append(wrongTraceData[traceId], BATCH_TRACE_LIST[pos][traceId]...)
			wrongTraceData[traceId] = append(wrongTraceData[traceId], BATCH_TRACE_LIST[nextPos][traceId]...)
		}
	}

	//unlock the batch trace cache for pre batch, cause it is already consumed by backend. no need any more.
	cond := LOCK_BUCKET[prePos]
	cond.L.Lock()
	BATCH_TRACE_LIST[prePos] = make(map[string][]string, config.ROW_PER_BATCH)
	ERROR_TRACE[prePos] = make([]string, 0, config.MAX_ERROR_PER_BATCH)
	cond.Broadcast()
	cond.L.Unlock()

	return wrongTraceData
}
