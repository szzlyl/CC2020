package clientprocess

import (
	"fmt"
	"github.com/thinkeridea/go-extend/exbytes"
	"log"
	"tailsampling/config"
	"tailsampling/entity"
	"testing"
	"time"
)

// Test span Data
var spanList = []Span{
	Span{
		batchId:             0,
		routineId:           config.ROUTINE_NUMBER_PER_BATCH - 1,
		rowId:               30,
		traceIdUint64:       0,
		traceId:             "1",
		traceIdSeparatorPos: 0,
		spanBytes:           []byte("error trace, but no error span1"),
		hasError:            false,
		isFullSpan:          true,
	},
	Span{
		batchId:             0,
		routineId:           config.ROUTINE_NUMBER_PER_BATCH - 1,
		rowId:               31,
		traceIdUint64:       0,
		traceId:             "1",
		traceIdSeparatorPos: 0,
		spanBytes:           []byte("1nd part, error trace, but no error span"),
		hasError:            false,
		isFullSpan:          false,
	},
	Span{
		batchId:             1,
		routineId:           0,
		rowId:               0,
		traceIdUint64:       0,
		traceId:             "1",
		traceIdSeparatorPos: 0,
		spanBytes:           []byte("2nd part"),
		hasError:            false,
		isFullSpan:          false,
	},
	Span{
		batchId:             1,
		routineId:           0,
		rowId:               2,
		traceIdUint64:       0,
		traceId:             "2",
		traceIdSeparatorPos: 0,
		spanBytes:           []byte("trace 2 error span"),
		hasError:            true,
		isFullSpan:          true,
	},
	Span{
		batchId:             1,
		routineId:           0,
		rowId:               3,
		traceIdUint64:       0,
		traceId:             "1",
		traceIdSeparatorPos: 0,
		spanBytes:           []byte("error trace 1, error span2"),
		hasError:            true,
		isFullSpan:          true,
	},
	Span{
		batchId:             1,
		routineId:           0,
		rowId:               4,
		traceIdUint64:       0,
		traceId:             "1",
		traceIdSeparatorPos: 0,
		spanBytes:           []byte("error trace 1, no error span3"),
		hasError:            false,
		isFullSpan:          true,
	},
}

func TestInit(t *testing.T) {
	tests := []struct {
		name string
	}{
		// TODO: Add test cases.
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
		})
	}
	Init()
}

func TestProcessSpan(t *testing.T) {

	var spanList = []Span{}
	spanList = append(spanList, Span{
		batchId:             0,
		routineId:           0,
		rowId:               0,
		traceIdUint64:       0,
		traceId:             "",
		traceIdSeparatorPos: 0,
		spanBytes:           nil,
		hasError:            false,
		isFullSpan:          false,
	})

	//ProcessSpan(1, spanList)
}

func Test_findOtherPartKey(t *testing.T) {
	type args struct {
		batchId int
		rountId int
		rowId   int
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{"last batch tail", args{
			batchId: 3,
			rountId: 0,
			rowId:   0,
		}, fmt.Sprintf("%d_%d_T", 2, config.ROUTINE_NUMBER_PER_BATCH-1),
		},
		{"same batch last rountine tail", args{
			batchId: 3,
			rountId: 2,
			rowId:   0,
		}, fmt.Sprintf("%d_%d_T", 3, 1),
		},
		{"same batch next rountine head", args{
			batchId: 3,
			rountId: 1,
			rowId:   10,
		}, fmt.Sprintf("%d_%d_H", 3, 2),
		},
		{"next batch head", args{
			batchId: 3,
			rountId: config.ROUTINE_NUMBER_PER_BATCH - 1,
			rowId:   232,
		}, fmt.Sprintf("%d_%d_H", 4, 0),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			//if got := findOtherPartKey(tt.args.batchId, tt.args.rountId, tt.args.rowId); got != tt.want {
			//	t.Errorf("findOtherPartKey() = %v, want %v", got, tt.want)
			//}
		})
	}
}

//
func Test_fixPartialSpan(t *testing.T) {
	Init()
	for i := range spanList {
		if !spanList[i].isFullSpan {
			fixPartialSpan(1, spanList[i])
		}
	}

}

func TestProcessSpan1(t *testing.T) {
	//ProcessSpan(1, spanList)
	//log.Print(len(spanList))

}

func Test_getWrongTracing(t *testing.T) {
	ProcessSpan()
	getWrongTracing(&entity.WrongTrace{
		TraceIdList: []string{"0", "1", "2", "3"},
		BatchId:     1,
	})
}

func Test_byteToStringPerformance(t *testing.T) {

	strByte := []byte("1d37a8b17db8568b|1589285985482071|23a19dcb2768db5f|5ac24275abbc87a6|1195|OrderCenter|db.ArmsAppDao.getAppListByUserIdAllRegion(..)|192.168.0.18|http.status_code=200&component=java-web-servlet&span.kind=server&sampler.type=const&sampler.param=1&http.url=http://localhost:8081/buyItem&http.method=GET")
	startTime := time.Now().UnixNano()
	str := ""
	for i := 1; i <= 100000; i++ {
		str = string(strByte[:])
	}
	endTime := time.Now().UnixNano()
	log.Printf("cost time using string([]byte) %d", endTime-startTime)

	startTime = time.Now().UnixNano()
	for i := 1; i <= 100000; i++ {
		str = exbytes.ToString(strByte[:])
	}
	endTime = time.Now().UnixNano()
	log.Printf("cost time using exbytes.ToString %d", endTime-startTime)

	log.Print(str)

}

func TestProcessSpan2(t *testing.T) {
	ProcessSpan()
}
