package clientprocess

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"log"
	"net/http"
	"net/url"
	"sync"
	"tailsampling/config"
	"tailsampling/entity"
	"tailsampling/util"
	"time"
)

var (
	NON_FULL_SPAN_MAP = make([][][]byte, config.MAX_BATCH_NUM)

	traceCheckSumData map[string]string

	TRACE_CHECK_SUM_DATA map[string]string

	// an list of trace map,like ring buffe.
	//every batch will have one map to store the Trace ID and the span under the same trace id,
	//key is traceId, value is spans.
	BATCH_TRACE_LIST = make([]map[string][]string, config.TRACE_MAP_BUCKET_NUMBER)
	ERROR_TRACE      = make([][]string, config.TRACE_MAP_BUCKET_NUMBER)
	LOCK             = sync.Mutex{}
	LOCK_BUCKET      = make([]*sync.Cond, config.TRACE_MAP_BUCKET_NUMBER)

	BUFFER = make([]byte, config.PAGE_LENGTH)
)

func Init() {
	for i := 0; i < config.TRACE_MAP_BUCKET_NUMBER; i++ {
		BATCH_TRACE_LIST[i] = make(map[string][]string, config.ROW_PER_BATCH)
		ERROR_TRACE[i] = make([]string, 0, config.MAX_ERROR_PER_BATCH)
		LOCK_BUCKET[i] = sync.NewCond(&LOCK)
	}

	http.HandleFunc("/getWrongTrace", getWrongTrace)

}

func getWrongTrace(writer http.ResponseWriter, request *http.Request) {
	body, _ := ioutil.ReadAll(request.Body)

	var data entity.WrongTrace
	_ = json.Unmarshal(body, &data)

	response := getWrongTracing(&data)
	responseBytes, _ := json.Marshal(response)
	_, _ = writer.Write(responseBytes)
}

// Get all the ErrorSpan by a list of trace id in ErrorTrace
//func getWrongTracing(errorTraceBatch *[]entity.WrongTraceByBatch) []entity.SpanByTrace {
//
//	returnVal := []entity.SpanByTrace{}
//	//wrongTraceIdList := errorTrace.TraceIdList
//	//
//	//wrongTraceData := []entity.ErrorSpan{}
//	//if len(wrongTraceIdList) > 0 {
//	//	for i := range wrongTraceIdList {
//	//		traceId := wrongTraceIdList[i]
//	//		if errorTrace.BatchId > 0 {
//	//			wrongTraceData = append(wrongTraceData, spanListToErrorList(traceMapBucket[errorTrace.BatchId-1][traceId]...)...)
//	//		}
//	//		wrongTraceData = append(wrongTraceData, spanListToErrorList(traceMapBucket[errorTrace.BatchId][traceId]...)...)
//	//		if v, ok := traceMapBucket[errorTrace.BatchId+1]; ok {
//	//			wrongTraceData = append(wrongTraceData, spanListToErrorList(v[traceId]...)...)
//	//		}
//	//
//	//	}
//	//}
//	return returnVal
//}

//to process the Span list produce by Span producer
func ProcessSpan() {
	//defer timeTrack(time.Now(), "ProcessSpan")
	//defer timeTrack(time.Now(), "ProcessSpan")
	url := util.GetUrl()
	log.Print("loading file: " + url)

	resp, err := http.Get(url)
	if err != nil {
		return
	}

	count, pos := readFile(resp)

	errorList := ERROR_TRACE[pos]
	if len(errorList) > 0 {
		updateWrongTraceId((count/config.ROW_PER_BATCH)-1, errorList)
	}

	callFinish()

}

func readFile(resp *http.Response) (int, int) {
	count := 0
	pos := 0
	tailLength := 0
	for {
		read, _ := resp.Body.Read(BUFFER[tailLength : config.PAGE_LENGTH-tailLength])
		if read == 0 {
			break
		}
		endIndex := read + tailLength

		startIndex := 0
		for {
			lineIndex := bytes.IndexByte(BUFFER[startIndex:endIndex], '\n')
			if lineIndex < 0 {
				tailLength = endIndex - startIndex
				copy(BUFFER[:tailLength], BUFFER[startIndex:endIndex])
				break
			}

			count++
			lineEndIndex := startIndex + lineIndex
			traceId := ""
			for i := startIndex + 11; i < lineEndIndex; i++ {
				if BUFFER[i] == config.SEPERACTOR {
					traceId = string(BUFFER[startIndex:i])
					BATCH_TRACE_LIST[pos][traceId] = append(BATCH_TRACE_LIST[pos][traceId], string(BUFFER[startIndex:lineEndIndex]))
					break
				}
			}

			if CheckSpanIfError(BUFFER, startIndex, lineEndIndex) {
				ERROR_TRACE[pos] = append(ERROR_TRACE[pos], traceId)
			}

			if count%config.ROW_PER_BATCH == 0 {
				pos = processBatch(pos, count)
			}

			startIndex += lineIndex + 1
			if startIndex > endIndex {
				tailLength = 0
				break
			}
		}
	}
	return count, pos
}

func processBatch(pos int, count int) int {
	errorList := ERROR_TRACE[pos]
	go updateWrongTraceId((count/config.ROW_PER_BATCH)-1, errorList)

	pos++

	if pos >= config.TRACE_MAP_BUCKET_NUMBER {
		pos = 0
	}

	//batch trace Map cache. the len of the map should be 0 initially.
	//If the len of the Map > 0, it means backend not yet consume the data. need to wait for backend to consume
	if len(BATCH_TRACE_LIST[pos]) > 0 {
		cond := LOCK_BUCKET[pos]
		cond.L.Lock()
		if len(BATCH_TRACE_LIST[pos]) > 0 {
			cond.Wait()
		}
	}
	return pos
}

//heandle buffer
func handleBuffer(read int, tailLength int, count int, pos int) (int, int) {
	endIndex := read + tailLength

	startIndex := 0
	for {
		lineIndex := bytes.IndexByte(BUFFER[startIndex:endIndex], '\n')
		if lineIndex < 0 {
			tailLength = endIndex - startIndex
			copy(BUFFER[:tailLength], BUFFER[startIndex:endIndex])
			break
		}

		count++
		lineEndIndex := startIndex + lineIndex
		traceId := ""
		for i := startIndex + 11; i < lineEndIndex; i++ {
			if BUFFER[i] == config.SEPERACTOR {
				traceId = string(BUFFER[startIndex:i])
				BATCH_TRACE_LIST[pos][traceId] = append(BATCH_TRACE_LIST[pos][traceId], string(BUFFER[startIndex:lineEndIndex]))
				break
			}
		}

		if CheckSpanIfError(BUFFER, startIndex, lineEndIndex) {
			ERROR_TRACE[pos] = append(ERROR_TRACE[pos], traceId)
		}

		//reach batch size, start to send to backend
		if count%config.ROW_PER_BATCH == 0 {
			pos = processBatch(pos, count)
		}

		startIndex += lineIndex + 1
		if startIndex > endIndex {
			tailLength = 0
			break
		}
	}
	return count, pos
}

//Send a list of ErrorSpan to backend for processing
//func sendErrorSpan(batchId int, errorTraceList []string) {
//	errorTraceBatch := entity.WrongTraceByBatch{
//		TraceIdList: errorTraceList,
//		BatchId: batchId,
//	}
//	data, _ := json.Marshal(errorTraceBatch)
//	_, _ = http.Post("http://localhost:"+config.BACKEND_PROCESS_PORT1+"/setWrongTraceId", "application/json", bytes.NewBuffer(data))
//	log.Printf("send error span to backend, Span number: %d", len(errorTraceList))
//}

func updateWrongTraceId(batchId int, wrongTrace []string) {
	uploadData := entity.WrongTrace{wrongTrace, batchId}
	data, _ := json.Marshal(uploadData)
	_, _ = http.Post("http://localhost:"+config.BACKEND_PROCESS_PORT1+"/setWrongTraceId", "application/json", bytes.NewBuffer(data))
}

//due to ramdom cut of the download file, some span will be cut into multiple part,
//this funciton will find the other part of the span and merge into one span
func fixPartialSpan(batchId int, span Span) Span {
	if span.rowId == 0 {
		if batchId-1 >= 0 && NON_FULL_SPAN_MAP[batchId-1][1] != nil {
			span.spanBytes = append(NON_FULL_SPAN_MAP[batchId-1][1], span.spanBytes...)
			span.isFullSpan = true

			span.traceId = string(span.spanBytes[:bytes.IndexByte(span.spanBytes, byte('|'))])
		} else {
			NON_FULL_SPAN_MAP[batchId][0] = append(NON_FULL_SPAN_MAP[batchId][0], span.spanBytes...)
		}
	} else {
		if NON_FULL_SPAN_MAP[batchId+1][0] != nil {
			span.spanBytes = append(span.spanBytes, NON_FULL_SPAN_MAP[batchId+1][0]...)
			span.isFullSpan = true
			span.traceId = string(span.spanBytes[:bytes.IndexByte(span.spanBytes, byte('|'))])
		} else {
			NON_FULL_SPAN_MAP[batchId][1] = append(NON_FULL_SPAN_MAP[batchId][1], span.spanBytes...)
		}
	}
	return span
}

func callFinish() {
	log.Printf("callFinish at %s", time.Now())
	_, _ = http.Get("http://localhost:" + config.BACKEND_PROCESS_PORT1 + "/finish")
	//SendCheckSum()
}

func SendCheckSum() bool {
	result, _ := json.Marshal(traceCheckSumData)
	response, err := http.PostForm("http://localhost:"+config.DataSourcePort+"/api/finished", url.Values{
		"result": []string{string(result)},
	})
	if err != nil {
		return false
	}
	if response.StatusCode != 200 {
		return false
	}
	return true
}

func CheckSpanIfError(buffer []byte, start int, end int) bool {
	searchStart := start + 100
	searchEnd := end
	for {
		pos := bytes.IndexByte(buffer[searchStart:searchEnd], '=')
		if pos < 0 {
			return false
		}
		searchStart += pos
		if buffer[searchStart-2] == 'd' && buffer[searchStart-1] == 'e' {
			return buffer[searchStart+1] != '2'
		}
		if buffer[searchStart-2] == 'o' && buffer[searchStart-1] == 'r' {
			return true
		}

		searchStart += 4
		if searchStart > searchEnd {
			return false
		}
	}
}
