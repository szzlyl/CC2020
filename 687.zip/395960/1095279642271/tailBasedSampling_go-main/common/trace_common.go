package common

func (m *TraceData) AddSpan(newSpans [][]byte) {
	m.Lock()
	m.Sb = append(m.Sb, newSpans...)
	m.Unlock()
}

type SpanData struct {
	StartTime string
	Tags      []byte
}

type Spans []*SpanData

func (s Spans) Len() int           { return len(s) }
func (s Spans) Swap(i, j int)      { s[i], s[j] = s[j], s[i] }
func (s Spans) Less(i, j int) bool { return s[i].StartTime < s[j].StartTime }
