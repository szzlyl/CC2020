package main

import (
	"flag"
	"fmt"
	"github.com/larrydpk/tailBasedSampling_go/backend"
	"github.com/larrydpk/tailBasedSampling_go/client"
	"github.com/larrydpk/tailBasedSampling_go/scorer"
	"math/rand"
	"runtime"
	"sync"
	"time"
)

func main() {

	rand.Seed(time.Now().Unix())
	var httpPort string
	flag.StringVar(&httpPort, "p", "", "port")
	flag.Parse()

	if httpPort == "8000" || httpPort == "8001" {
		receiver := client.Receiver{
			HttpPort:             httpPort,
			CollectorPort:        "8002",
			CollectorSetWrongUrl: fmt.Sprintf("http://127.0.0.1:8002/setWrong"),
		}
		runtime.GOMAXPROCS(2)
		receiver.Run()
	} else if httpPort == "8002" {
		compactor := backend.Collector{
			HttpPort: httpPort,
		}
		runtime.GOMAXPROCS(2)
		compactor.Run()
	} else if httpPort == "38081" {
		datapath := "G:\\tianchi\\smalldata"
		scorer := scorer.Scorer{
			Mtx:      sync.RWMutex{},
			Datapath: datapath,
			Servers: map[string]int{
				"http://localhost:8000": 0,
				"http://localhost:8001": 0,
				"http://localhost:8002": 0,
			},
		}
		runtime.GOMAXPROCS(2)
		scorer.Run()
	}

	fmt.Printf("port not macth [%v] \n", httpPort)
	time.Sleep(10 * time.Second)
}
