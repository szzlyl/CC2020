# tailBasedSampling_go

## env setup
For down go module, need to set env:

https://learnku.com/go/wikis/38122

```text
# 启用 Go Modules 功能
go env -w GO111MODULE=on

# 配置 GOPROXY 环境变量，以下三选一

# 1. 七牛 CDN
export GOPROXY=https://goproxy.cn,direct

# 2. 阿里云
export GOPROXY=https://mirrors.aliyun.com/goproxy/,direct

# 3. 官方
export GOPROXY=https://goproxy.io,direct
```

## how to run in local
+ put data(trace1.data, trace2.data and checkSum.data) in G:\tianchi\data (or change the datapath in main.go)
+ cd tailBasedSampling
+ go build
+ ./tailBasedSampling_go.exe -p=38081
+ ./tailBasedSampling_go.exe -p=8002
+ ./tailBasedSampling_go.exe -p=8000
+ ./tailBasedSampling_go.exe -p=8001


## how to build image and test
update the `ver` in file `build.sh` and execute the command:
```shell script
sh build.sh
```

update the image in `docker-compose/samping.yaml` and start:
```shell script
docker-compose -f docker-compose/samping.yaml -f docker-compose/scoring.yaml up
```


## Go study
入门：
https://github.com/unknwon/the-way-to-go_ZH_CN/blob/master/eBook/directory.md

并发： https://juejin.cn/post/6844904147880263694

# 新数据调参优化记录


| 镜像           | 说明                          | workNum | extDownloader | downloadStepSize | readBufSize | score  | f1         | costTime |
| -------------- | ----------------------------- | ------- | ------------- | ---------------- | ----------- | ------ | ---------- | -------- |
| 1201-04-go     | 原10s第一次                   | 4       | 3             | 256              | 16          | 28571  | 137200000  | 4802     |
| 1201-04-go     | 原10s第二次                   | 4       | 3             | 256              | 16          | 29529  | 131700000  | 4460     |
| 1205-2nd-score | 之前第二名                    | 8       | 5             | 120              | 20          | 27401  | 137200000  | 5007     |
| 1205-09-go     | 新                            | 5       | 2             | 256              | 32          | 249889 | 1132000000 | 4530     |
| 1205-10-go     | 新                            | 5       | 2             | 128              | 16          | 264981 | 1132000000 | 4272     |
| 1206-01-go     | 作者原参数                    | 4       | 1             | 512              | 64          | 34717  | 139600000  | 4021     |
| 1206-02-go     | 新                            | 6       | 1             | 128              | 16          | 251109 | 1132000000 | 4508     |
| 1206-04-go     | 同时改了GOMAXPROCS为3/2       | 4       | 1             | 128              | 16          | 31692  | 139700000  | 4408     |
| 1206-06-go     | 同时改了GOMAXPROCS为2/2       | 5       | 2             | 128              | 16          | 268564 | 1132000000 | 4215     |
| 1207-03-go     | 同上                          | 6       | 2             | 128              | 16          | 278543 | 1132000000 | 4064     |
| 1207-04-go     | 同上                          | 8       | 2             | 128              | 16          | 248791 | 1132000000 | 4550     |
| 1207-05-go     | 同上                          | 8       | 3             | 128              | 16          | 31161  | 133900000  | 4297     |
| 1207-06-go     | 同上                          | 7       | 2             | 128              | 16          | 289810 | 1132000000 | 3906     |
| 1207-07-go     | 同上                          | 7       | 2             | 256              | 32          | 28584  | 123200000  | 4310     |
| 1207-09-go     | 没改GOMAXPROCS                | 7       | 2             | 128              | 16          | 609    | 109000000  | 178965   |
| 1208-01-go     | Nolog,同时改了GOMAXPROCS为2/2 | 7       | 2             | 128              | 16          | 270683 | 1132000000 | 4182     |
| 1208-02-go     | 同上，2_0000->18000           | 7       | 2             | 128              | 16          | 278269 | 1132000000 | 4068     |
| 1208-03-go     | 同上，2_0000->16000           | 7       | 2             | 128              | 16          | 34656  | 141400000  | 4080     |
| 1208-04-go     | 同上，18000, 12000->10000     | 7       | 2             | 128              | 16          | 32061  | 138600000  | 4323     |
| 1209-01-go     | 同1207-03-go                 | 6       | 2             | 128              | 16          | 272902  | 1132000000 | 4148     |
| 1209-04-go     | 同1208-01-go                 | 7       | 2             | 128              | 16          | 272902  | 1132000000 | 3997     |
| 1209-07-go     | 同上，2_0000->1_8000          | 7       | 2             | 128              | 16          | 272902  | 1132000000 | 4389     |








