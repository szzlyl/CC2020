#!/usr/bin/env bash
set -ex

ver=1209-09-go

CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o main *.go
docker build -t tail-based-sampling:1 .
docker tag tail-based-sampling:1 registry.cn-shenzhen.aliyuncs.com/pkslow/star/tianchi:${ver}
