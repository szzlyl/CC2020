package client

import (
	"sync"
)

type TraceData struct {
	IsErrorTrace bool
	Status       uint8
	n            uint8
	id           string
	Spans        []int
}

type TraceDataMapShard struct {
	mu           sync.RWMutex
	traceDataMap map[string]*TraceData
}

func (t *TraceDataMapShard) LoadOrStore(id string, val *TraceData) (*TraceData, bool) {
	t.mu.Lock()
	if v, ok := t.traceDataMap[id]; ok {
		t.mu.Unlock()
		return v, true
	} else {
		t.traceDataMap[id] = val
		t.mu.Unlock()
		return val, false
	}
}

func (t *TraceDataMapShard) Load(id string) (*TraceData, bool) {
	t.mu.RLock()
	if v, ok := t.traceDataMap[id]; ok {
		t.mu.RUnlock()
		return v, true
	} else {
		t.mu.RUnlock()
		return nil, false
	}
}

const shardNum = 128
const shardNum1 = shardNum - 1

func NewTraceDataMap() *TraceDataMap {
	m := &TraceDataMap{shards: make([]*TraceDataMapShard, shardNum)}
	for i := 0; i < shardNum; i++ {
		m.shards[i] = &TraceDataMapShard{
			traceDataMap: make(map[string]*TraceData, 7000),
			mu:           sync.RWMutex{},
		}
	}
	return m
}

type TraceDataMap struct {
	shards []*TraceDataMapShard
}

func (t *TraceDataMap) Load(id string) (*TraceData, bool) {
	shard := t.shards[uint(fnv32(id))&shardNum1]

	return shard.Load(id)
}

func (t *TraceDataMap) LoadOrStore(id string, val *TraceData) (*TraceData, bool) {
	shard := t.shards[uint(fnv32(id))&shardNum1]
	return shard.LoadOrStore(id, val)
}

//
const prime32 = uint32(16777619)
const offset = uint32(2166136261)

// FNV hash
func fnv32(key string) uint32 {
	hash := uint32(2166136261)
	for i := 0; i < 5; i++ {
		hash *= prime32
		hash ^= uint32(key[i])
	}
	return hash
}

func fnvi64(key string) int64 {
	hash := int64(2166136261)
	for i := 0; i < 7; i++ {
		hash *= prime64
		hash ^= int64(key[i])
	}
	return hash
}

const (
	// offset64 FNVa offset basis. See https://en.wikipedia.org/wiki/Fowler–Noll–Vo_hash_function#FNV-1a_hash
	offset64 = 14695981039346656037
	// prime64 FNVa prime value. See https://en.wikipedia.org/wiki/Fowler–Noll–Vo_hash_function#FNV-1a_hash
	prime64 = 1099511628211
)

// Sum64 gets the string and returns its uint64 hash value.
func fnv64(key string) uint {
	var hash uint = offset64
	for i := 0; i < len(key); i++ {
		hash ^= uint(key[i])
		hash *= prime64
	}
	return hash
}
