package client

import (
	"bytes"
	"github.com/larrydpk/tailBasedSampling_go/common"
	"sync/atomic"
)

const (
	TraceStatusErrorSet = 1
	TraceStatusSkip     = 2
	TraceStatusSent     = 3
	TraceStatusDone     = 4
)

func (r *Receiver) processSpans(spanMetaData []int) {
	var idToSpans *Map
	select {
	case idToSpans = <-r.idMapCache:
	default:
		idToSpans = New(12000, 0.99)
	}

	for i, val := range spanMetaData {
		//Get span from span meta data
		start := val >> 16
		len := val & 0xffff
		span := spansBuffer[start : start+len]

		traceId := GetTraceIdFromSpan(span)
		traceIdInt64 := fnvi64(traceId)
		if positionOnTraceDataCache, ok := idToSpans.Get(traceIdInt64); !ok {
			//New trace found, we already have TraceData cache pooo, just fetch
			//empty slot from traceDataCache and fill in real data

			//Get slot
			var traceData *TraceData
			nextPosition := atomic.AddInt64(&r.cursorOnTraceDataCache, 1)
			if nextPosition < traceDataCacheLimit {
				traceData = traceDataCache[nextPosition]
			} else {
				nextPosition = nextPosition & (traceDataCacheLimit - 1)
				traceData = traceDataCache[nextPosition]
				traceData.Spans = traceData.Spans[:0]
			}

			//Fill data
			traceData.id = traceId
			traceData.IsErrorTrace = IsErrorSpan(span)
			traceData.Spans = append(traceData.Spans, val)
			if i > batchSize && i < spansBatchNum-batchSize {
				traceData.Status = TraceStatusSkip
			}

			//Add to map
			idToSpans.Put(traceIdInt64, nextPosition)
		} else {
			//Existing Trace, just update status and update span array
			existingTraceData := traceDataCache[positionOnTraceDataCache]
			if !existingTraceData.IsErrorTrace && IsErrorSpan(span) {
				existingTraceData.IsErrorTrace = true
			}
			existingTraceData.Spans = append(existingTraceData.Spans, val)
		}
	}

	for i := 0; i < len(idToSpans.data); i += 2 {
		if idToSpans.data[i] == FREE_KEY {
			continue
		}
		traceDataPosition := idToSpans.data[i+1]
		traceData := traceDataCache[traceDataPosition]
		traceId := traceData.id
		if traceData.Status == TraceStatusSkip && traceData.IsErrorTrace {
			r.dropTrace(traceId, traceData, "0")
			continue
		}
		currentTraceData, exist := r.idToTrace.LoadOrStore(traceId, traceData)
		if exist {
			currentTraceData.Spans = append(currentTraceData.Spans, traceData.Spans...)

			if !currentTraceData.IsErrorTrace && traceData.IsErrorTrace {
				currentTraceData.IsErrorTrace = true
			}
			if currentTraceData.Status == TraceStatusErrorSet {
				goto SET_AND_DROP
			}
			continue
		}
		if currentTraceData.Status == TraceStatusSkip {
			r.dropTrace(traceId, currentTraceData, "0")
			continue
		}
	SET_AND_DROP:
		postDeletion := false
		for !postDeletion {
			select {
			case r.dropIdQueue <- traceId:
				postDeletion = true
			default:
				dropId, ok := <-r.dropIdQueue
				if ok {
					r.dropTraceById(dropId, "0")
				}
			}
		}
	}
}

func GetTraceIdFromSpan(line []byte) string {
	return common.BytesToString(line[:bytes.IndexByte(line, '|')])
}

func IsErrorSpan(l []byte) bool {
	length := len(l)
	for {
		p := bytes.IndexByte(l[:], '=')

		if p == -1 {
			return false
		}

		if l[p-2] == 'o' &&
			l[p-1] == 'r' &&
			l[p+1] == '1' {
			return true
		}

		if l[p-2] == 'd' &&
			l[p-1] == 'e' &&
			l[p+1] != '2' {
			return true
		}

		if p < length-1 {
			l = l[p+1:]
		} else {
			return false
		}
	}
}

func (r *Receiver) readSpansMeta() {
	r.doneWg.Add(1)
	defer r.doneWg.Done()
	for spansMeta := range r.spansMetaQueue {
		r.processSpans(spansMeta)
	}
}
