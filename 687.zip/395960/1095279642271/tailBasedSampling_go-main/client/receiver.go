package client

import (
	"bytes"
	"go.uber.org/zap"
	"io"
	"sync"
	"time"
)

type Receiver struct {
	HttpPort             string // 8000,8001
	DataPort             string // 8081
	CollectorPort        string // 8002
	CollectorSetWrongUrl string
	idToTrace            *TraceDataMap

	dropIdQueue  chan string
	finishSignal chan interface{}

	overWg sync.WaitGroup

	traceNums   int64
	maxSpanNums int
	minSpanNums int
	mapMaxSize  int
	mapMinSize  int
	traceMiss   int
	traceSkip   int
	wrongHit    int

	cursorOnTraceDataCache int64

	idMapCache chan *Map

	spansMetaQueue  chan []int
	readBufSize     int
	doneWg          sync.WaitGroup
	spansMetaCache  chan []int
	bufferRangeChan chan BufferRange
}

func NewTraceData() *TraceData {
	return &TraceData{
		Spans: make([]int, 0, 100),
	}
}

const (
	// buffer 缓冲区大小
	spansBufferSize = int(2.5 * 1024 * 1024 * 1024)

	// 聚合批处理长度
	spansBatchNum = 20_0000

	// Trace的最大跨度
	batchSize = 2_0000

	// 预分配
	batchNum = 130

	// trace 环形数组
	traceDataCacheLimit = 512 * 1024

	// 处理具体数据的worker
	processRoutineCount = 7

	// 额外的下载协程数量
	extraRoutineCountForDownload = 2

	// 用于每个range下载的初始大小
	downloadStepSize = 128 * 1024 * 1024

	// 下载文件时,凑够buffer再提交处理队列
	readBufSize = 16 * 1024 * 1024

	// Map大小
	//idToSpanMapSize = 12000
)

var (
	spansBuffer    = make([]byte, spansBufferSize)
	traceDataCache = make([]*TraceData, traceDataCacheLimit)
	logger, _      = zap.NewProduction()
)

type BufferRange struct {
	start  int
	length int
}

func (r *Receiver) Run() {

	for i := int64(0); i < traceDataCacheLimit; i++ {
		traceDataCache[i] = NewTraceData()
	}

	r.readBufSize = readBufSize

	r.idMapCache = make(chan *Map, batchNum)
	for i := 0; i < batchNum; i++ {
		r.idMapCache <- New(12000, 0.99)
	}

	r.spansMetaQueue = make(chan []int, batchNum)
	r.spansMetaCache = make(chan []int, batchNum)
	for i := 0; i < batchNum; i++ {
		r.spansMetaCache <- make([]int, spansBatchNum)
	}

	r.idToTrace = NewTraceDataMap()

	r.dropIdQueue = make(chan string, 6000)
	r.finishSignal = make(chan interface{})

	r.bufferRangeChan = make(chan BufferRange, 1024)

	go r.processBufferRange()
	for i := 0; i < processRoutineCount; i++ {
		go r.readSpansMeta()
	}
	go r.finish()

	r.RunHttpServer()
}

func (r *Receiver) Read(dataUrl string) {
	size := 0

	//Construct Http Readers
	httpRangeReaders := GenHttpRangeReaders(dataUrl, spansBufferSize, downloadStepSize, readBufSize)
	downTaskChan := make(chan int, len(httpRangeReaders))
	for hi, httpRangeReader := range httpRangeReaders {
		httpRangeReader.readBufSize = r.readBufSize
		httpRangeReader.buffer = spansBuffer
		downTaskChan <- hi
	}

	for i := 0; i < extraRoutineCountForDownload; i++ {
		go func() {
			for hi := range downTaskChan {
				if !httpRangeReaders[hi].exitRead {
					httpRangeReaders[hi].waitGroup.Add(1)
					httpRangeReaders[hi].asyncFill()
				}
			}
		}()
	}

	for _, httpRangeReader := range httpRangeReaders {
		httpRangeReader.exitRead = true
		close(httpRangeReader.readSignal)
		httpRangeReader.waitGroup.Wait()

		if httpRangeReader.currentWrite > httpRangeReader.currentRead {
			size += httpRangeReader.currentWrite - httpRangeReader.currentRead
			r.bufferRangeChan <- BufferRange{start: httpRangeReader.currentRead,
				length: httpRangeReader.currentWrite - httpRangeReader.currentRead}
		}

		for {
			var n int
			var err error
			if httpRangeReader.currentWrite+httpRangeReader.readBufSize <= httpRangeReader.BufferEnd {
				n, err = io.ReadAtLeast(httpRangeReader.reader, httpRangeReader.buffer[httpRangeReader.currentWrite:],
					httpRangeReader.readBufSize)
			} else {
				n, err = httpRangeReader.reader.Read(httpRangeReader.buffer[httpRangeReader.currentWrite:])
			}
			if n > 0 {
				r.bufferRangeChan <- BufferRange{start: httpRangeReader.currentWrite, length: n}
				httpRangeReader.currentWrite += n
			}
			if err != nil {
				goto RUN_DOWN
			}
		}
	RUN_DOWN:
	}

	close(r.bufferRangeChan)

	r.doneWg.Wait()

	close(r.finishSignal)
}

//Get buffer range from chan and convert to spans meta data
func (r *Receiver) processBufferRange() {

	r.doneWg.Add(1)
	defer r.doneWg.Done()

	i := 0
	var spansMeta []int
	select {
	case spansMeta = <-r.spansMetaCache:
	default:
		spansMeta = make([]int, spansBatchNum)
	}

	readPosition := 0
	writePosition := 0

	for val := range r.bufferRangeChan {
		start := val.start
		length := val.length

		writeMaxPos := writePosition + length
		//Wrap around when exceed spans buffer size
		if writeMaxPos > spansBufferSize {
			wrapAroundSize := writePosition - readPosition
			if wrapAroundSize > 0 {
				logger.Info("Wrap around the buffer",
					zap.Int("size", wrapAroundSize),
				)
				copy(spansBuffer[r.readBufSize-wrapAroundSize:r.readBufSize], spansBuffer[readPosition:writePosition])
				readPosition = r.readBufSize - wrapAroundSize
				writeMaxPos = start + length
			}
		}

		writePosition = writeMaxPos

		for {
			if position := bytes.IndexByte(spansBuffer[readPosition:writePosition], '\n'); position >= 0 {

				spansMeta[i] = readPosition<<16 | position + 1
				readPosition += position + 1
				if i == (spansBatchNum - 1) {
					r.spansMetaQueue <- spansMeta
					select {
					case spansMeta = <-r.spansMetaCache:
					default:
						spansMeta = make([]int, spansBatchNum)
					}
					i = 0
					continue
				}
				i++
				continue
			} else {
				break
			}
		}

	}

	if i != 0 {
		r.spansMetaQueue <- spansMeta[:i]
	}

	close(r.spansMetaQueue)
}

func (r *Receiver) dropTraceById(traceId string, over string) {
	traceData, ok := r.idToTrace.Load(traceId)
	if !ok {
		logger.Info("drop traceId not exist", zap.String("traceId", traceId))
		return
	}
	r.dropTrace(traceId, traceData, over)
}

func (r *Receiver) dropTrace(traceId string, traceData *TraceData, over string) {
	wrong := traceData.IsErrorTrace
	if wrong && traceData.Status != TraceStatusSent {
		traceData.Status = TraceStatusSent
		r.overWg.Add(1)
		go r.SendWrongRequest(traceId, traceData, over)
		return
	} else {
		traceData.Status = TraceStatusDone
	}
}

func (r *Receiver) finish() {
	btime := time.Now()
	ftime := time.Second
	fwg := sync.WaitGroup{}
	fonce := sync.Once{}
	for i := 0; i < 2; i++ {
		fwg.Add(1)
		go func() {
			defer fwg.Done()
			<-r.finishSignal
			fonce.Do(func() {
				logger.Info("finish start")
				btime = time.Now()
			})
			for {
				select {
				case dropId := <-r.dropIdQueue:
					r.dropTraceById(dropId, "1")
				default:
					ftime = time.Since(btime)
					return
				}
			}

		}()
	}
	fwg.Wait()
	r.overWg.Wait()
	logger.Info("finish over",
		zap.Duration("finish cost", ftime),
		zap.Duration("total cost", time.Since(btime)),
		zap.Int64("traceNum", r.traceNums),
		zap.Int("maxSpLen", r.maxSpanNums),
		zap.Int("minSpanNums", r.minSpanNums),
		zap.Int("mapMaxSize", r.mapMaxSize),
		zap.Int64("cursorOnTraceDataCache", r.cursorOnTraceDataCache),
		zap.Int("traceMiss", r.traceMiss),
		zap.Int("traceSkip", r.traceSkip),
		zap.Int("wrongHit", r.wrongHit),
	)
	r.notifyFIN()
}
