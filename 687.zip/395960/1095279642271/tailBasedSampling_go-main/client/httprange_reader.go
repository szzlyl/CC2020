package client

import (
	"fmt"
	"go.uber.org/zap"
	"io"
	"net/http"
	"strconv"
	"sync"
)

type HttpRangeReader struct {
	Sequence       int
	HttpRangeStart int
	HttpRangeEnd   int
	BufferStart    int
	BufferEnd      int

	buffer       []byte // points to global spans buffer
	reader       io.Reader
	readSignal   chan interface{}
	exitRead     bool
	currentRead  int
	currentWrite int
	readBufSize  int
	error        error
	waitGroup    sync.WaitGroup
}

func (h *HttpRangeReader) asyncFill() {
	defer func() {
		h.waitGroup.Done()
	}()

	for {
		select {
		case <-h.readSignal:
			return
		default:
			var n int
			var error error
			n, error = h.reader.Read(h.buffer[h.currentWrite:])
			h.currentWrite += n
			if error != nil {
				h.error = error
				return
			}
			if n > 0 {
				continue
			}
		}
	}
}

func GenHttpRangeReaders(dataFileUrl string, bufSize int, stepSize int, readBufferSize int) []*HttpRangeReader {
	//Get length
	length, err := getLength(dataFileUrl)
	if err != nil {
		logger.Error("Error Getting Length",
			zap.Error(err),
		)
		return nil
	}

	logger.Info("Getting Length",
		zap.Int("length", length),
	)

	//Construct readers
	httpRangeReaders := make([]*HttpRangeReader, 0, length/stepSize+1)
	bufferStart := 0
	bufferEnd := 0
	httpRangeStart := 0
	httpRangeEnd := 0
	sequence := 0
	for {
		if httpRangeEnd == length {
			break
		}

		tmpStepSize := stepSize

		//Wrap around the tail and head
		if bufferEnd == bufSize {
			bufferStart = readBufSize
			bufferEnd = bufferStart + tmpStepSize
		} else {
			if bufferStart+tmpStepSize > bufSize {
				tmpStepSize = bufSize - bufferStart
				bufferEnd = bufSize
			} else {
				bufferEnd = bufferStart + tmpStepSize
			}
		}

		httpRangeEnd = httpRangeStart + tmpStepSize - 1
		if httpRangeEnd >= length {
			httpRangeEnd = length
		}

		reader, err := getHttpReader(dataFileUrl, httpRangeStart, httpRangeEnd)
		if err != nil {
			logger.Error("Error Getting Http Reader",
				zap.Error(err),
			)
			return nil
		}

		httpRangeReaders = append(httpRangeReaders, &HttpRangeReader{
			Sequence:       sequence,
			HttpRangeStart: httpRangeStart,
			HttpRangeEnd:   httpRangeEnd,
			BufferStart:    bufferStart,
			BufferEnd:      bufferEnd,
			reader:         reader,
			currentRead:    bufferStart,
			currentWrite:   bufferStart,
			readSignal:     make(chan interface{}),
		})
		bufferStart = bufferEnd
		httpRangeStart = httpRangeEnd + 1
		sequence++
	}
	return httpRangeReaders
}

func getLength(dataFileUrl string) (int, error) {
	client := &http.Client{}
	request, error := http.NewRequest("HEAD", dataFileUrl, nil)
	if error != nil {
		logger.Error("Http get error", zap.Error(error))
		return 0, error
	}
	request.Header.Add("Range", "bytes=0-")
	response, error := client.Do(request)
	if error != nil {
		logger.Error("Http request error", zap.Error(error))
		return 0, error
	}

	var length int
	switch response.StatusCode {
	case http.StatusPartialContent:
		contentLength := response.Header.Get("Content-Length")
		logger.Info("Http request error1", zap.String("string", contentLength))
		length64, _ := strconv.ParseInt(contentLength, 10, 0)
		length = int(length64)
		logger.Info("Http request error2", zap.Int("Int", length))
	default:
		length = 0
	}

	return length, nil
}

func getHttpReader(dataFileUrl string, start, end int) (io.Reader, error) {
	client := &http.Client{}
	request, error := http.NewRequest("GET", dataFileUrl, nil)
	if error != nil {
		logger.Error("Error on New HTTP Request",
			zap.Error(error),
		)
		return nil, error
	}

	request.Header.Add("Range", fmt.Sprintf("bytes=%d-%d", start, end))
	response, error := client.Do(request)
	if error != nil {
		return nil, error
	}
	return response.Body, nil
}
