package client

import (
	"fmt"
	"github.com/buaazp/fasthttprouter"
	"github.com/larrydpk/tailBasedSampling_go/common"
	"github.com/valyala/fasthttp"
	"go.uber.org/zap"
	"net/http"
	"sync"
	"sync/atomic"
	"time"
)

var (
	fastHttpClient = &fasthttp.Client{
		MaxConnsPerHost:     10000,
		MaxIdleConnDuration: 5 * time.Second,
		ReadTimeout:         500 * time.Millisecond,
		WriteTimeout:        500 * time.Millisecond,
	}
)

func (r *Receiver) RunHttpServer() {
	fastHttpRouter := fasthttprouter.New()

	fastHttpRouter.GET("/ready", func(ctx *fasthttp.RequestCtx) {
		wg := sync.WaitGroup{}
		for i := 0; i < 500; i++ {
			go r.warmUp(wg)
		}
		wg.Wait()
		ctx.SetStatusCode(http.StatusOK)
	})
	fastHttpRouter.GET("/warmup", func(ctx *fasthttp.RequestCtx) {
		time.Sleep(1 * time.Millisecond)
		ctx.SetStatusCode(http.StatusOK)
	})
	fastHttpRouter.GET("/setParameter", r.SetParamHandler)
	fastHttpRouter.GET("/qw", r.QueryWrongHandler)

	if err := fasthttp.ListenAndServe(fmt.Sprintf(":%s", r.HttpPort), fastHttpRouter.Handler); err != nil {
		logger.Info("currentRead.HttpPort fail", zap.Error(err))
	}
}

func (r *Receiver) SetParamHandler(ctx *fasthttp.RequestCtx) {
	port := string(ctx.QueryArgs().Peek("port"))

	if r.DataPort != "" {
		logger.Info("SetParamHandler already has",
			zap.String("port", r.HttpPort),
			zap.String("set", r.DataPort),
		)
		ctx.SetStatusCode(http.StatusOK)
		return
	}

	r.DataPort = port
	logger.Info("SetParamHandler",
		zap.String("port", r.HttpPort),
		zap.String("set", r.DataPort),
	)
	go r.notifyDataPort()

	if r.HttpPort == "8000" {
		dataUrl := fmt.Sprintf("http://127.0.0.1:%s/trace1.data", r.DataPort)
		go r.Read(dataUrl)
	}

	if r.HttpPort == "8001" {
		dataUrl2 := fmt.Sprintf("http://127.0.0.1:%s/trace2.data", r.DataPort)
		go r.Read(dataUrl2)
	}

	ctx.SetStatusCode(http.StatusOK)
	return
}

func (r *Receiver) notifyDataPort() {
	notifyUrl := fmt.Sprintf("http://127.0.0.1:%s/setParameter?port=%s&hport=%s", r.CollectorPort, r.DataPort, r.HttpPort)

	request := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(request)

	request.SetRequestURI(notifyUrl)
	request.Header.SetMethod("GET")

	response := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(response)

	if error := fastHttpClient.Do(request, response); error != nil {
		logger.Info("send setParameter to backend",
			zap.Error(error),
		)
		return
	}
	if response.StatusCode() != fasthttp.StatusOK {
		logger.Info("send setParameter to backend",
			zap.Int("code", response.StatusCode()),
		)
		return
	}
}

func (r *Receiver) QueryWrongHandler(ctx *fasthttp.RequestCtx) {
	traceId := string(ctx.QueryArgs().Peek("id"))
	over := string(ctx.QueryArgs().Peek("over"))
	var traceData *TraceData
	if nowPosition := atomic.AddInt64(&r.cursorOnTraceDataCache, 1); nowPosition < traceDataCacheLimit {
		traceData = traceDataCache[nowPosition]
	} else {
		traceData = NewTraceData()
	}
	traceData.IsErrorTrace = true
	traceData.Status = TraceStatusErrorSet
	existingTraceData, exist := r.idToTrace.LoadOrStore(traceId, traceData)
	if exist {
		existingTraceData.IsErrorTrace = true
		if existingTraceData.Status == TraceStatusDone {
			existingTraceData.Status = TraceStatusSent
			r.overWg.Add(1)
			if over == "1" {
				r.SendWrongRequest(traceId, existingTraceData, "")
			} else {
				go r.SendWrongRequest(traceId, existingTraceData, "")
			}
		}
	}
	ctx.SetStatusCode(http.StatusOK)
	return
}

func (r *Receiver) SendWrongRequest(traceId string, traceData *TraceData, over string) {
	defer r.overWg.Done()

	traceDataProtobuf := &common.TraceData{
		Id:     traceId,
		Source: r.HttpPort,
		Sb:     make([][]byte, len(traceData.Spans)),
	}
	for i, val := range traceData.Spans {
		start := val >> 16
		llen := val & 0xffff
		traceDataProtobuf.Sb[i] = spansBuffer[start : start+llen]
	}

	b, _ := traceDataProtobuf.Marshal()
	req := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(req)

	req.SetRequestURI(r.CollectorSetWrongUrl + fmt.Sprintf("?over=%s", over))
	req.Header.SetMethod("POST")
	req.Header.SetContentType("application/json")
	req.SetBody(b)

	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)

	//return
	if err := fastHttpClient.Do(req, resp); err != nil {
		fmt.Printf("set wrong fail traceId[%v] error[%v] \n", traceId, err)
		return
	}
	if resp.StatusCode() != fasthttp.StatusOK {
		fmt.Printf("set wrong fail[%v] code[%v]\n", traceId, resp.StatusCode())
		return
	}

}

func (r *Receiver) notifyFIN() {
	notifyUrl := fmt.Sprintf("http://127.0.0.1:%s/finish?port=%s", r.CollectorPort, r.HttpPort)

	request := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(request)

	request.SetRequestURI(notifyUrl)
	request.Header.SetMethod("GET")

	response := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(response)

	if error := fastHttpClient.Do(request, response); error != nil {
		logger.Info("send notify fin",
			zap.Error(error),
		)
		return
	}
	if response.StatusCode() != fasthttp.StatusOK {
		logger.Info("send notify fin",
			zap.Int("code", response.StatusCode()),
		)
		return
	}
}

func (r *Receiver) warmUp(wg sync.WaitGroup) {
	wg.Add(1)
	defer wg.Done()
	notifyUrl := fmt.Sprintf("http://127.0.0.1:%s/warmup?port=%s", r.CollectorPort, r.HttpPort)

	request := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(request)

	request.SetRequestURI(notifyUrl)
	request.Header.SetMethod("GET")

	response := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(response)

	if error := fastHttpClient.Do(request, response); error != nil {
		logger.Info("send warm up",
			zap.Error(error),
		)
		return
	}
	if response.StatusCode() != fasthttp.StatusOK {
		logger.Info("send notify fin",
			zap.Int("code", response.StatusCode()),
		)
		return
	}
}
