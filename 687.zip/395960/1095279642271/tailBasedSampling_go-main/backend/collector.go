package backend

import (
	"crypto/md5"
	"encoding/hex"
	"fmt"
	"github.com/buaazp/fasthttprouter"
	"github.com/larrydpk/tailBasedSampling_go/common"
	"github.com/valyala/fasthttp"
	"go.uber.org/zap"
	"net/http"
	"os"
	"sort"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type Collector struct {
	HttpPort  string // 8003
	DataPort  string // 8081
	ReportUrl string
	logger    *zap.Logger

	finishChan  chan interface{}
	checkSumMap map[string]string
	closeTimes  int64
	doneWg      sync.WaitGroup
	idToTrace   sync.Map
	startTime   time.Time
}

var (
	fastHttpClient = &fasthttp.Client{
		MaxConnsPerHost:     10000,
		MaxIdleConnDuration: 5 * time.Second,
		ReadTimeout:         500 * time.Millisecond,
		WriteTimeout:        500 * time.Millisecond,
	}
)

func (c *Collector) Run() {
	c.logger, _ = zap.NewProduction()
	defer c.logger.Sync()
	go func() {
		i := 0
		for {
			if i > 2 {
				c.logger.Info("too long to stop")
				close(c.finishChan)
				c.finish()
			}
			if i > 3 {
				os.Exit(-1)
			}

			i++
			c.logger.Info("sleep",
				zap.String("port", c.HttpPort),
				zap.Int("i", i),
			)
			time.Sleep(1 * time.Minute)
		}
	}()

	c.finishChan = make(chan interface{})
	c.checkSumMap = make(map[string]string)
	go c.finish()

	fastHttpRouter := fasthttprouter.New()
	fastHttpRouter.GET("/ready", func(ctx *fasthttp.RequestCtx) {
		wg := sync.WaitGroup{}
		for i := 0; i < 500; i++ {
			go WarmUp("8000", wg)
		}
		for i := 0; i < 500; i++ {
			go WarmUp("8001", wg)
		}
		wg.Wait()
		ctx.SetStatusCode(http.StatusOK)
	})
	fastHttpRouter.GET("/warmup", func(ctx *fasthttp.RequestCtx) {
		time.Sleep(1 * time.Millisecond)
		ctx.SetStatusCode(http.StatusOK)
	})
	fastHttpRouter.GET("/setParameter", c.SetParamHandler)
	fastHttpRouter.POST("/setWrong", c.SetWrongHandler)
	fastHttpRouter.GET("/finish", c.NotifyFinishHandler)

	if err := fasthttp.ListenAndServe(fmt.Sprintf(":%s", c.HttpPort), fastHttpRouter.Handler); err != nil {
		c.logger.Info("c.HttpPort fail", zap.Error(err))
	}
}

func (c *Collector) SetParamHandler(ctx *fasthttp.RequestCtx) {
	port := string(ctx.QueryArgs().Peek("port"))
	hport := string(ctx.QueryArgs().Peek("hport"))
	c.DataPort = port

	if hport != "" {
		anotherPort := "8000"
		if hport == "8000" {
			anotherPort = "8001"
		}
		c.notifyDataPort(anotherPort)
	}
	c.ReportUrl = fmt.Sprintf("http://127.0.0.1:%s/api/finished", c.DataPort)
	c.startTime = time.Now()
	c.logger.Info("SetParamHandler",
		zap.String("port", c.HttpPort),
		zap.String("set", c.DataPort),
	)

	ctx.SetStatusCode(http.StatusOK)
	return
}

func (c *Collector) notifyDataPort(httpPort string) {
	notifyUrl := fmt.Sprintf("http://127.0.0.1:%s/setParameter?port=%s", httpPort, c.DataPort)

	req := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(req)

	req.SetRequestURI(notifyUrl)
	req.Header.SetMethod("GET")

	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)

	if err := fastHttpClient.Do(req, resp); err != nil {
		c.logger.Info("send setParameter to another",
			zap.Error(err),
		)
		return
	}
	if resp.StatusCode() != fasthttp.StatusOK {
		c.logger.Info("send setParameter to another",
			zap.Int("code", resp.StatusCode()),
		)
		return
	}
}

func (c *Collector) SetWrongHandler(ctx *fasthttp.RequestCtx) {
	over := string(ctx.QueryArgs().Peek("over"))
	td := &common.TraceData{}
	body := ctx.PostBody()
	err := td.Unmarshal(body)
	if err != nil {
		c.logger.Info("td Unmarshal fail", zap.Error(err))
		ctx.SetStatusCode(http.StatusBadRequest)
		return
	}

	tdi, exist := c.idToTrace.LoadOrStore(td.Id, td)
	if !exist {
		// notify another
		anotherPort := "8000"
		if td.Source == "8000" {
			anotherPort = "8001"
		}
		reportUrl := fmt.Sprintf("http://127.0.0.1:%s/qw?id=%s&over=%s", anotherPort, td.Id, over)
		c.doneWg.Add(1)
		if over == "1" {
			NotifyAnotherWrong(reportUrl, &c.doneWg)
		} else {
			go NotifyAnotherWrong(reportUrl, &c.doneWg)
		}
	} else {
		otd := tdi.(*common.TraceData)
		if otd.Md5 != "" {
			c.logger.Info("md5 already exist ", zap.String("id", otd.Id))
			ctx.SetStatusCode(http.StatusOK)
			return
		}
		if otd.Source == td.Source {
			c.logger.Info("source already exist ", zap.String("id", otd.Id))
			ctx.SetStatusCode(http.StatusOK)
			return
		}

		otd.AddSpan(td.Sb)
		otd.Md5 = CompactMd5(otd, nil)
	}
	ctx.SetStatusCode(http.StatusOK)
	return
}

func (c *Collector) NotifyFinishHandler(ctx *fasthttp.RequestCtx) {
	port := string(ctx.QueryArgs().Peek("port"))
	c.logger.Info("got notify fin ", zap.String("port", port))
	times := atomic.AddInt64(&c.closeTimes, 1)
	if times == 2 {
		close(c.finishChan)
	}
	return
}

func (c *Collector) finish() {
	<-c.finishChan
	btime := time.Now()
	c.doneWg.Wait()
	doneWaitTime := time.Since(btime)
	btime = time.Now()
	sb := strings.Builder{}
	sb.WriteString("result={")
	start := true
	i := 0
	calTimes := 0
	c.idToTrace.Range(func(key, value interface{}) bool {
		i++
		td := value.(*common.TraceData)
		if td.Md5 == "" {
			calTimes++
			td.Md5 = CompactMd5(td, nil)
		}
		if !start {
			sb.WriteString(",\"")
		} else {
			sb.WriteString("\"")
			start = false
		}
		sb.WriteString(td.Id)
		sb.WriteString("\":\"")
		sb.WriteString(td.Md5)
		sb.WriteString("\"")
		return true
	})
	c.logger.Info("gen checksum",
		zap.Int("len", i),
		zap.Int("calTimes", calTimes),
		zap.Duration("wait", doneWaitTime),
		zap.Duration("cost", time.Since(btime)),
	)

	sb.WriteString("}")
	btime = time.Now()
	//c.logger.Info(sb.String())
	ReportCheckSumString(sb.String(), c.ReportUrl)
	c.logger.Info("report checksum",
		zap.Int("len", i),
		zap.Duration("cost", time.Since(btime)),
		zap.Duration("total cost", time.Since(c.startTime)),
	)
	return
}

func CompactMd5(td *common.TraceData, wg *sync.WaitGroup) string {
	if wg != nil {
		defer wg.Done()
	}

	spans := common.Spans{}
	for _, sb := range td.Sb {
		spans = append(spans, ParseSpanData(sb))
	}
	sort.Sort(spans)
	h := md5.New()
	for _, span := range spans {
		h.Write(span.Tags)

	}
	return strings.ToUpper(hex.EncodeToString(h.Sum(nil)))
}

func ParseSpanData(line []byte) *common.SpanData {
	spanData := &common.SpanData{}
	l := common.BytesToString(line)
	firstIdx := strings.IndexByte(l, '|')
	secondIdx := strings.IndexByte(l[firstIdx+1:], '|')
	spanData.StartTime = l[firstIdx+1 : firstIdx+1+secondIdx]
	spanData.Tags = line
	return spanData
}

func WarmUp(port string, wg sync.WaitGroup) {
	wg.Add(1)
	defer wg.Done()
	notifyUrl := fmt.Sprintf("http://127.0.0.1:%s/warmup", port)

	req := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(req)

	req.SetRequestURI(notifyUrl)
	req.Header.SetMethod("GET")

	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)

	if err := fastHttpClient.Do(req, resp); err != nil {
		return
	}
	if resp.StatusCode() != fasthttp.StatusOK {
		return
	}
}

func NotifyAnotherWrong(reqUrl string, wg *sync.WaitGroup) {
	defer wg.Done()
	req := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(req)

	req.SetRequestURI(reqUrl)
	req.Header.SetMethod("GET")
	req.Header.SetContentType("application/json")

	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)

	if err := fastHttpClient.Do(req, resp); err != nil {
		fmt.Printf("notify wrong fail reqUrl[%v] err[%v] \n", reqUrl, err)
		return
	}
	if resp.StatusCode() != fasthttp.StatusOK {
		fmt.Printf("notify wrong fail reqUrl[%v] code[%v]\n", reqUrl, resp.StatusCode())
		return
	}
}

func ReportCheckSumString(checkSumMap string, reqUrl string) {
	req := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(req)

	req.SetRequestURI(reqUrl)
	req.Header.SetMethod("POST")
	req.SetBodyString(checkSumMap)

	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)

	if err := fastHttpClient.Do(req, resp); err != nil {
		fmt.Printf("report checkSum fail reqUrl[%v] err[%v] \n", reqUrl, err)
		return
	}
	if resp.StatusCode() != fasthttp.StatusOK {
		fmt.Printf("report checkSum fail reqUrl[%v] code[%v]\n", reqUrl, resp.StatusCode())
		return
	}
}
