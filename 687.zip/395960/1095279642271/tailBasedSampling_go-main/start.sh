#!/usr/bin/env bash

/usr/local/src/main -p=$SERVER_PORT