package entity

import (
	"math"
)

// FreeKey is the 'free' key
const FreeKey = 0

type Map struct {
	data      []int64
	factor    float64
	threshold int
	size      int

	mask  int64 // 掩码
	mask2 int64

	hasFreeKey bool
	freeVal    int64
}

func nextPowerOf2(x uint32) uint32 {
	if x == math.MaxUint32 {
		return x
	}

	if x == 0 {
		return 1
	}

	x--
	x |= x >> 1
	x |= x >> 2
	x |= x >> 4
	x |= x >> 8
	x |= x >> 16

	return x + 1
}

func arraySize(exp int, fill float64) int {
	s := nextPowerOf2(uint32(math.Ceil(float64(exp) / fill)))
	if s < 2 {
		s = 2
	}
	return int(s)
}

func New(size int, factor float64) *Map {
	if factor <= 0 || factor >= 1 {
		panic("扩容因子 必须介于 (0, 1)")
	}
	if size <= 0 {
		panic("必须正数")
	}

	capacity := arraySize(size, factor)
	return &Map{
		data:      make([]int64, 2*capacity),
		factor:    factor,
		threshold: int(math.Floor(float64(capacity) * factor)),
		mask:      int64(capacity - 1),
		mask2:     int64(2*capacity - 1),
	}
}

func (m *Map) Get(key int64) (int64, bool) {
	ptr := (key & m.mask) << 1
	if ptr < 0 || ptr >= int64(len(m.data)) { // Check to help to compiler to eliminate a bounds check below.
		return 0, false
	}
	k := m.data[ptr]

	if k == FreeKey {
		return 0, false
	}
	if k == key {
		return m.data[ptr+1], true
	}

	for {
		ptr = (ptr + 2) & m.mask2
		k = m.data[ptr]
		if k == FreeKey {
			return 0, false
		}
		if k == key {
			return m.data[ptr+1], true
		}
	}
}

func (m *Map) Put(key int64, val int64) {
	ptr := (key & m.mask) << 1
	k := m.data[ptr]

	if k == FreeKey {
		m.data[ptr] = key
		m.data[ptr+1] = val
		if m.size >= m.threshold {
			m.rehash()
		} else {
			m.size++
		}
		return
	} else if k == key {
		m.data[ptr+1] = val
		return
	}

	for {
		ptr = (ptr + 2) & m.mask2
		k = m.data[ptr]

		if k == FreeKey {
			m.data[ptr] = key
			m.data[ptr+1] = val
			if m.size >= m.threshold {
				m.rehash()
			} else {
				m.size++
			}
			return
		} else if k == key {
			m.data[ptr+1] = val
			return
		}
	}

}

func (m *Map) Del(key int64) {
	ptr := (key & m.mask) << 1
	k := m.data[ptr]

	if k == key {
		m.shiftKeys(ptr)
		m.size--
		return
	} else if k == FreeKey { // end of chain already
		return
	}

	for {
		ptr = (ptr + 2) & m.mask2
		k = m.data[ptr]

		if k == key {
			m.shiftKeys(ptr)
			m.size--
			return
		} else if k == FreeKey {
			return
		}

	}
}

func (m *Map) shiftKeys(pos int64) int64 {
	var last, slot int64
	var k int64
	var data = m.data
	for {
		last = pos
		pos = (last + 2) & m.mask2
		for {
			k = data[pos]
			if k == FreeKey {
				data[last] = FreeKey
				return last
			}

			slot = (k & m.mask) << 1
			if last <= pos {
				if last >= slot || slot > pos {
					break
				}
			} else {
				if last >= slot && slot > pos {
					break
				}
			}
			pos = (pos + 2) & m.mask2
		}
		data[last] = k
		data[last+1] = data[pos+1]
	}
}

// 扩容
func (m *Map) rehash() {
	newCapacity := len(m.data) * 2
	m.threshold = int(math.Floor(float64(newCapacity/2) * m.factor))
	m.mask = int64(newCapacity/2 - 1)
	m.mask2 = int64(newCapacity - 1)

	data := make([]int64, len(m.data))
	copy(data, m.data)

	m.data = make([]int64, newCapacity)
	if m.hasFreeKey {
		m.size = 1
	} else {
		m.size = 0
	}

	var o int64
	for i := 0; i < len(data); i += 2 {
		o = data[i]
		if o != FreeKey {
			m.Put(o, data[i+1])
		}
	}
}

func (m *Map) Size() int {
	return m.size
}
