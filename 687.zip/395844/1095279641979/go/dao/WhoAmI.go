package dao

import (
	"log"
	"sync"
)

var whoAmI *WhoAmI

var MyPort string
var onceNodeInfo sync.Once
var IsPeerComplete bool = false

const IsCollector = "collector"
const IsFilter = "filter"

type WhoAmI struct {
	MyServerPort   string
	PeerServerPort string
	ParameterPort  string
}

func (ni *WhoAmI) GetRole() string {
	if ni.MyServerPort == "8002" {
		return IsCollector
	}
	return IsFilter
}

func (ni *WhoAmI) GetDataFileUrl() string {
	if ni.MyServerPort == "8000" {
		return "http://localhost:" + ni.ParameterPort + "/trace1.data"
	} else if ni.MyServerPort == "8001" {
		return "http://localhost:" + ni.ParameterPort + "/trace2.data"
	} else {
		log.Fatal("获取不到数据 ", ni.MyServerPort)
		return ""
	}
}

func (ni *WhoAmI) GetLocalDataFileUrl() string {
	if ni.MyServerPort == "8000" {
		return "C:/Users/xuyuanna/Desktop/4000/trace1.data"
	} else if ni.MyServerPort == "8001" {
		return "C:/Users/xuyuanna/Desktop/4000/trace2.data"
	}
	return ""
}

func (ni *WhoAmI) GetCollectorUrl() string {
	return "http://localhost:8002"
}

func GetWhoAmI() *WhoAmI {
	onceNodeInfo.Do(func() {
		whoAmI = newWhoAmI()
	})
	return whoAmI
}

func newWhoAmI() *WhoAmI {
	var whoAmI WhoAmI
	whoAmI.MyServerPort = MyPort
	if "8000" == whoAmI.MyServerPort {
		whoAmI.PeerServerPort = "8001"
	} else {
		whoAmI.PeerServerPort = "8000"
	}
	return &whoAmI
}
