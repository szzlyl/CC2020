package dao

import (
	"io"
	"net"
	"strings"
	"sync"
)

var Connection8003 []net.Conn

var ErrorTraceId = make([][]string, 2)
var ErrorTraceIdMutex = make([]sync.Mutex, 2)

const ShortTraceIdLen = 9

//perf 500000 will be faster but more dangerous
const TraceCount = 400000

type FilterTraceItem struct {
	Iid            int64
	firstStartLine int
	HasError       ERRORTYPE
	Spans          []string
	IsFixed        bool
	Pos            int
}

type CollectorTraceManager struct {
	ErrorTraces            map[string]*TraceItem
	result                 strings.Builder
	CollectorManagerRWLock sync.RWMutex
}

type TraceScannerForCollector struct {
	r            io.Reader
	split        SplitFunction
	maxTokenSize int
	token        []byte
	buf          []byte
	start        int
	end          int
	err          error
	empties      int
	scanCalled   bool
	done         bool
}

type SplitFunction func(data []byte, atEOF bool) (advance int, token []byte, err error)
