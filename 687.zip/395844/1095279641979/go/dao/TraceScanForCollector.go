package dao

import (
	"errors"
	"io"
	"unsafe"
)

func (s *TraceScannerForCollector) Err() error {
	if s.err == io.EOF {
		return nil
	}
	return s.err
}

func (s *TraceScannerForCollector) Bytes() []byte {
	return s.token
}

func (s *TraceScannerForCollector) Text() string {
	return *(*string)(unsafe.Pointer(&s.token))
}

var ErrFinalToken = errors.New("最后一个token")

const readSize = 1 * 1024 * 1024

func (s *TraceScannerForCollector) Scan() bool {
	if s.done {
		return false
	}
	s.scanCalled = true
	for {
		if s.end > s.start || s.err != nil {
			advance, token, err := s.split(s.buf[s.start:s.end], s.err != nil)
			if err != nil {
				if err == ErrFinalToken {
					s.token = token
					s.done = true
					return true
				}
				s.setErr(err)
				return false
			}
			if !s.advance(advance) {
				return false
			}
			s.token = token
			if token != nil {
				if s.err == nil || advance > 0 {
					s.empties = 0
				} else {
					s.empties++
					if s.empties > 100 {
						panic("太多空的token")
					}
				}
				return true
			}
		}
		// 关闭
		if s.err != nil {
			s.start = 0
			s.end = 0
			return false
		}
		if s.start > 0 && (len(s.buf)-s.end <= readSize) {
			copy(s.buf, s.buf[s.start:s.end])
			s.end -= s.start
			s.start = 0

		}

		for loop := 0; ; {
			endPos := s.end + readSize
			if endPos > len(s.buf) {
				endPos = len(s.buf)
			}
			n, err := s.r.Read(s.buf[s.end:endPos])
			s.end += n
			if err != nil {
				s.setErr(err)
				break
			}
			if n > 0 {
				s.empties = 0
				break
			}
			loop++
			if loop > 100 {
				s.setErr(io.ErrNoProgress)
				break
			}
		}
	}
}

func (s *TraceScannerForCollector) advance(n int) bool {
	s.start += n
	return true
}

func (s *TraceScannerForCollector) setErr(err error) {
	if s.err == nil || s.err == io.EOF {
		s.err = err
	}
}

func (s *TraceScannerForCollector) Buffer(buf []byte, max int) {
	if s.scanCalled {
		panic("扫描后缓存")
	}
	s.buf = buf[0:max]
	s.maxTokenSize = max
}

func (s *TraceScannerForCollector) Split(split SplitFunction) {
	if s.scanCalled {
		panic("扫描后切割")
	}
	s.split = split
}
