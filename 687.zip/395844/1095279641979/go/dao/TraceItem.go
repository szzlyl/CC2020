package dao

import (
	"sort"
	"strings"
	"sync"
	"trace/util"
)

type SpanItems []*SpanItem
type ERRORTYPE int32

const NoErr ERRORTYPE = 0
const Err ERRORTYPE = 1

type TraceItem struct {
	TraceId        string
	firstStartLine int
	HasError       ERRORTYPE
	Spans          SpanItems
	SpanTimes      map[uint64]int
	HashString     string
	mutex          sync.Mutex
}

func (trace *TraceItem) Hash() string {
	trace.Sort()
	var sb strings.Builder
	sb.Grow(32 * 1024)
	for _, si := range trace.Spans {
		sb.WriteString(si.Line)
		sb.WriteString("\n")
	}
	trace.HashString = util.GetMD5Hash(sb.String())
	return trace.HashString
}

func (s SpanItems) Len() int {
	return len(s)
}

func (s SpanItems) Less(i, j int) bool {
	return s[i].StartTime < s[j].StartTime
}

func (s SpanItems) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}

func (trace *TraceItem) AddSpan(span *SpanItem) {
	trace.mutex.Lock()
	_, found := trace.SpanTimes[span.StartTime]
	if found {
		trace.mutex.Unlock()
		return
	}
	trace.Spans = append(trace.Spans, span)
	trace.SpanTimes[span.StartTime] = 0
	trace.mutex.Unlock()
}

func (trace *TraceItem) Sort() {
	sort.Sort(trace.Spans)
}
