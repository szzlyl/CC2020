package dao

import (
	"strings"
	"sync"
	"trace/entity"
	"trace/util"
)

const IntMax = int(^uint(0) >> 1)

var m *FilterTraceManager
var FilterTraceManagers [2]*FilterTraceManager

var onceFilterTraceManager sync.Once

const TraceMustInLine int = 20001

type FilterTraceManager struct {
	Traces *entity.Map

	errorTraceIdInfoByCollector *entity.Map
	TraceQueue                  []*FilterTraceItem
	traceCount                  int
	Tid                         int
	badTraceReportUrl           string
	AllTraces                   [TraceCount]*FilterTraceItem
	currentIndexInAllTrace      int
	B                           strings.Builder
}

func (manager *FilterTraceManager) AddLine(line string, linenum int, errorType ERRORTYPE) {

	traceId := line[0:ShortTraceIdLen]
	iid := util.Str2Uint64(traceId)
	index, ok := manager.Traces.Get(iid)
	if ok {
		tmpTrace := manager.AllTraces[index]

		tmpTrace.HasError |= errorType

		length := len(tmpTrace.Spans)
		if tmpTrace.Pos >= length {
			var newspan = make([]string, length*2, length*2)
			copy(newspan, tmpTrace.Spans)
			tmpTrace.Spans = newspan
		}
		tmpTrace.Spans[tmpTrace.Pos] = line
		tmpTrace.Pos++
	} else {

		ti := manager.AllTraces[manager.currentIndexInAllTrace]
		ti.Iid = iid
		ti.firstStartLine = linenum
		ti.IsFixed = false
		ti.HasError = errorType
		ti.Spans[0] = line
		ti.Pos = 1

		_, found := manager.errorTraceIdInfoByCollector.Get(iid)
		if found {
			ti.HasError = Err
		}

		manager.Traces.Put(int64(iid), int64(manager.currentIndexInAllTrace))

		manager.TraceQueue = append(manager.TraceQueue, ti)

		manager.currentIndexInAllTrace++
		if manager.currentIndexInAllTrace >= TraceCount {
			manager.currentIndexInAllTrace = 0
		}
	}
}

func (manager *FilterTraceManager) CheckFixedTrace(currentLine int) {
	for {
		if len(manager.TraceQueue) == 0 {
			break
		}

		traceItem := manager.TraceQueue[0]

		if currentLine-traceItem.firstStartLine <= TraceMustInLine {
			break
		}
		manager.TraceQueue = manager.TraceQueue[1:]
		traceItem.IsFixed = true

		if traceItem.HasError == Err {
			traceItem.toStringBuilder(&manager.B, "o\n")
			manager.Traces.Del(traceItem.Iid)
		}
	}
}

func (manager *FilterTraceManager) FlagAsErrorSync(traceId string) {

	iid := util.Str2Uint64(traceId)
	index, ok := manager.Traces.Get(int64(iid))
	if !ok {
		manager.errorTraceIdInfoByCollector.Put(iid, 1)
		return
	}
	tmpTrace := manager.AllTraces[index]
	tmpTrace.flagAsError()

	if tmpTrace.IsFixed {
		tmpTrace.toStringBuilder(&manager.B, "o\n")
		manager.Traces.Del(int64(iid))
	}
}

func NewFilterTraceManager(tid int) *FilterTraceManager {
	var manager FilterTraceManager
	manager.Traces = entity.New(1000000, 0.6)
	manager.errorTraceIdInfoByCollector = entity.New(30000, 0.6)

	manager.TraceQueue = make([]*FilterTraceItem, 0, 1000000)
	manager.Tid = tid

	for i := 0; i < TraceCount; i++ {
		var ti FilterTraceItem
		ti.Spans = make([]string, 64, 64)
		manager.AllTraces[i] = &ti
	}

	return &manager
}

func (trace *FilterTraceItem) flagAsError() {
	trace.HasError = Err
}

func (trace *FilterTraceItem) toStringBuilder(b *strings.Builder, suffix1 string) {
	for i := 0; i < trace.Pos; i++ {
		b.WriteString(trace.Spans[i])
		b.WriteString("\n")
	}
	b.WriteString(suffix1)
}
