package dao

import (
	"strconv"
	"strings"
)

type SpanItem struct {
	TraceId   string
	StartTime uint64
	Line      string
	HasError  ERRORTYPE
}

func NewSpanItemTraceIdAndStartTime(line string) SpanItem {
	var si SpanItem
	si.Line = line
	var loc int
	si.TraceId, loc = getTraceId(line)
	si.StartTime, _ = strconv.ParseUint(getStartTime(line[loc+1:]), 10, 64)
	return si
}

func getTraceId(line string) (string, int) {
	i := strings.IndexByte(line, '|')
	return line[0:i], i
}

func getStartTime(line string) string {
	return line[0:16]
}
