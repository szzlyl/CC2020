package dao

import (
	"strings"
	"sync"
)

var cm *CollectorTraceManager
var onceCollectorTraceManager sync.Once

func GetCollectorTraceManager() *CollectorTraceManager {
	onceCollectorTraceManager.Do(func() {
		cm = newCollectorTraceManager()
	})
	return cm
}

func newCollectorTraceManager() *CollectorTraceManager {
	var manager CollectorTraceManager
	manager.ErrorTraces = make(map[string]*TraceItem, 30000)
	manager.result.Grow(1000 * 1024)
	manager.result.WriteString("{")
	//manager.CompleteTraceIds = make(map[string]string,10000)
	return &manager
}

func (manager *CollectorTraceManager) Add(span *SpanItem) *TraceItem {
	manager.CollectorManagerRWLock.Lock()
	defer manager.CollectorManagerRWLock.Unlock()

	tmpTrace, found := manager.ErrorTraces[span.TraceId]

	if found {
		tmpTrace.AddSpan(span)
		return tmpTrace
	} else {
		var ti TraceItem
		ti.TraceId = span.TraceId
		ti.Spans = make([]*SpanItem, 0, 32)
		ti.SpanTimes = make(map[uint64]int, 32)
		ti.AddSpan(span)
		manager.ErrorTraces[span.TraceId] = &ti
		return &ti
	}

}
func (manager *CollectorTraceManager) CalculateTrace(traceId string) {
	manager.CollectorManagerRWLock.RLock()
	trace, found := manager.ErrorTraces[traceId]
	manager.CollectorManagerRWLock.RUnlock()
	if !found {
		return
	}

	if trace.HashString == "" {
		trace.Hash()
	} else {
		trace.HashString = ""
	}
}

func (manager *CollectorTraceManager) ClearHash(traceId string) {
	manager.CollectorManagerRWLock.Lock()
	trace, found := manager.ErrorTraces[traceId]
	if found {
		trace.HashString = ""
	}
	manager.CollectorManagerRWLock.Unlock()
}

func (manager *CollectorTraceManager) CalculateResult() string {
	var json strings.Builder
	json.Grow(1000 * 1024)
	json.WriteString("{")
	manager.CollectorManagerRWLock.Lock()
	i := 0
	for _, traceItem := range manager.ErrorTraces {
		i++
		if i > 1 {
			json.WriteString(",")
		}
		json.WriteString("\"")
		json.WriteString(traceItem.TraceId)
		json.WriteString("\":")
		json.WriteString("\"")
		if traceItem.HashString == "" {
			json.WriteString(traceItem.Hash())
		} else {
			json.WriteString(traceItem.HashString)
		}
		json.WriteString("\"")
	}

	json.WriteString("}")
	manager.CollectorManagerRWLock.Unlock()
	return json.String()
}
