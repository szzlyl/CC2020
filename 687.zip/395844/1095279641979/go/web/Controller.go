package web

import (
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"sync"
	"time"
	"trace/dao"
	"trace/service"
	"trace/util"
)

var syncMutex sync.Mutex
var finishCount int = 0
var readytoreadCount int32 = 0
var readytoreadCount_lock sync.Mutex
var isReady bool = false

func SetParameterWeb(writer http.ResponseWriter, request *http.Request) {

	port := request.URL.Query().Get("port")
	log.Println("setParameter ,port is  ", port)
	nodeInfo := dao.GetWhoAmI()
	nodeInfo.ParameterPort = port
	if nodeInfo.GetRole() == dao.IsCollector {
		writer.WriteHeader(200)
		return
	}

	//客户端处理开始
	service.FilterAfterSetParameterSingleThread(nodeInfo)

	writer.WriteHeader(200)
}

func getLastPart(url string) string {
	i := strings.LastIndex(url, "/")
	return url[i+1:]
}

func GetLastTwoPart(url string) (string, string) {
	i := strings.LastIndex(url, "/")
	j := strings.LastIndex(url[0:i], "/")
	last := url[i+1:]
	lastTwo := url[j+1 : i]
	return lastTwo, last
}

func ReadyToReadWeb(w http.ResponseWriter, request *http.Request) {
	if dao.GetWhoAmI().GetRole() == dao.IsFilter {
		//filter
		service.IsReadyToReadStream = true
	} else {
		// 收集器
		readytoreadCount_lock.Lock()
		defer readytoreadCount_lock.Unlock()
		readytoreadCount++
		if readytoreadCount == 2 {
			r, e := util.HttpClient.Get("http://localhost:8000/readytoread")

			if e == nil {
				r.Body.Close()
			}
			r, e = util.HttpClient.Get("http://localhost:8001/readytoread")
			r.Body.Close()
			if e == nil {
				r.Body.Close()
			}
		}
	}
	w.WriteHeader(200)
}

func CompletedWeb(w http.ResponseWriter, request *http.Request) {
	dao.IsPeerComplete = true
	w.WriteHeader(200)
}

func ReadyWeb(writer http.ResponseWriter, request *http.Request) {
	if isReady {
		writer.WriteHeader(200)
	} else {
		writer.WriteHeader(404)
	}
}

func YoucangoWeb(w http.ResponseWriter, request *http.Request) {
	var err error
	if dao.GetWhoAmI().GetRole() == dao.IsCollector {
		isReady = true
		w.WriteHeader(200)
		return
	}
Connection1:
	dao.Connection8003[0], err = net.Dial("tcp", "localhost:8003")
	if err != nil {
		goto Connection1
	}
	dao.Connection8003[0].Write(util.Str2bytes(dao.MyPort + "," + "0\n"))

Connection0:
	dao.Connection8003[1], err = net.Dial("tcp", "localhost:8003")
	if err != nil {
		goto Connection0
	}
	dao.Connection8003[1].Write(util.Str2bytes(dao.MyPort + "," + "1\n"))

	isReady = true

	go service.ReceiveErrorTraceIdForThread(dao.Connection8003[0], 0)
	go service.ReceiveErrorTraceIdForThread(dao.Connection8003[1], 1)
	w.WriteHeader(200)
}

func AliveWeb(writer http.ResponseWriter, request *http.Request) {
	writer.WriteHeader(200)
}

var DReader DelayReader

type DelayReader struct {
	PostData string
	i        int64
	prevRune int
	dataRead sync.Mutex
}

func (r *DelayReader) Read(b []byte) (n int, err error) {

	for r.PostData == "" {
		time.Sleep(time.Duration(1) * time.Microsecond)
	}

	if r.i >= int64(len(r.PostData)) {
		return 0, io.EOF
	}
	r.prevRune = -1
	n = copy(b, r.PostData[r.i:])
	r.i += int64(n)
	return
}

var connectToServerCall bool = false

func connectToServer() {
	nodeInfo := dao.GetWhoAmI()
	postUrl := fmt.Sprintf("http://localhost:%s/api/finished", nodeInfo.ParameterPort)
	for {
		req, _ := http.NewRequest("POST", postUrl, &DReader)
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
		resp, err := util.HttpClient.Do(req)

		if err == nil {
			util.DiscardAndClose(resp)
			log.Printf("post successfully")
			break
		}
		time.Sleep(time.Duration(1) * time.Microsecond)
	}
}

func BadCollectFinishWeb(writer http.ResponseWriter, request *http.Request) {
	syncMutex.Lock()
	finishCount++
	if !connectToServerCall {
		go connectToServer()
	}
	connectToServerCall = true

	if finishCount == 2 {
		//全部完成了
		collecorManager := dao.GetCollectorTraceManager()
		for service.ExitCount != 4 {
			time.Sleep(time.Duration(1) * time.Microsecond)
		}

		json := collecorManager.CalculateResult()
		postData := url.Values{}
		postData.Set("result", json)
		DReader.PostData = postData.Encode()
	}
	syncMutex.Unlock()
	writer.WriteHeader(200)
}

func BroadcastWeb(writer http.ResponseWriter, request *http.Request) {
	from := getLastPart(request.URL.Path)
	url := request.URL.Query().Get("url")
	if from == "8000" {
		resp, err := util.HttpClient.Get("http://localhost:8001/" + url)
		if err == nil {
			util.DiscardAndClose(resp)
		}
	} else {
		resp, err := util.HttpClient.Get("http://localhost:8000/" + url)
		if err == nil {
			util.DiscardAndClose(resp)
		}
	}
	writer.WriteHeader(200)
}

/*
  /tracescanstep/0/3
  /tracescanstep/1/2
*/
func TraceScanStepWeb(writer http.ResponseWriter, request *http.Request) {
	index, step := GetLastTwoPart(request.URL.Path)
	scannerIndex, _ := strconv.Atoi(index)
	BackendStep, _ := strconv.Atoi(step)
	service.Scanners[scannerIndex].BackendStep = BackendStep
	writer.WriteHeader(200)
}
