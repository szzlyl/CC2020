package service

import (
	"bytes"
	"errors"
	"io"
	"strconv"
	"time"
	"trace/dao"
	"trace/util"
	"unsafe"
)

type TraceScanner struct {
	r            io.Reader
	split        SplitFunc
	maxTokenSize int
	token        []byte
	buf          []byte
	start        int
	end          int
	err          error
	empties      int
	scanCalled   bool
	done         bool
	myStep       int
	BackendStep  int
	Tid          int
	errorInLine  dao.ERRORTYPE
	Manager      *dao.FilterTraceManager
}

/**
SplitFunc是用于标记输入。参数是剩余未处理的初始子字符串数据和一个标记atEOF，用于报告读取器是否没有更多数据给予。
返回值是推进输入的字节数以及返回给用户的下一个令牌（如果有），以及一个错误（如果有）。如果函数返回错误，扫描将停止，在这种情况下输入可以被丢弃。
否则，扫描仪推进输入。如果不是零，扫描仪将其返回给用户。如果令牌为零，则扫描仪读取更多数据并继续扫描；如果没有更多数据data——如果atEOF为真，则扫描仪返回。
如果数据没有但是要持有一个完整的令牌，例如如果它没有换行符while扫描行时，SplitFunc可以返回（0，nil，nil）来向扫描仪将更多数据读入切片，
然后使用从输入的同一点开始的较长切片。除非atEOF，否则永远不会使用空数据片调用函数是真的。
但是，如果atEOF为真，则数据可能不是空的，一如既往，保留未处理的文本。
*/
type SplitFunc func(data []byte, atEOF bool) (advance int, token []byte, err error, errorInLine dao.ERRORTYPE)

const (
	MaxScanTokenSize = 64 * 1024
)

func NewTraceScanner(r io.Reader) *TraceScanner {
	return &TraceScanner{
		r:            r,
		maxTokenSize: MaxScanTokenSize,
	}
}

func (s *TraceScanner) Err() error {
	if s.err == io.EOF {
		return nil
	}
	return s.err
}

func (s *TraceScanner) Bytes() []byte {
	return s.token
}

func (s *TraceScanner) Text() string {
	return *(*string)(unsafe.Pointer(&s.token))
}

func (s *TraceScanner) TextAndErrorInLine() (string, dao.ERRORTYPE) {
	return *(*string)(unsafe.Pointer(&s.token)), s.errorInLine
}

var ErrFinalToken = errors.New("final token")

const readSize = 1024 * 1024

func (s *TraceScanner) Scan() bool {
	if s.done {
		return false
	}
	s.scanCalled = true
	for {
		if s.end > s.start || s.err != nil {
			advance, token, err, errorInLine := ScanLines(s.buf[s.start:s.end], s.err != nil)

			if err != nil {
				if err == ErrFinalToken {
					s.errorInLine = errorInLine
					s.token = token
					s.done = true
					return true
				}
				s.setErr(err)
				return false
			}
			s.start += advance

			s.errorInLine = errorInLine
			s.token = token
			if token != nil {
				if s.err == nil || advance > 0 {
					s.empties = 0
				} else {
					s.empties++
					if s.empties > 100 {
						panic("bufio.Scan: too many empty tokens without progressing")
					}
				}
				return true
			}
		}
		if s.err != nil {
			s.start = 0
			s.end = 0
			return false
		}
		if s.start > 0 && (len(s.buf)-s.end <= readSize) {

			s.myStep++
			s.PostMyStepToBackend(s.myStep)
			for s.BackendStep < s.myStep {
				time.Sleep(time.Duration(1) * time.Microsecond)
			}

			copy(s.buf, s.buf[s.start:s.end])
			s.end -= s.start
			s.start = 0
		}
		for loop := 0; ; {
			endPos := s.end + readSize
			if endPos > len(s.buf) {
				endPos = len(s.buf)
			}
			n, err := s.r.Read(s.buf[s.end:endPos])
			s.end += n
			if err != nil {
				s.setErr(err)
				break
			}
			if n > 0 {
				s.empties = 0
				break
			}
			loop++
			if loop > 100 {
				s.setErr(io.ErrNoProgress)
				break
			}
		}
	}
}

func (s *TraceScanner) PostMyStepToBackend(step int) {
	whoAmI := dao.GetWhoAmI()
	url := "http://localhost:8002/broadcast/" + whoAmI.MyServerPort + "?url=traceScanStep/" + strconv.Itoa(s.Tid) + "/" + strconv.Itoa(step)
	util.HttpClient.Get(url)
}

func (s *TraceScanner) advance(n int) bool {
	s.start += n
	return true
}

func (s *TraceScanner) setErr(err error) {
	if s.err == nil || s.err == io.EOF {
		s.err = err
	}
}

func (s *TraceScanner) Buffer(buf []byte, max int) {
	if s.scanCalled {
		panic("Buffer called after Scan")
	}
	s.buf = buf
	s.maxTokenSize = max
}

func (s *TraceScanner) Split(split SplitFunc) {
	if s.scanCalled {
		panic("Split called after Scan")
	}
	s.split = split
}

func ScanLines(data1 []byte, atEOF bool) (advance int, token []byte, err error, lineError dao.ERRORTYPE) {
	if atEOF && len(data1) == 0 {
		return 0, nil, nil, dao.NoErr
	}

	if i := bytes.IndexByte(data1, '\n'); i >= 0 {
		// 新行
		return i + 1, data1[0:i], nil, GetErrorInBytes(data1[0:i])
	}
	if atEOF {
		return len(data1), data1, nil, GetErrorInBytes(data1)
	}
	return 0, nil, nil, dao.NoErr
}

// http.status_code=200前面是最短的可以跳过的 = 65
// d614959183521b4b|1587457762873000|d614959183521b4b|0|0|||0.0.1.3|http.status_code=200
const skipCount = 65

func GetErrorInBytes(line []byte) dao.ERRORTYPE {
	lastIndexOfS := bytes.IndexByte(line[skipCount:], '&')
	if line[lastIndexOfS-20+skipCount] == 'h' && line[lastIndexOfS-4+skipCount] == '=' && line[lastIndexOfS-3+skipCount] == '2' {
		return dao.NoErr
	} else if line[lastIndexOfS-7+skipCount] == 'e' && line[lastIndexOfS-2+skipCount] == '=' && line[lastIndexOfS-1+skipCount] == '1' {
		return dao.Err
	} else if line[lastIndexOfS-20+skipCount] == 'h' && line[lastIndexOfS-4+skipCount] == '=' {
		return dao.Err
	}

	tag := line[lastIndexOfS+1+skipCount:]

	if tag[0] == '&' {
		tag = tag[1:]
	}

	var i = 0
	var length int
	for {
		length = len(tag)
		if length < 7 {
			return dao.NoErr
		}
		if tag[0] == 'h' && length >= 20 {
			if tag[16] == '=' && tag[17] == '2' {
				//perf  just compare 200    if tag[17:20] == "200" {
				return dao.NoErr
			} else if tag[5] == 's' {
				//} else if  tag[0:6] == "http.s" {
				return dao.Err
			}
		} else if tag[0] == 'e' && tag[1] == 'r' && tag[2] == 'r' && tag[3] == 'o' && tag[4] == 'r' && tag[5] == '=' && tag[6] == '1' {
			return dao.Err
		}

		if tag[0] == '&' {
			tag = tag[1:]
			continue
		}

		i = bytes.IndexByte(tag, '&') + 1

		if i == 0 || i == length {
			return dao.NoErr
		} else {
			tag = tag[i:]
		}
	}
}
