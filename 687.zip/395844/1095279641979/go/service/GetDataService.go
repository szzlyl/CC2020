package service

import (
	"io"
	"os"
	"strings"
	"sync"
	"time"
	"trace/dao"
	"trace/util"
)

var WaitHttpReader sync.WaitGroup
var LoadLocalFile = false
var IsReadyToReadStream = false
var PprofEnable = false

var Scanners = make([]*TraceScanner, 2)
var BigBuf = make([][]byte, 2)

const MaxCapacity = 1 * 1024 * 1024 * 1024

func FilterAfterSetParameterSingleThread(nodeInfo *dao.WhoAmI) {
	resp, err := util.HttpClient.Get(nodeInfo.GetCollectorUrl() + "/readytoread")
	if err == nil {
		util.DiscardAndClose(resp)
	}
	go ReadDataFromHttp()
}

func WaitPeerComplete() {
	for !dao.IsPeerComplete {
		time.Sleep(time.Duration(10) * time.Microsecond)
	}
}

func ReadDataFromHttp() {
	for !IsReadyToReadStream {
		time.Sleep(time.Duration(1) * time.Microsecond)
	}

	nodeInfo := dao.GetWhoAmI()

	if !LoadLocalFile {
		dataUrl := nodeInfo.GetDataFileUrl()
		scopes := util.SplitTo2(dataUrl)
		for i, item := range scopes {
			resp, err := util.GetPart(dataUrl, item)
			if err != nil {
				panic(err)
			}
			WaitHttpReader.Add(1)
			go handleTraceData(resp.Body, i)
		}
	} else {
		file1, _ := os.Open(nodeInfo.GetLocalDataFileUrl())
		defer file1.Close()
		WaitHttpReader.Add(1)
		go handleTraceData(file1, 0)
	}

	WaitHttpReader.Wait()

	completeUrl := nodeInfo.GetCollectorUrl() + "/broadcast/" + nodeInfo.MyServerPort + "?url=iamcompelte"
	resp, err := util.HttpClient.Get(completeUrl)
	if err == nil {
		util.DiscardAndClose(resp)
	}

	WaitPeerComplete()

	handleErrorTraceIdBatch(0)
	handleErrorTraceIdBatch(1)

	dao.Connection8003[0].Close()
	dao.Connection8003[1].Close()
	url := nodeInfo.GetCollectorUrl() + "/bad/collect_finish"
	util.HttpClient.Post(url, "text/plain", strings.NewReader(""))
}

func handleErrorTraceIdBatch(tid int) {
	for len(dao.ErrorTraceId[tid]) > 0 {
		dao.ErrorTraceIdMutex[tid].Lock()
		traceId := dao.ErrorTraceId[tid][0]
		dao.ErrorTraceId[tid] = dao.ErrorTraceId[tid][1:]
		dao.ErrorTraceIdMutex[tid].Unlock()
		dao.FilterTraceManagers[tid].FlagAsErrorSync(traceId)
	}

	content := util.Str2bytes(dao.FilterTraceManagers[tid].B.String())
	if len(content) > 0 {
		dao.Connection8003[tid].Write(content)
		dao.FilterTraceManagers[tid].B.Reset()
		dao.FilterTraceManagers[tid].B.Grow(128 * 1024)
	}
}

func handleTraceData(reader io.ReadCloser, tid int) {

	manager := dao.FilterTraceManagers[tid]
	manager.Tid = tid

	var linenum int = 0

	scanner := NewTraceScanner(reader)
	scanner.Tid = tid
	scanner.Buffer(BigBuf[tid], MaxCapacity)
	scanner.Split(ScanLines)
	scanner.Manager = manager
	Scanners[tid] = scanner
	for scanner.Scan() {
		linenum++
		line, errorType := scanner.TextAndErrorInLine()

		manager.AddLine(line, linenum, errorType)

		if linenum&0x7fff == 0x7fff {
			manager.CheckFixedTrace(linenum)
			handleErrorTraceIdBatch(tid)
		}
	}

	scanner.PostMyStepToBackend(10)

	manager.CheckFixedTrace(dao.IntMax)
	handleErrorTraceIdBatch(tid)

	reader.Close()
	handleErrorTraceIdBatch(tid)
	WaitHttpReader.Done()
}
