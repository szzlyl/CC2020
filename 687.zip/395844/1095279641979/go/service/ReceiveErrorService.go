package service

import (
	"bufio"
	"net"
	"strconv"
	"sync"
	"trace/dao"
	"trace/util"
)

var ErrorCollectTcpMutex sync.Mutex
var traceIdCount map[string]int
var ExitCount int

var Connection8000 = make([]net.Conn, 2)
var Connection8001 = make([]net.Conn, 2)

func ReceiveErrorTraceIdForThread(connection net.Conn, index int) {
	scanner := bufio.NewScanner(bufio.NewReader(connection))
	scanner.Split(util.TraceScanLines)
	buf := make([]byte, 512)
	scanner.Buffer(buf, 512)
	for scanner.Scan() {
		traceId := scanner.Text()
		dao.ErrorTraceIdMutex[index].Lock()
		dao.ErrorTraceId[index] = append(dao.ErrorTraceId[index], traceId)
		dao.ErrorTraceIdMutex[index].Unlock()
	}
}

func ErrorCollectTcp(connection net.Conn) {
	traceIdCount = make(map[string]int)

	collectorManager := dao.GetCollectorTraceManager()

	scanner := bufio.NewScanner(bufio.NewReader(connection))
	scanner.Split(util.TraceScanLines)
	buf := make([]byte, 5*1024*1024)
	scanner.Buffer(buf, 5*1024*1024)

	var lineNum = 0
	var currentTraceId string
	var currentTrace *dao.TraceItem
	var from string
	var threadId string
	var threadIdInt int
	var firstCmd = true
	for scanner.Scan() {
		line := scanner.Text()
		if firstCmd {
			from = line[0 : len(line)-2]
			threadId = line[len(line)-1:]
			firstCmd = false
			threadIdInt, _ = strconv.Atoi(threadId)
			if from == "8000" {
				Connection8000[threadIdInt] = connection
			} else {
				Connection8001[threadIdInt] = connection
			}
			continue
		}
		lineNum++

		if line == "o" {
			currentTrace = nil
			ErrorCollectTcpMutex.Lock()
			count := traceIdCount[currentTraceId] + 1
			traceIdCount[currentTraceId] = count
			ErrorCollectTcpMutex.Unlock()

			if count == 2 {
				if from == "8000" {
					Connection8001[threadIdInt].Write(util.Str2bytes(currentTraceId[0:dao.ShortTraceIdLen] + "\n"))
				} else {
					Connection8000[threadIdInt].Write(util.Str2bytes(currentTraceId[0:dao.ShortTraceIdLen] + "\n"))
				}
				collectorManager.CalculateTrace(currentTraceId)
			} else if count < 2 {
				//var toUrl string
				if from == "8000" {
					//toUrl = "http://localhost:8001/badtrace" + threadId + "/" + currentTraceId[data.ShortTraceIdStartPos:]
					Connection8001[threadIdInt].Write(util.Str2bytes(currentTraceId[0:dao.ShortTraceIdLen] + "\n"))
				} else {
					//toUrl = "http://localhost:8000/badtrace" + threadId + "/" + currentTraceId[data.ShortTraceIdStartPos:]
					Connection8000[threadIdInt].Write(util.Str2bytes(currentTraceId[0:dao.ShortTraceIdLen] + "\n"))

				}
			} else {
				//count >2
				collectorManager.ClearHash(currentTraceId)
			}
			lineNum = 0
			continue
		}

		span := dao.NewSpanItemTraceIdAndStartTime(line)
		if currentTrace == nil {
			currentTraceId = span.TraceId
			currentTrace = collectorManager.Add(&span)
		} else {
			currentTrace.AddSpan(&span)
		}
	}

	ErrorCollectTcpMutex.Lock()
	ExitCount++
	ErrorCollectTcpMutex.Unlock()
}
