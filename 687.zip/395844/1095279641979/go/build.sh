rm -f ./script/trace
GOOS=linux go build
mv ./trace ./script/trace

docker build -t go-server:2.0 script/
docker login -u632015851@qq.com -p aliyun-hsbc registry.cn-shanghai.aliyuncs.com
docker tag go-server:2.0 registry.cn-shanghai.aliyuncs.com/cloudnative-contest/go-server:2.0
docker push registry.cn-shanghai.aliyuncs.com/cloudnative-contest/go-server:2.0
