# tianchi-contest
Source code for HSBC coding contest
go version

# Build & Runtime
- java - jdk 1.8+ 
- go - go 1.15.5
- docker 19.03 CE

# How to test
sh build.sh

# TODO
- startTime 可以简化处理，因为数据基本集中在一年/一个月内，只需要保存它的差值
- findError 可以使用比较高效的字节匹配算法
- 可以去除冗余数据块增加一些同步逻辑来确保数据块同步
- 数据结构比较冗余，比如traceId等数据也可以压缩


