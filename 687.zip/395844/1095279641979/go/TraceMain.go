package main

import (
	"flag"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"os"
	"sync"
	"time"
	"trace/dao"
	"trace/service"
	"trace/util"
	"trace/web"
)

func init() {
	flag.StringVar(&dao.MyPort, "server.port", "8080", "server.port")
	flag.BoolVar(&service.LoadLocalFile, "loadLocalFile", false, "loadLocalFile")
	flag.Parse()
	util.HttpClient = util.CreateHTTPClient()

	if dao.GetWhoAmI().GetRole() == dao.IsFilter {
		//data.FilterTraceManagers = make([]*data.FilterTraceManager, 2)
		dao.FilterTraceManagers[0] = dao.NewFilterTraceManager(0)
		dao.FilterTraceManagers[1] = dao.NewFilterTraceManager(1)
	}

	util.InitHex()

	service.BigBuf[0] = make([]byte, service.MaxCapacity)
	service.BigBuf[1] = make([]byte, service.MaxCapacity)
}

func main() {
	log.SetFlags(log.Lmicroseconds)
	log.SetOutput(ioutil.Discard)
	start()
}

func start() {
	initLog()

	whoAmI := dao.GetWhoAmI()
	if whoAmI.GetRole() != dao.IsFilter {
		go start8003()
		go CheckAlive()
	} else {
		dao.ErrorTraceId[0] = make([]string, 0, 10000)
		dao.ErrorTraceId[1] = make([]string, 0, 10000)
		dao.ErrorTraceIdMutex[0] = sync.Mutex{}
		dao.ErrorTraceIdMutex[1] = sync.Mutex{}
	}
	dao.Connection8003 = make([]net.Conn, 2)

	startHttp()

}

/**
get bad trace content
*/
func start8003() {
	l, err := net.Listen("tcp", ":8003")
	if err != nil {
		log.Println("listen error:", err)
		return
	}

	for {
		c, err := l.Accept()
		if err != nil {
			log.Println("accept error:", err)
			break
		}
		// start a new goroutine to handle
		// the new connection.
		go service.ErrorCollectTcp(c)
	}
}

func startHttp() {
	http.HandleFunc("/setParameter", web.SetParameterWeb)
	http.HandleFunc("/iamcompelte", web.CompletedWeb)
	http.HandleFunc("/readytoread", web.ReadyToReadWeb)
	http.HandleFunc("/ready", web.ReadyWeb)
	http.HandleFunc("/youcango", web.YoucangoWeb)
	http.HandleFunc("/alive", web.AliveWeb)
	http.HandleFunc("/broadcast/", web.BroadcastWeb)
	http.HandleFunc("/traceScanStep/", web.TraceScanStepWeb)
	http.HandleFunc("/bad/collect_finish", web.BadCollectFinishWeb)
	err := http.ListenAndServe(":"+dao.MyPort, nil) //设置监听的端口
	if err != nil {
		log.Fatal("ListenAndServe: ", err)
	}
}

func initLog() {
	os.Mkdir("./log", 0755)
}

func CheckAlive() {
	log.Println("I am collector, i will check alive")
	var ready8000, ready8001, ready8002 int
	for {
		resp, err := util.HttpClient.Get("http://localhost:8000/alive")
		if err == nil {
			ready8000 = resp.StatusCode
			util.DiscardAndClose(resp)
			log.Println("8000 is ok")
		} else {
			log.Printf("error check 8000 %s\n", err)
		}

		resp, err = util.HttpClient.Get("http://localhost:8001/alive")
		if err == nil {
			ready8001 = resp.StatusCode
			util.DiscardAndClose(resp)
			log.Println("8001 is ok")
		} else {
			log.Printf("error check 8001 %s\n", err)
		}

		resp, err = util.HttpClient.Get("http://localhost:8002/alive")
		if err == nil {
			ready8002 = resp.StatusCode
			util.DiscardAndClose(resp)
			log.Println("8002 is ok")
		} else {
			log.Printf("error check 8002 %s\n", err)
		}

		if ready8000 == 200 && ready8001 == 200 && ready8002 == 200 {
			for {
				resp, err = util.HttpClient.Get("http://localhost:8000/youcango")
				if err == nil {
					util.DiscardAndClose(resp)
					log.Println("8000 youcango")
				} else {
					log.Printf("error info 8000 youcango  %s\n", err)
					time.Sleep(time.Duration(10) * time.Microsecond)
					continue
				}

				resp, err = util.HttpClient.Get("http://localhost:8001/youcango")
				if err == nil {
					util.DiscardAndClose(resp)
					log.Println("8001 youcango")
				} else {
					log.Printf("error info 8001 youcango  %s\n", err)
					time.Sleep(time.Duration(10) * time.Microsecond)
					continue
				}
				resp, err = util.HttpClient.Get("http://localhost:8002/youcango")
				if err == nil {
					util.DiscardAndClose(resp)
					log.Println("8002 youcango")
				} else {
					log.Printf("error info 8002 youcango  %s \n", err)
					time.Sleep(time.Duration(10) * time.Microsecond)
					continue
				}
				log.Println("all ready, GO!")
				break
			}
			break

		} else {
			log.Printf("someone not ready, try to check again, statut code is  %d %d %d \n ", ready8000, ready8001, ready8002)
		}
		time.Sleep(time.Duration(10) * time.Microsecond)
	}
	log.Println("check alive exist, all ready!")
}
