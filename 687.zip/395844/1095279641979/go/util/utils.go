package util

import (
	"bytes"
	"crypto/md5"
	"encoding/hex"
	"io"
	"io/ioutil"
	"log"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"
	"unsafe"
)

var (
	HttpClient *http.Client
	Hex        []int64
)

func GetMD5Hash(text string) string {
	hash := md5.Sum(Str2bytes(text))
	return hex.EncodeToString(hash[:])
}

func CreateHTTPClient() *http.Client {
	client := &http.Client{
		Transport: &http.Transport{
			Proxy: http.ProxyFromEnvironment,
			DialContext: (&net.Dialer{
				Timeout:   30 * time.Second,
				KeepAlive: 30 * time.Second,
			}).DialContext,
			MaxIdleConns:        100,
			MaxIdleConnsPerHost: 1000,
			IdleConnTimeout:     time.Duration(90) * time.Second,
		},
	}
	return client
}

/**
从 ptype 输出的结构来看，string 可看做 [2]uintptr，而 [ ]byte 则是 [3]uintptr，这便于我们编写代码，无需额外定义结构类型。
如此，str2bytes 只需构建 [3]uintptr{ptr, len, len}，而 bytes2str 更简单，直接转换指针类型，忽略掉 cap 即可。
通过unsafe.Pointer（指针转换）和uintptr（指针运算）实现转换
https://www.cnblogs.com/shuiyuejiangnan/p/9707066.html
*/
func Str2bytes(s string) []byte {
	x := (*[2]uintptr)(unsafe.Pointer(&s))
	h := [3]uintptr{x[0], x[1], x[1]}
	return *(*[]byte)(unsafe.Pointer(&h))
}

func InitHex() {
	Hex = make([]int64, 256)
	Hex['0'] = 0
	Hex['1'] = 1
	Hex['2'] = 2
	Hex['3'] = 3
	Hex['4'] = 4
	Hex['5'] = 5
	Hex['6'] = 6
	Hex['7'] = 7
	Hex['8'] = 8
	Hex['9'] = 9
	Hex['a'] = 10
	Hex['b'] = 11
	Hex['c'] = 12
	Hex['d'] = 13
	Hex['e'] = 14
	Hex['f'] = 15
	Hex['A'] = 10
	Hex['B'] = 11
	Hex['C'] = 12
	Hex['D'] = 13
	Hex['E'] = 14
	Hex['F'] = 15
}

func Str2Uint64(value string) int64 {

	var result int64
	result |= (Hex[(value[0])]) << 32
	result |= (Hex[(value[1])]) << 28
	result |= (Hex[(value[2])]) << 24
	result |= (Hex[(value[3])]) << 20
	result |= (Hex[(value[4])]) << 16
	result |= (Hex[(value[5])]) << 12
	result |= (Hex[(value[6])]) << 8
	result |= (Hex[(value[7])]) << 4
	result |= (Hex[(value[8])])
	return result
}

func GetPart(url string, httpRange string) (resp *http.Response, err error) {
	req, _ := http.NewRequest(http.MethodGet, url, nil)

	req.Header.Set("RANGE", "bytes="+httpRange)

	resp, err1 := HttpClient.Do(req)
	return resp, err1
}

func GetPartAsString(url string, httpRange string) string {
	resp, err := GetPart(url, httpRange)
	if err == nil {
		defer resp.Body.Close()
		s, _ := ioutil.ReadAll(resp.Body)
		return string(s)
	} else {
		log.Printf("error int GetPartAsString %s", err)
		return ""
	}
}

func GetContentLength(url string) uint64 {
	req, _ := http.NewRequest(http.MethodHead, url, nil)

	resp, err := HttpClient.Do(req)
	if err == nil {
		length := resp.Header.Get("Content-Length")
		DiscardAndClose(resp)
		if err != nil {
			log.Println("close error", err)
		}
		intLen, _ := strconv.ParseUint(length, 10, 64)
		log.Printf("get len from %s is %d", url, intLen)
		return intLen
	}

	log.Printf("err when GetContentLength %s ", err)
	return 0
}

/**
找到pos後 最近的一個回車
平均一行271byte
*/
func FindEol(url string, pos uint64) uint64 {
	readCount := uint64(500)
	for {
		re, found := findEol(url, pos, readCount)
		if found {
			return re
		}
		readCount *= 2
	}
}

func findEol(url string, pos uint64, readBytes uint64) (uint64, bool) {
	strRange := strconv.FormatUint(pos, 10) + "-" + strconv.FormatUint(pos+readBytes, 10)
	content := GetPartAsString(url, strRange)
	eolLoc := strings.Index(content, "\n")
	if eolLoc == -1 {
		return 0, false
	}
	return pos + uint64(eolLoc), true
}

func TraceScanLines(data []byte, atEOF bool) (advance int, token []byte, err error) {

	if atEOF && len(data) == 0 {
		return 0, nil, nil
	}
	if i := bytes.IndexByte(data, '\n'); i >= 0 {
		// We have a full newline-terminated line.
		return i + 1, data[0:i], nil
	}

	// If we're at EOF, we have a final, non-terminated line. Return it.
	if atEOF {
		return len(data), data, nil
	}
	// Request more data.
	return 0, nil, nil
}

func SplitTo2(url string) []string {
	var re []string = make([]string, 2)
	contentSize := GetContentLength(url)
	middlePos := contentSize / uint64(2)

	// one line for 270 bytes
	eolPos := FindEol(url, middlePos+32*1024*1024)
	re[0] = "0-" + strconv.FormatUint(eolPos, 10)

	eolPos2 := FindEol(url, middlePos-32*1024*1024) + 1
	re[1] = strconv.FormatUint(eolPos2, 10) + "-"

	return re
}

func DiscardAndClose(resp *http.Response) {
	io.Copy(ioutil.Discard, resp.Body)
	resp.Body.Close()
}
