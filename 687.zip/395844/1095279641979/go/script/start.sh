mkdir log;
if   [  $SERVER_PORT == "8002" ];
then
   GOGC=off /usr/local/src/trace -server.port=$SERVER_PORT  &
else
   GOGC=off /usr/local/src/trace -server.port=$SERVER_PORT  &
fi
tail -f /usr/local/src/start.sh

