package htc.code2020.trace.aggregator;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class BadIdRequest {
    private int filterId;
    private int id;
    private boolean last;
    private Set<String> badIdSet;

    public byte[] toBytes() {
        ByteBuf byteBuf = Utils.getBuffer();
        byteBuf.writeInt(filterId);
        byteBuf.writeInt(id);
        byteBuf.writeByte(last ? (byte) 1 : (byte) 0);
        Utils.writeSet(byteBuf, badIdSet);
        return Utils.asBytes(byteBuf);
    }

    public static BadIdRequest fromBytes(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }

        ByteBuf byteBuf = Unpooled.wrappedBuffer(bytes);
        BadIdRequest request = new BadIdRequest();
        request.filterId = byteBuf.readInt();
        request.id = byteBuf.readInt();
        request.last = byteBuf.readByte() > 0;
        request.badIdSet = Utils.readSet(byteBuf);
        return request;
    }
}
