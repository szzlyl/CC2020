package htc.code2020.trace.aggregator;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

import java.util.*;

public final class Utils {
    public static final int INITIAL_CAPACITY = 4096;

    private Utils() { }

    private static final ThreadLocal<ByteBuf> SERIALIZATION_BUFFER =
            ThreadLocal.withInitial(() -> Unpooled.buffer(INITIAL_CAPACITY));

    public static final ByteBuf getBuffer() {
        return SERIALIZATION_BUFFER.get().clear();
    }

    public static void writeSet(ByteBuf byteBuf, Set<String> set) {
        List<String> badIds = new ArrayList<>(set);
        writeList(byteBuf, badIds);
    }

    public static void writeList(ByteBuf byteBuf, List<String> list) {
        byteBuf.writeInt(list.size());
        for (String str : list) {
            byteBuf.writeShort(str.length());
        }
        for (String str : list) {
            byteBuf.writeBytes(str.getBytes());
        }
    }

    public static byte[] asBytes(ByteBuf byteBuf) {
        int length = byteBuf.readableBytes();
        byte[] bytes = new byte[length];
        byteBuf.getBytes(0, bytes);
        return bytes;
    }

    public static List<String> readList(ByteBuf byteBuf) {
        int length = byteBuf.readInt();
        List<String> list = new ArrayList<>(length);
        short[] itemLengths = new short[length];
        for (int i = 0; i < length; i ++) {
            itemLengths[i] = byteBuf.readShort();
        }
        for (int i = 0; i < itemLengths.length; i ++) {
            byte[] bytes = new byte[itemLengths[i]];
            byteBuf.readBytes(bytes);
            list.add(new String(bytes));
        }
        return list;
    }

    public static Set<String> readSet(ByteBuf byteBuf) {
        return new HashSet<>(readList(byteBuf));
    }

    public static void writeMap(ByteBuf byteBuf, Map<String, List<String>> map) {
        byteBuf.writeInt(map.size());
        for (Map.Entry<String, List<String>> entry : map.entrySet()) {
            String key = entry.getKey();
            byte keyLength = (byte) key.length();
            byteBuf.writeByte(keyLength);
            byteBuf.writeBytes(key.getBytes());
            writeList(byteBuf, entry.getValue());
        }
    }

    public static Map<String, List<String>> readMap(ByteBuf byteBuf) {
        int size = byteBuf.readInt();
        Map<String, List<String>> map = new HashMap<>(size);
        for (int i = 0; i < size; i ++) {
            byte keyLength = byteBuf.readByte();
            byte[] keyBytes = new byte[keyLength];
            byteBuf.readBytes(keyBytes);
            String key = new String(keyBytes);
            List<String> value = readList(byteBuf);
            map.put(key, value);
        }
        return map;
    }
}
