package htc.code2020.trace.aggregator;

import java.time.Duration;

import org.springframework.boot.autoconfigure.web.client.RestTemplateBuilderConfigurer;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.Data;
import reactor.core.scheduler.Scheduler;
import reactor.core.scheduler.Schedulers;

@Configuration
@EnableConfigurationProperties(AggregatorConfig.Properties.class)
public class AggregatorConfig {
    @ConfigurationProperties(prefix = "htc.aggregator")
    @Data
    public static class Properties {
        private String scoreUrl = "http://localhost:<PORT>/api/finished";
        private Integer[] filterIds = { 8000, 8001 };

        private Timeouts timeouts = new Timeouts();
        private int maxThreads = 100;
        private int maxQueueSize = 2000;
    }

    @Data
    public static class Timeouts {
        private Duration connect = Duration.ofSeconds(1);
        private Duration read = Duration.ofSeconds(5);
        private Duration write = Duration.ofSeconds(5);
        private Duration windowSync = Duration.ofSeconds(5);
        private Duration ready = Duration.ofSeconds(20);
    }

    @Bean
    public RestTemplateBuilder restTemplateBuilder(RestTemplateBuilderConfigurer configurer, 
                                                    Properties properties) {
        return configurer.configure(new RestTemplateBuilder())
        .setConnectTimeout(properties.timeouts.connect)
        .setReadTimeout(properties.timeouts.read);
    }

    @Bean
    public Scheduler scheduler(Properties properties) {
        return Schedulers.newBoundedElastic(properties.maxThreads, properties.maxQueueSize, "elastic-");
    }
}
