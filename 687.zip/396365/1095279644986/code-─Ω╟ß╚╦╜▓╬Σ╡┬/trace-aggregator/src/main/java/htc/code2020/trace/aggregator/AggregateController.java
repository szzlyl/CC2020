package htc.code2020.trace.aggregator;

import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.joining;

import java.io.UnsupportedEncodingException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Stream;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.twmacinta.util.MD5;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Scheduler;

@Slf4j
@RestController
public class AggregateController {
    private final Map<Integer, AllFilterRequests> windowIdAllRequestsMap = new ConcurrentHashMap<>();
    private final Map<String, Set<Trace>> traceIdTracesMap = new ConcurrentHashMap<>();
    private String scoreUrl;

    @RequiredArgsConstructor
    private class AllFilterRequests {
        final Set<Integer> expectedFilterIds;
        final CountDownLatch countDownLatch;
        final List<BadIdRequest> requests = new CopyOnWriteArrayList<>();
    }

    private final AggregatorConfig.Properties properties;
    private final ObjectMapper objectMapper;
    private final RestTemplate restTemplate;
    private final Set<Integer> expectedFilterIds;
    private final Scheduler scheduler;
    private final AtomicBoolean sent = new AtomicBoolean(false);

    private final AtomicBoolean warmUpFinished = new AtomicBoolean(false);

    public AggregateController(AggregatorConfig.Properties properties, ObjectMapper objectMapper,
            RestTemplateBuilder restTemplateBuilder, Scheduler scheduler) {
        this.properties = properties;
        this.objectMapper = objectMapper;
        this.restTemplate = restTemplateBuilder.build();
        this.scheduler = scheduler;
        this.expectedFilterIds = new HashSet<>();
        Stream.of(properties.getFilterIds()).forEach(this.expectedFilterIds::add);
    }

    @RequestMapping("/ready")
    public ResponseEntity<String> ready() throws InterruptedException {
        boolean ok = warmUpFinished.get();
        return ok ?
                ResponseEntity.ok("ok") :
                ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body("not-ok");
    }

    @RequestMapping("/warmUp")
    public ResponseEntity<String> warmUp() {
        setParameter(null);
        return ResponseEntity.ok("ok");
    }

    @RequestMapping("/setParameter")
    public String setParameter(@RequestParam Integer port) {
        if (port != null){
            this.scoreUrl = properties.getScoreUrl().replace("<PORT>", port.toString());
        } else {
            this.scoreUrl = null;
            try {
                String warmUp = md5(objectMapper.writeValueAsString(Collections.singletonMap("a", "b")));
                MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
                // map.add("result", objectMapper.writeValueAsString(idMD5Map));
                map.add("result", objectMapper.writeValueAsString(warmUp));
                HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(map, null);
                restTemplate.postForObject(scoreUrl+"/warmUp", httpEntity, String.class);
            } catch (Exception ex) { }
        }

        if (sent.get()) {
            traceIdTracesMap.clear();
            windowIdAllRequestsMap.clear();
            expectedFilterIds.clear();
            Stream.of(properties.getFilterIds()).forEach(this.expectedFilterIds::add);
            sent.set(false);
        }
        return "ok";
    }

    @MessageMapping("badIds")
    public Mono<byte[]> receiveBadIds(Mono<byte[]> mono) {
        return mono.map(bytes -> {
            BadIdRequest request = BadIdRequest.fromBytes(bytes);
            AllFilterRequests allFilterRequests = windowIdAllRequestsMap.computeIfAbsent(request.getId(), key -> {
                Set<Integer> expectedFilterIds = new HashSet<>();
                Stream.of(properties.getFilterIds()).forEach(expectedFilterIds::add);
                CountDownLatch countDownLatch = new CountDownLatch(expectedFilterIds.size());
                return (new AllFilterRequests(expectedFilterIds, countDownLatch));
            });

            Integer filterId = request.getFilterId();
            // log.debug("Received request: {} with {} getBadIdSet", request, request.getBadIdSet().size());
            if (allFilterRequests.expectedFilterIds.remove(filterId)) {
                allFilterRequests.requests.add(request);
                allFilterRequests.countDownLatch.countDown();
            } else {
                String message = String.format("Duplicated request filter id %s for request #%d", filterId,
                        request.getId());
                log.error(message);
                throw (new RuntimeException(message));
            }

            BadIdResponse response = null;
            try {
                allFilterRequests.countDownLatch.await();
                // log.debug("Received all requests for window #{}", request.getId());

                Set<String> badIdsFromOthers = new HashSet<>();
                for (BadIdRequest req : allFilterRequests.requests) {
                    if (req.getFilterId() != request.getFilterId()) {
                        badIdsFromOthers.addAll(req.getBadIdSet());
                    }
                }
                response = new BadIdResponse(request.getId(), badIdsFromOthers);
                // log.debug("Send to {} badIdsFromOthers for window: {}", response.getBadIdsFromOthers().size(),
//                        request.getId());
                windowIdAllRequestsMap.remove(request.getId()); // Very important
            } catch (InterruptedException e) {
                log.error("Got interrupted when wait for receiving all the windows from all the filters", e);
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                log.error("Unknown exception", e);
            }
            return ofNullable(response).map(BadIdResponse::toBytes).orElse(new byte[0]);
        }).subscribeOn(scheduler);
    }

    @MessageMapping("traces")
    public void receiveTraces(byte[] bytes) throws Exception {
        AggregateRequest request = AggregateRequest.fromBytes(bytes);
        // log.debug("Received trace: {}, {} id lines pairs", request, request.getIdLinesMap().size());
        for (Map.Entry<String, List<String>> entry : request.getIdLinesMap().entrySet()) {
            Set<Trace> traces = traceIdTracesMap.computeIfAbsent(entry.getKey(),
                    key -> new ConcurrentSkipListSet<>(Comparator.comparing(Trace::getTracedAt)));
            entry.getValue().stream().map(Trace::new).forEach(traces::add);
        }

        if (request.isLast()) {
            // log.debug("Request: {} is last for its filter", request);
            expectedFilterIds.remove(request.getFilterId());
        }

        if (!sent.get() && expectedFilterIds.isEmpty()) {
            Map<String, String> idMD5Map = new HashMap<>();
            StopWatch stopWatch = new StopWatch();

            stopWatch.start();
            traceIdTracesMap.entrySet().stream().forEach(entry -> {
                String joinedLines = entry.getValue().stream()
                        // .sorted(Comparator.comparing(Trace::getTracedAt))
                        .map(Trace::getLine).collect(joining("\n")) + "\n";
                String checksum = md5(joinedLines);
                idMD5Map.put(entry.getKey(), checksum);
            });
            stopWatch.stop();
            // log.debug("Finished sorting and MD5 within {}ms", stopWatch.getTotalTimeMillis());

            stopWatch.start();
            MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
            // map.add("result", objectMapper.writeValueAsString(idMD5Map));
            map.add("result", objectMapper.writeValueAsString(idMD5Map));
            HttpEntity<MultiValueMap<String, String>> httpEntity = new HttpEntity<>(map, null);
            String text;
            if (scoreUrl != null) {
                text = restTemplate.postForObject(scoreUrl, httpEntity, String.class);
            } else {
                text = "WarmUp";
            }
            stopWatch.stop();
            log.info("All done, sent {} id and MD5 pairs to score app, and got the response: {}, within {}ms",
                    idMD5Map.size(), text, stopWatch.getTotalTimeMillis());
            sent.set(true);
            warmUpFinished.set(true);
        }
    }

    private String md5(String key) {
        String hash = null;
        try {
            MD5 md5 = new MD5();
            md5.Update(key, null);
            hash = asHex(md5.Final());
        } catch (UnsupportedEncodingException e) {
            new RuntimeException("Failed to do MD5", e);
        }
        return hash;
    }

    private static final char[] HEX_CHARS = {'0', '1', '2', '3',
                                             '4', '5', '6', '7',
                                             '8', '9', 'A', 'B',
                                             'C', 'D', 'E', 'F',};
    private static String asHex(byte hash[]) {
        char buf[] = new char[hash.length * 2];
        for (int i = 0, x = 0; i < hash.length; i++) {
            buf[x++] = HEX_CHARS[(hash[i] >>> 4) & 0xf];
            buf[x++] = HEX_CHARS[hash[i] & 0xf];
        }
        return new String(buf);
    }

}

