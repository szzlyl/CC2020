package htc.code2020.trace.aggregator;

import org.springframework.util.Assert;

import lombok.Getter;

@Getter
public class Trace {
    private final long tracedAt;
    private final String line;

    public Trace(String line) {
        Assert.notNull(line, "Line must not be null");
        this.line = line;
        this.tracedAt = getTracedAt(line);
    }

    @Override
    public boolean equals(Object trace) {
        if (trace == null) {
            return false;
        }

        if (!(trace instanceof Trace)) {
            return false;
        }

        return line.equals(((Trace) trace).getLine());
    }

    @Override
    public int hashCode() {
        return line.hashCode();
    }

    private long getTracedAt(String line) {
        int firstPipeIndex = line.indexOf('|');
        if (firstPipeIndex < 0) {
            return 0;
        }

        int firstPipeIndexNext = firstPipeIndex + 1;
        int secondPipeIndex = line.indexOf('|', firstPipeIndexNext);
        if (secondPipeIndex < 0) {
            return 0;
        }

        long tracedAt = 0;
        try {
            tracedAt = Long.parseLong(line.substring(firstPipeIndexNext, secondPipeIndex));
        } catch (Exception e) { /* No need to handle */ }
        return tracedAt;
    }
}
