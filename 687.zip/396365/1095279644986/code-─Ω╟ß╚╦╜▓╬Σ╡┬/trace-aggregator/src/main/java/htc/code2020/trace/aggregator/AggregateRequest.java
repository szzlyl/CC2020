package htc.code2020.trace.aggregator;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class AggregateRequest {
    private int filterId;
    private boolean last;
    private Map<String, List<String>> idLinesMap;

    public byte[] toBytes() {
        ByteBuf byteBuf = Utils.getBuffer();
        byteBuf.writeInt(filterId);
        byteBuf.writeByte(last ? (byte) 1 : (byte) 0);
        Utils.writeMap(byteBuf, idLinesMap);
        return Utils.asBytes(byteBuf);
    }

    public static AggregateRequest fromBytes(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }

        ByteBuf byteBuf = Unpooled.wrappedBuffer(bytes);
        AggregateRequest request = new AggregateRequest();
        request.filterId = byteBuf.readInt();
        request.last = byteBuf.readByte() > 0;
        request.idLinesMap = Utils.readMap(byteBuf);
        return request;
    }

}
