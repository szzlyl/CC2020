# HTC Code Event 2020

### Useful commands, local test
``` shell script
# post result
curl -X POST -d 'result={"d614959183521b4b":"d8de6a65bd9f0b80POST 5b44dc6dff8d5"}' "http://localhost:8080/api/finished"

curl "http://localhost:8000/ready"

curl "http://localhost:8001/setParameter?port=8080"

curl "http://localhost:8000/setParameter?port=8080"; curl "http://localhost:8001/setParameter?port=8080"; curl "http://localhost:8002/setParameter?port=8080"

cd /home/max/IdeaProjects/htc-code-2020/source-score; mvn clean package; java -Xms2g -Xmx2g -server -jar target/source-score-0.0.1-SNAPSHOT.jar
cd /home/max/IdeaProjects/htc-code-2020/trace-aggregator; mvn clean package; java -Xms1500m -Xmx1500m -server -jar target/trace-aggregator-0.0.1-SNAPSHOT.jar
cd /home/max/IdeaProjects/htc-code-2020/trace-filter; mvn clean package; java -Xms3500m -Xmx3500m -server -jar target/trace-filter-0.0.1-SNAPSHOT.jar --htc.filter.windowSize=100000
cd /home/max/IdeaProjects/htc-code-2020/trace-filter; java -Xms3500m -Xmx3500m -server -jar target/trace-filter-0.0.1-SNAPSHOT.jar --server.port=8001 --htc.filter.windowSize=100000


cd C:\Users\maxmy\IdeaProjects\htc-code-2020\source-score & %userprofile%/path.bat & mvn compile exec:java -Dexec.mainClass="htc.code2020.source.score.HttpStaticFileServer"
cd C:\Users\maxmy\IdeaProjects\htc-code-2020\source-score & %userprofile%/path.bat & mvn clean package -Dmaven.test.skip=true & java -Xms500m -Xmx500m -server -jar target/source-score-0.0.1-SNAPSHOT.jar
cd C:\Users\maxmy\IdeaProjects\htc-code-2020\trace-aggregator & %userprofile%/path.bat & mvn clean package -Dmaven.test.skip=true & java -Xms1500m -Xmx1500m -server -jar target/trace-aggregator-0.0.1-SNAPSHOT.jar
cd C:\Users\maxmy\IdeaProjects\htc-code-2020\trace-filter & %userprofile%/path.bat & mvn clean package -Dmaven.test.skip=true & java -Xms3500m -Xmx3500m -server -jar target/trace-filter-0.0.1-SNAPSHOT.jar
cd C:\Users\maxmy\IdeaProjects\htc-code-2020\trace-filter & %userprofile%/path.bat & java -Xms3500m -Xmx3500m -server -jar target/trace-filter-0.0.1-SNAPSHOT.jar --server.port=8001
```

### Docker Instruction
```
系统安装并启动了docker
```
###Command
```
docker pull registry.cn-hangzhou.aliyuncs.com/cloud_native_match/tail-base-sampling:0.2
docker run --rm -it  --net host -e "SERVER_PORT=8000" --name "clientprocess1" -d registry.cn-hangzhou.aliyuncs.com/cloud_native_match/tail-base-sampling:0.2
docker run --rm -it  --net host -e "SERVER_PORT=8001" --name "clientprocess2" -d registry.cn-hangzhou.aliyuncs.com/cloud_native_match/tail-base-sampling:0.2
docker run --rm -it  --net host -e "SERVER_PORT=8002" --name "backendprocess" -d registry.cn-hangzhou.aliyuncs.com/cloud_native_match/tail-base-sampling:0.2

docker pull registry.cn-hangzhou.aliyuncs.com/cloud_native_match/scoring:0.1
docker run --rm --net host -e "SERVER_PORT=8081" --name scoring -d registry.cn-hangzhou.aliyuncs.com/cloud_native_match/scoring:0.1
```
###Scoring Output
```
begin output result :
{"score":1008,"f1":80000000,"checkSumRightCount":800,"checkSumWrongCount":0,"checkSumMissCount":0,"noErrorTracingCount":0,"useTime":79289,"startTime":1606067213316,"endTime":1606067292605}
 end output result.
```
##Docker run Max's app
###Requirement
```
系统安装并启动了docker
```
###Steps
```
1. 把jdk8-271(重命名为jdk8.tar.gz)放进trace-aggregator和trace-filter的文件夹中(或者改start.sh的jdk版本)
2. 把打好的jar分别放进trace-image的文件夹中
3. docker build -t "trace-image" .
```
###Running Commands
```
docker run --rm -it --net host -e "SERVER_PORT=8000" -m=4G --memory-swap=0 --cpuset-cpus="0,1" --name "trace-filter1" -d trace-image
docker run --rm -it --net host -e "SERVER_PORT=8001" -m=4G --memory-swap=0 --cpuset-cpus="2,3" --name "trace-filter2" -d trace-image
docker run --rm -it --net host -e "SERVER_PORT=8002" -m=2G --memory-swap=0 --cpuset-cpus="4" --name "trace-aggregator" -d trace-image
docker run --rm --net host -e "SERVER_PORT=8081" -m=1G --memory-swap=0 --cpuset-cpus="5,6" --name scoring -d registry.cn-hangzhou.aliyuncs.com/cloud_native_match/scoring:0.1
docker run --rm --net host -e "SERVER_PORT=8081" -m=1G --memory-swap=0 --cpuset-cpus="5,6" --name scoring -d registry.cn-hangzhou.aliyuncs.com/cloud_native_match/scoring:0.2
```
###Push Commands
```
system start docker
cd /usr/local/src/trace-image
cp ../trace-aggregator/target/trace-aggregator-0.0.1-SNAPSHOT.jar .
docker build -t "trace-image" .
docker login --username=ethanlhliang registry.cn-shanghai.aliyuncs.com
docker tag trace-image registry.cn-shanghai.aliyuncs.com/htc-code-2020/htc-code-2020:<version>
docker push registry.cn-shanghai.aliyuncs.com/htc-code-2020/htc-code-2020:<version>
```