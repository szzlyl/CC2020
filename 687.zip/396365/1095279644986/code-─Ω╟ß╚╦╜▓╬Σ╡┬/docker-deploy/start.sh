if   [  $SERVER_PORT == 8002  ];
then
  /usr/local/src/jdk-11.0.9/bin/java -Dserver.port=$SERVER_PORT -Xms1500m -Xmx1500m -server -jar /usr/local/src/trace-aggregator-0.0.1-SNAPSHOT.jar
else
  /usr/local/src/jdk-11.0.9/bin/java -Dserver.port=$SERVER_PORT -Xms3500m -Xmx3500m -server -jar /usr/local/src/trace-filter-0.0.1-SNAPSHOT.jar
fi