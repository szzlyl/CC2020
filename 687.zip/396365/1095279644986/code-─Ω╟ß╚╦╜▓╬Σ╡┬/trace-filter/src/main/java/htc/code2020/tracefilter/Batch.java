package htc.code2020.tracefilter;

import lombok.*;

import java.nio.ByteBuffer;
import java.util.concurrent.Semaphore;

@RequiredArgsConstructor
@Getter
@Setter
public class Batch {
    private final int pos;
    private final byte[] data;
    private final ByteBuffer lines;
    private final Semaphore semaphore;
    private int dataSize = 0;
    private int linesSize = 0;
    private byte[] firstHalf;
    private byte[] lastHalf;
}
