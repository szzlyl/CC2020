package htc.code2020.tracefilter;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import org.springframework.util.unit.DataSize;

import java.io.IOException;

public interface ReadClient {
    RangedHttpClient.ContentRangeAndTotalRead read(byte[] buffer, DataSize singleReadSize,
                                                   long start, boolean careContentRange)
            throws IOException, IllegalAccessException;

    @RequiredArgsConstructor
    @Data
    class ContentRangeAndTotalRead {
        private final long contentRange;
        private final int totalRead;
    }
}
