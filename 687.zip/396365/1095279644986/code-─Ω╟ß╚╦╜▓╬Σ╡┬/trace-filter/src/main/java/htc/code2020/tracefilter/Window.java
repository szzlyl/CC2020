package htc.code2020.tracefilter;

import lombok.*;

import java.util.List;
import java.util.Map;
import java.util.Set;

@RequiredArgsConstructor
@Getter
@Setter
public class Window {
    private final int id;
    private final boolean last;
    private final Set<String> badIdSet;
    private final Map<String, List<InDataString>> idLinesMap; // the value is the pos of Lines in the Lines cache
    private final Batch batch;
}
