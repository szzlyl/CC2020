package htc.code2020.tracefilter;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class AggregateRequest {
    private int filterId;
    private boolean last;
    private Map<String, List<String>> idLinesMap;

    public byte[] toBytes() {
        ByteBuf byteBuf = Utils.getBuffer();
        byteBuf.writeInt(filterId);
        byteBuf.writeByte(last ? (byte) 1 : (byte) 0);
        Utils.writeMap(byteBuf, idLinesMap);
        return Utils.asBytes(byteBuf);
    }

    public static AggregateRequest fromBytes(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }

        ByteBuf byteBuf = Unpooled.wrappedBuffer(bytes);
        AggregateRequest request = new AggregateRequest();
        request.filterId = byteBuf.readInt();
        request.last = byteBuf.readByte() > 0;
        request.idLinesMap = Utils.readMap(byteBuf);
        return request;
    }

    public static void main(String[] args) {
        Map<String, List<String>> map = new HashMap<>();
        map.put("1d37a8b17db8568b", Arrays.asList("1d37a8b17db8568b|1589285985482007|3d1e7e1147c1895d|1d37a8b17db8568b|1259|InventoryCenter|/api/traces|192.168.0.2|http.status_code=200&http.url=http://tracing.console.aliyun.com/getOrder&component=java-web-servlet&span.kind=server&http.method=GET"
                , "1d37a8b17db8568b|1589285985482015|4ee98bd6d34500b3|3d1e7e1147c1895d|1251|PromotionCenter|getAppConfig|192.168.0.4|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://localhost:9004/getPromotion?id=1&peer.port=9004&http.method=GET"
                ,"1d37a8b17db8568b|1589285985482023|2a7a4e061ee023c3|3d1e7e1147c1895d|1243|OrderCenter|sls.getLogs|192.168.0.6|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://tracing.console.aliyun.com/getInventory?id=1&peer.port=9005&http.method=GET"));
        map.put("1093e0c1e05431", Arrays.asList("1093e0c1e05431|1589285985482078|1093e0c1e05431|0|1177|InventoryCenter|/nginx_status|192.168.0.20|biz=fxtius&sampler.type=const&sampler.param=1"
                ,"1093e0c1e05431|1589285985482082|2254233fa7bd7c7a|4d3d95fe822bc12a|1179|PromotionCenter|db.AlertDao.listByTitleAndUserId(..)|192.168.0.22|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://tracing.console.aliyun.com/getOrder?id=5&peer.port=9002&http.method=GET"));
        AggregateRequest request = new AggregateRequest(12, true, map);
        byte[] bytes = request.toBytes();
        AggregateRequest request1 = AggregateRequest.fromBytes(bytes);
        System.out.println(request1);
        System.out.println(request1.getIdLinesMap());
    }

}
