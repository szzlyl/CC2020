package htc.code2020.tracefilter;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.unit.DataSize;

import java.time.Duration;
import java.util.concurrent.ThreadPoolExecutor;

@Configuration
@EnableConfigurationProperties(FilterConfig.Properties.class)
public class FilterConfig {

    @ConfigurationProperties(prefix = "htc.filter")
    @Data
    public static class Properties {
        private int windowSize = 20000;
        private int windowQueueSize = 10000;
        private int averageLineLength = 200;
        private int estimatedSameTraceIdSize = 50;
        private int firstPipeSkip = 12;
        private int tagsSkip = 32;

        private int readingParallelism = 25;
        private int parallelPoolSize = Runtime.getRuntime().availableProcessors() + 1;
        private int elasticPoolSize = Runtime.getRuntime().availableProcessors() * 10;
        private int sendingParallelism = 100;

        private String warmUpPath = "/usr/local/src/";
        private String sourceUrl = "http://localhost:<PORT>";
        private Aggregator aggregator = new Aggregator();
        private Timeouts timeouts = new Timeouts();
        private DataSize bufferSize = DataSize.ofMegabytes(256);
        private DataSize totalDataSize = DataSize.ofGigabytes(2);
        private boolean compress = true;

        public int getDataSizeInBytes() {
            return (int) (totalDataSize.toBytes() / readingParallelism);
        }
    }

    @Data
    public static class Timeouts {
        private Duration connect = Duration.ofSeconds(1);
        private Duration read = Duration.ofSeconds(5);
        private Duration write = Duration.ofSeconds(5);
        private Duration windowProcessing = Duration.ofSeconds(10);
        private Duration ready = Duration.ofSeconds(20);
    }

    @Data
    public static class Aggregator {
//        private String baseUri = "tcp://localhost:9000";
        private String tcpHost = "localhost";
        private int tcpPort = 8003;
        private String badIdsRoute = "badIds";
        private String tracesRoute = "traces";
        private String readyUrl = "http://localhost:8002/ready";
        private String warmUpUrl = "http://localhost:8002/warmUp";
        private int maxRetry = 3;
    }

    @Bean("readInputExecutor")
    public AsyncTaskExecutor readInputExecutor(Properties properties) {
        return executor("readInput", properties.readingParallelism);
    }

    @Bean("parallelExecutor")
    public AsyncTaskExecutor parallelExecutor(Properties properties) {
        return executor("parallel", properties.parallelPoolSize);
    }

    @Bean("elasticExecutor")
    public AsyncTaskExecutor elasticExecutor(Properties properties) {
        return executor("elastic", properties.elasticPoolSize);
    }

    private ThreadPoolTaskExecutor executor(String threadNamePrefix, int poolSize) {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(poolSize);
        executor.setMaxPoolSize(poolSize);
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.AbortPolicy());
        executor.setThreadNamePrefix(threadNamePrefix + "-");
        executor.initialize();
        return executor;
    }

    @Bean
    RSocketRequester rSocketRequester(RSocketRequester.Builder builder, Properties properties) {
        return builder.tcp(properties.aggregator.tcpHost, properties.aggregator.tcpPort);
    }
}
