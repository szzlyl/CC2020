package htc.code2020.tracefilter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StopWatch;

import static htc.code2020.tracefilter.Constants.*;

import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;

@Slf4j
@RequiredArgsConstructor
public class BatchProcessor implements Callable<Batch> {
    private final Future<Batch> future;
    private final int firstPipeSkip;
    private final int tagsSkip;
    
    @Override
    public Batch call() throws Exception {
        Batch batch = future.get();

        StopWatch stopWatch = new StopWatch(); // TODO: Clean up before final run
        stopWatch.start();

        int totalRead = batch.getDataSize();
        byte[] data = batch.getData();
        ByteBuffer lines = batch.getLines();

        int lineStartPos = 0;
        int firstPipePos = -1;
        byte hasError = 0;
        char[] keyword = null;
        int keywordPos = 0;
        int linesSize = 0;
        for (int i = 0; i < totalRead; i++) {
            char c = (char) data[i];
            if (c == '\n') {
                if (batch.getLastHalf() == null) {
                    batch.setLastHalf(Arrays.copyOfRange(data, 0, i));
                } else {
                    if (firstPipePos > 0) {
                        lines.putInt(lineStartPos)
                                .putInt(firstPipePos)
                                .putShort((short) (i - lineStartPos))
                                .put(hasError);
                        linesSize ++;
                    }
                }

                firstPipePos = -1;
                keyword = null;
                keywordPos = 0;
                hasError = 0;
                lineStartPos = i + 1;

                i += firstPipeSkip;
            } else if (c == '|') {
                if (firstPipePos < 0) {
                    firstPipePos = i;
                    i += tagsSkip;
                }
            } else {
                if (keyword == null) {
                    if (c == STATUS_CODE[0]) {
                        keyword = STATUS_CODE;
                        keywordPos = 1;
                    } else if (c == ERROR_CODE[0]) {
                        keyword = ERROR_CODE;
                        keywordPos = 1;
                    }
                } else if (keywordPos < keyword.length) {
                    if (c == keyword[keywordPos]) {
                        keywordPos++;
                        if (keywordPos == keyword.length) {
                            if (keyword == STATUS_CODE) {
                                hasError = ((i + 3 >= totalRead) // 200
                                        || data[i + 1] != '2'
                                        || data[i + 2] != '0'
                                        || data[i + 3] != '0') ? (byte) 1 : (byte) 0;
                            } else if (keyword == ERROR_CODE) {
                                hasError = 1;
                            }
                            keyword = null;
                            keywordPos = 0;
                        }
                    } else {
                        keyword = null;
                        keywordPos = 0;
                    }
                }
            }
        }

        if (lineStartPos < totalRead - 1) {
            batch.setFirstHalf(Arrays.copyOfRange(data, lineStartPos, totalRead));
        }
        // Don't remove the cast here, please check out https://github.com/eclipse/jetty.project/issues/3244
        ((Buffer) lines).position(0);
        // lines.flip();
        batch.setLinesSize(linesSize);

        stopWatch.stop();
        // log.debug("Finished processing for batch #{}, total {} lines processed within {} ms",
//                batch.getPos(), linesSize, stopWatch.getTotalTimeMillis());
        return batch;
    }
}
