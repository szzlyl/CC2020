package htc.code2020.tracefilter;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StopWatch;

import java.util.concurrent.Callable;
import java.util.concurrent.Semaphore;

@Slf4j
@AllArgsConstructor
public class BatchReader implements Callable<Batch> {
    private final FilterConfig.Properties properties;
    private final Batch batch;
    private final ReadClient readClient;

    @Override
    public Batch call() throws Exception {
        batch.getSemaphore().acquire();

        StopWatch stopWatch = new StopWatch(); // TODO: Clean up before final run
        stopWatch.start();

        byte[] data = batch.getData();
        int dataSizeInBytes = properties.getDataSizeInBytes();
        long start = batch.getPos() * (long) dataSizeInBytes;
        // log.debug("Start read from: {} for batch #{}", start, batch.getPos());
        int totalRead = readClient.read(data, properties.getBufferSize(), start, false)
                .getTotalRead();
        batch.setDataSize(totalRead);

        stopWatch.stop();
        // log.debug("Finished reading for batch #{}, total {} bytes read within {} ms",
//                batch.getPos(), totalRead, stopWatch.getTotalTimeMillis());
        return batch;
    }
}
