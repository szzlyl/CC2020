package htc.code2020.tracefilter;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public class InDataString {
    private final byte[] data;
    private final int startPos;
    private final int length;

    public String asString() {
        return (new String(data, startPos, length));
    }
}
