package htc.code2020.tracefilter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TraceFilterApplication {

	public static void main(String[] args) {
		SpringApplication.run(TraceFilterApplication.class, args);
	}

}
