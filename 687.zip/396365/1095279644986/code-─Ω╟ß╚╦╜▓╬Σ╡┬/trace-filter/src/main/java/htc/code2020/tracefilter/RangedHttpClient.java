package htc.code2020.tracefilter;

import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.util.unit.DataSize;
import org.springframework.web.client.HttpClientErrorException;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;

import static java.lang.Math.min;

@Slf4j
@RequiredArgsConstructor
public class RangedHttpClient implements ReadClient {
    private final String url;

    public ContentRangeAndTotalRead read(byte[] buffer, DataSize singleReadSize,
                                  long start, boolean careContentRange)
            throws IOException, IllegalAccessException {
        if(start < 0) {
            throw new IllegalArgumentException("Illegal start position " + start);
        }
        URL url = new URL(this.url);
        HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY);
        long end = start + (long) buffer.length - 1L;
        end = end < 0 ? 0 : end;
        // log.debug("start to download range from {} to {}", start, end);
        httpConnection.addRequestProperty("range", "bytes=" + start + "-" + end);
        httpConnection.connect();
        long contentRange = -1;
        int totalRead = 0;
        try {
            int responseCode = httpConnection.getResponseCode();
            if (responseCode == 206) {
                if (careContentRange) {
                    String contentRangeValue = httpConnection.getHeaderField("Content-Range");
                    String contentRangeText = contentRangeValue.substring(contentRangeValue.indexOf('/') + 1);
                    contentRange = Long.parseLong(contentRangeText);
                    // log.debug("contentRange {}", contentRange);
                }

                int contentLength = httpConnection.getContentLength();
                InputStream input = httpConnection.getInputStream();
                int bufferSize = (int) singleReadSize.toBytes();
                while (totalRead < contentLength) {
                    int bufferLen = min(contentLength - totalRead, bufferSize);
                    int len = input.read(buffer, totalRead, bufferLen);
                    totalRead += len;
                }
            } else if (responseCode == 200) {
                throw new IllegalAccessException("Range read is not supported");
            } else {
                throw new HttpClientErrorException(HttpStatus.valueOf(responseCode));
            }
        } finally {
            httpConnection.disconnect();
        }
        return (new ContentRangeAndTotalRead(contentRange, totalRead));
    }
}