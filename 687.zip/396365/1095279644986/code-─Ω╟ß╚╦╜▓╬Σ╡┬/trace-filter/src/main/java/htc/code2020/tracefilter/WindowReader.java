package htc.code2020.tracefilter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.StopWatch;

import java.nio.ByteBuffer;
import java.util.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import static htc.code2020.tracefilter.Constants.*;

@Slf4j
public class WindowReader {
    private final FilterConfig.Properties properties;
    private final List<Future<Batch>> futureList;
    private final BlockingQueue<Window> windowQueue;

    private final AtomicLong lineIdCounter = new AtomicLong(0);
    private final AtomicLong errorCounter = new AtomicLong(0);
    private final AtomicInteger windowIdCounter = new AtomicInteger(0);

    private Set<String> badIdSet;
    private int estimatedMapSize;
    private Map<String, List<InDataString>> idLinesMap;

    public WindowReader(FilterConfig.Properties properties, List<Future<Batch>> futureList,
            BlockingQueue<Window> windowQueue) {
        this.properties = properties;
        this.futureList = futureList;
        this.windowQueue = windowQueue;
        this.estimatedMapSize = (int) Math
                .ceil((double) properties.getWindowSize() / properties.getEstimatedSameTraceIdSize());
        this.badIdSet = new HashSet<>();
        this.idLinesMap = new HashMap<>(estimatedMapSize);
    }

    public void read() throws ExecutionException, InterruptedException {
        // log.debug("Start reading processed batches");

        StopWatch stopWatch = new StopWatch(); // TODO: Clean up before final run
        stopWatch.start();

        Batch batch = null;
        for (int i = 0; i < futureList.size(); i++) {
            batch = futureList.get(i).get();
            handleFirstLine(i);
            handleLines(batch);
            // handle the last line
            if ((i + 1) == futureList.size() && batch.getFirstHalf() != null) {
                handleSpecialLine(ByteBuffer.wrap(batch.getFirstHalf()), batch);
            }
        }

        Window window = new Window(windowIdCounter.incrementAndGet(), true, badIdSet, idLinesMap, batch);
        windowQueue.put(window);

        stopWatch.stop();
        // log.debug("Finished reading {} lines, found {} problematic ones, for {} batches, within {}ms",
//                lineIdCounter.get(), errorCounter.get(), futureList.size(), stopWatch.getTotalTimeMillis());
    }

    @RequiredArgsConstructor
    private static class LineWrapper {
        final byte[] data;
        final int lineStartPos, firstPipePos;
        final short lineLength;
        final boolean problematic;
    }

    private void handleLines(Batch batch) throws InterruptedException {
        for (int i = 0; i < batch.getLinesSize(); i++) {
            ByteBuffer byteBuffer = batch.getLines();
            int lineStartPos = byteBuffer.getInt();
            int firstPipePos = byteBuffer.getInt();
            short lineLength = byteBuffer.getShort();
            boolean problematic = byteBuffer.get() > 0;
            byte[] data = batch.getData();
            handleLine(lineStartPos, firstPipePos, lineLength, problematic, data, batch);
        }
    }

    private void handleLine(int lineStartPos, int firstPipePos, short lineLength, boolean problematic, byte[] data,
            Batch batch) throws InterruptedException {
        String traceId = new String(data, lineStartPos, firstPipePos - lineStartPos);
        List<InDataString> lines = idLinesMap.computeIfAbsent(traceId, key -> new ArrayList<>());
        InDataString line = new InDataString(data, lineStartPos, lineLength);
        lines.add(line);
        if (problematic) {
            boolean added = badIdSet.add(traceId);
            if (added && log.isTraceEnabled()) {
                // log.trace("Added {} to bad trace ids set", traceId);
            }
            errorCounter.getAndIncrement();
        }
        long lineId = lineIdCounter.incrementAndGet();
        if (lineId % properties.getWindowSize() == 0) {
            Window window = new Window(windowIdCounter.incrementAndGet(), false, badIdSet, idLinesMap, batch);
            windowQueue.put(window);
            // log.debug("Finished reading for window #{}, found {} badIds and {} idLines entries", window.getId(),
//                    window.getBadIdSet().size(), window.getIdLinesMap().size());

            badIdSet = new HashSet<>();
            idLinesMap = new HashMap<>(estimatedMapSize);
        }
    }

    private void handleFirstLine(int i)
            throws ExecutionException, InterruptedException {
        Batch batch = futureList.get(i).get();
        byte[] lastHalf = batch.getLastHalf();
        ByteBuffer firstLine;
        if (i == 0) {
            firstLine = ByteBuffer.wrap(lastHalf);
        } else {
            byte[] firstHalf = futureList.get(i-1).get().getFirstHalf();
            int firstHalfLen = (firstHalf != null ? firstHalf.length : 0);
            int lastHalfLen = (lastHalf != null ? lastHalf.length : 0);
            firstLine = ByteBuffer.allocate(firstHalfLen + lastHalfLen);
            if (firstHalf != null) {
                firstLine.put(firstHalf);
            }
            if (lastHalf != null) {
                firstLine.put(lastHalf);
            }
        }

        handleSpecialLine(firstLine, batch);
    }

    private void handleSpecialLine(ByteBuffer firstLine, Batch batch) throws InterruptedException {
        byte[] bytes = firstLine.array();
        String line = new String(bytes);
//        // log.debug("Special line: {}", line);
        int firstPipePos = line.indexOf('|');
        boolean problematic = line.lastIndexOf(ERROR_CODE_STR) >= 0
                                || (line.lastIndexOf(STATUS_CODE_STR) >= 0
                                    && line.lastIndexOf(STATUS_CODE_200_STR) < 0);
        handleLine(0, firstPipePos, (short) bytes.length, problematic, bytes, batch);
    }

}
