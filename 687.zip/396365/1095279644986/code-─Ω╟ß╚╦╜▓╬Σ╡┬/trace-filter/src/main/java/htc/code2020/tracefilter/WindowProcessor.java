package htc.code2020.tracefilter;

import static java.util.Optional.ofNullable;

import java.nio.Buffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.util.StopWatch;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class WindowProcessor extends Thread {
    private final int filterId;
    private final FilterConfig.Properties properties;
    private final BlockingQueue<Window> windowQueue;
    private final RSocketRequester rsRequester;
    private final AsyncTaskExecutor elasticExecutor;
    private final AtomicBoolean warmUpFinished;

    public WindowProcessor(String name, int filterId, FilterConfig.Properties properties,
            BlockingQueue<Window> windowQueue, RSocketRequester rsRequester, 
            AsyncTaskExecutor elasticExecutor, AtomicBoolean warmUpFinished) {
        super(name);
        this.filterId = filterId;
        this.properties = properties;
        this.windowQueue = windowQueue;
        this.rsRequester = rsRequester;
        this.elasticExecutor = elasticExecutor;
        this.warmUpFinished = warmUpFinished;
    }

    @Override
    public void run() {
        // log.debug("Started processing");

        StopWatch stopWatch = new StopWatch(); // TODO: Clean up before final run
        stopWatch.start();

        Window previous = null, current = null, next = null;
        List<Future<?>> futures = new CopyOnWriteArrayList<>();
        AtomicReference<AggregateRequest> lastAggregateRequest = new AtomicReference<>();
        try {
            while (!interrupted()) {
                if (current == null) {
                    // // log.debug("Started taking the first entry from the queue");
                    current = windowQueue.take();
                } else if (next != null) {
                    current = next;
                } else {
                    log.error("End the thread because current window is null");
                    break;
                }

                next = current.isLast() ? null : windowQueue.take();
                processWindow(previous, current, next, futures, lastAggregateRequest);
                previous = current;

                if (current.isLast()) {
                    processLastWindow(current, futures, lastAggregateRequest.get());
                    break;
                }
            }
        } catch (InterruptedException e) {
            log.error("Got interrupted when waiting for the window queue to has entries", e);
            Thread.currentThread().interrupt();
        }

        stopWatch.stop();
        log.info("Finished processing for all windows within {}ms", stopWatch.getTotalTimeMillis());
        warmUpFinished.set(true);
    }

    private void processLastWindow(Window current, List<Future<?>> futures,
                                   AggregateRequest lastAggregateRequest)
            throws InterruptedException {
        // log.debug("Waiting for {} not-last aggregate requests to be finished.", futures.size());
        for (Future<?> future : futures) {
            try {
                future.get();
            } catch (ExecutionException e) {
                log.error("Failed to send lines", e);
            }
        }
        // log.debug("Send the last aggregate request");
        if (lastAggregateRequest != null) {
            (new AggregateRequestTask(lastAggregateRequest)).run();
        }

        // DO NOT REMOVE THE IS CAST HERE
        ((Buffer) current.getBatch().getLines()).position(0);
        // current.getBatch().getLines().flip();
        current.getBatch().getSemaphore().release();
        windowQueue.clear();
    }

    private void processWindow(Window previous, Window current, Window next, List<Future<?>> futures,
                               AtomicReference<AggregateRequest> lastAggregateRequest) {
        BadIdRequest request = new BadIdRequest(filterId, current.getId(), current.isLast(), current.getBadIdSet());
        // log.debug("Sent request: {} with {} current bad ids", request, request.getBadIdSet().size());
        BadIdResponse response = rsRequester.route(properties.getAggregator().getBadIdsRoute())
                .data(request.toBytes())
                .retrieveMono(new ParameterizedTypeReference<byte[]>() { })
                .map(BadIdResponse::fromBytes)
                .block();
        if (response != null) {
            // log.debug("Received {} badIdsFromOthers for window id {}", response.getBadIdsFromOthers().size(),
//                    response.getWindowId());
            Set<String> badIdsFromBoth = new HashSet<>(current.getBadIdSet());
            badIdsFromBoth.addAll(response.getBadIdsFromOthers());
            Map<String, List<String>> idLinesMap = new HashMap<>();
            for (String badId : badIdsFromBoth) {
                List<InDataString> wrappedLines = getLinesIn3Windows(previous, current, next, badId);
                List<String> lines = new ArrayList<>(wrappedLines.size());
                for (InDataString wrappedLine : wrappedLines) {
                    String line = wrappedLine.asString();
                    lines.add(line);
                    // log.trace("Added line: [{}] to bad id lines map", line);
                }
                idLinesMap.put(badId, lines);
                ofNullable(next).ifPresent(window -> window.getBadIdSet().remove(badId));
                // log.debug("Found {} traces in both current and next window for id {}", lines.size(), badId);
            }

            if (previous != null && previous.getBatch() != current.getBatch()) {
                ((Buffer) previous.getBatch().getLines()).position(0);
                // previous.getBatch().getLines().flip();
                previous.getBatch().getSemaphore().release();
            }

            AggregateRequest aggregateRequest = new AggregateRequest(filterId, current.isLast(), idLinesMap);
            if (!aggregateRequest.isLast()) {
                futures.add(elasticExecutor.submit(new AggregateRequestTask(aggregateRequest)));
            } else {
                lastAggregateRequest.set(aggregateRequest);
            }
        }
    }

    private List<InDataString> getLinesIn3Windows(Window previous, Window current, Window next, String badId) {
        List<InDataString> lines = current.getIdLinesMap().getOrDefault(badId, new LinkedList<>());
        if (previous != null) {
            List<InDataString> linesInPrevious = previous.getIdLinesMap().get(badId);
            if (linesInPrevious != null) {
                lines.addAll(linesInPrevious);
            }
        }
        if (next != null) {
            List<InDataString> linesInNext = next.getIdLinesMap().get(badId);
            if (linesInNext != null) {
                lines.addAll(linesInNext);
            }
        }
        return lines;
    }

    @RequiredArgsConstructor
    private class AggregateRequestTask implements Runnable {
        final AggregateRequest aggregateRequest;

        @Override
        public void run() {
            rsRequester.route(properties.getAggregator().getTracesRoute())
                    .data(aggregateRequest.toBytes())
                    .send()
//                    .doOnSuccess(v -> log.debug("Sent request {} with {} id lines pairs",
//                            aggregateRequest, aggregateRequest.getIdLinesMap().size()))
                    .block();
        }
    }
}