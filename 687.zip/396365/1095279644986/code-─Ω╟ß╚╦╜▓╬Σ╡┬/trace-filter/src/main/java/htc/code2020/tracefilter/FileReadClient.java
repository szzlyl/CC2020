package htc.code2020.tracefilter;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.unit.DataSize;

import java.io.*;

@Slf4j
@RequiredArgsConstructor
public class FileReadClient implements ReadClient {
    private final String filePath;

    @Override
    public ContentRangeAndTotalRead read(byte[] buffer, DataSize singleReadSize, long start, boolean careContentRange) throws IOException, IllegalAccessException {
        long totalLength = new File(filePath).length();
        if (careContentRange) {
            return new ContentRangeAndTotalRead(totalLength,0);
        } else {
            int totalRead = 0;
            try(FileInputStream fileInputStream = new FileInputStream(filePath);){
                int currentRead = fileInputStream.read(buffer,totalRead,(int)(totalLength<buffer.length?totalLength-totalRead:buffer.length-totalRead));
                while (currentRead!=0) {
                    totalRead += currentRead;
                    currentRead = fileInputStream.read(buffer,totalRead,(int)(totalLength<buffer.length?totalLength-totalRead:buffer.length-totalRead));
                }
            }
            return new ContentRangeAndTotalRead(totalLength,totalRead);
        }
    }
}
