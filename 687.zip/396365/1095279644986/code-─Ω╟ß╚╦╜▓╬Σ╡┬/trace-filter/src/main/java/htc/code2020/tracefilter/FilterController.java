package htc.code2020.tracefilter;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.rsocket.RSocketRequester;
import org.springframework.util.unit.DataSize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

import static htc.code2020.tracefilter.Constants.*;

@RestController
@Slf4j
public class FilterController {
    private final int serverPort;
    private final FilterConfig.Properties properties;
    private final RSocketRequester rsRequester;
    private final RestTemplate restTemplate;
    private final BlockingQueue<Window> windowQueue;

    private final AsyncTaskExecutor readInputExecutor;
    private final AsyncTaskExecutor parallelExecutor;
    private final AsyncTaskExecutor elasticExecutor;

    private final List<byte[]> dataList;
    private final List<ByteBuffer> linesList;
    private final List<Semaphore> semaphores;
    private List<Batch> batchList;

    private final AtomicBoolean warmUpFinished = new AtomicBoolean(false);
    private final AtomicBoolean warmUpStarted = new AtomicBoolean(false);

    public FilterController(@Value("${server.port:8000}") int serverPort, FilterConfig.Properties properties,
            RSocketRequester.Builder rsRequestBuilder, RestTemplateBuilder restTemplateBuilder,
            @Qualifier("readInputExecutor") AsyncTaskExecutor readInputExecutor,
            @Qualifier("parallelExecutor") AsyncTaskExecutor parallelExecutor,
            @Qualifier("elasticExecutor") AsyncTaskExecutor elasticExecutor) {
        this.serverPort = serverPort;
        this.properties = properties;
        this.rsRequester = rsRequestBuilder.tcp(properties.getAggregator().getTcpHost(),
                properties.getAggregator().getTcpPort());
        this.restTemplate = restTemplateBuilder.build();
        this.windowQueue = new LinkedBlockingQueue<>(properties.getWindowQueueSize());
        this.readInputExecutor = readInputExecutor;
        this.parallelExecutor = parallelExecutor;
        this.elasticExecutor = elasticExecutor;

        int readingParallelism = properties.getReadingParallelism();

        int dataSize = properties.getDataSizeInBytes();
        int linesSize = ((int) Math.ceil((double) dataSize / properties.getAverageLineLength())) * TRACE_LENGTH;
        this.dataList = new ArrayList<>(readingParallelism);
        this.linesList = new ArrayList<>(readingParallelism);
        this.semaphores = new ArrayList<>(readingParallelism);
        for (int i = 0; i < readingParallelism; i++) {
            this.semaphores.add(new Semaphore(1));
            this.dataList.add(new byte[dataSize]);
            // log.debug("Allocated memory for data: {}MB", DataSize.ofBytes(dataSize).toMegabytes());
            this.linesList.add(ByteBuffer.allocate(linesSize));
            // log.debug("Allocated memory for lines: {}MB", DataSize.ofBytes(linesSize).toMegabytes());
        }
    }

    @RequestMapping("/ready")
    public ResponseEntity<String> ready() throws InterruptedException {
        boolean ok = false;
        boolean warmUpFinished = this.warmUpFinished.get();
        if (!warmUpFinished){
            if (!warmUpStarted.getAndSet(true)) {
                try {
                    boolean warmUpReady = restTemplate.getForEntity(properties.getAggregator().getWarmUpUrl(), String.class)
                            .getStatusCode().value() == 200;
                    if (warmUpReady) {
                        setParameter(null);
                    }
                } catch (Exception e) {
                    warmUpStarted.set(false);
                }
            }
        } else {
            try {
                ok = restTemplate.getForEntity(properties.getAggregator().getReadyUrl(), String.class)
                        .getStatusCode().value() == 200;
            } catch (Exception e) { }
        }

        return ok ?
                ResponseEntity.ok("ok") :
                ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body("not-ok");
    }

    @RequestMapping("/setParameter")
    public synchronized String setParameter(@RequestParam Integer port) throws Exception {
        String url;
        if (port != null) {
            String fileName = (serverPort == 8000 ? "/trace1.data" : "/trace2.data");
            url = properties.getSourceUrl().replace("<PORT>", port.toString()) + fileName;
        } else {
            String fileName = (serverPort == 8000 ? "/trace1.data" : "/trace2.data");
            url = properties.getWarmUpPath() + fileName;
        }
        Thread thread = new Thread(() -> {
            try {
                ReadClient rangedHttpClient;
                if (port != null) {
                    rangedHttpClient = new RangedHttpClient(url);
                } else {
                    rangedHttpClient = new FileReadClient(url);
                }
                long totalLength = rangedHttpClient.read(new byte[1], DataSize.ofBytes(1), 0, true)
                        .getContentRange();

                int readingParallelism = properties.getReadingParallelism();
                int dataSize = properties.getDataSizeInBytes();
                int batchSize = (int) Math.ceil((double) totalLength / dataSize);
                // log.debug("Total file length: {}, data size: {}, batch size: {}", totalLength, dataSize, batchSize);
                batchList = new ArrayList<>(batchSize);
                for (int i = 0; i < batchSize; i ++) {
                    int pos = i % readingParallelism;
                    this.batchList.add(new Batch(i,
                            this.dataList.get(pos),
                            this.linesList.get(pos),
                            this.semaphores.get(pos)));
                }

                // log.debug("Started filtering");
                List<Future<Batch>> readInputFutures = new ArrayList<>(batchList.size());
                for (Batch batch : batchList) {
                    readInputFutures.add(readInputExecutor.submit(new BatchReader(properties, batch,
                            rangedHttpClient)));
                }
                List<Future<Batch>> processBatchFutures = new ArrayList<>(batchList.size());
                for (Future<Batch> future : readInputFutures) {
                    processBatchFutures.add(parallelExecutor.submit(
                            new BatchProcessor(future, properties.getFirstPipeSkip(), properties.getTagsSkip())));
                }

                WindowReader windowReader = new WindowReader(properties, processBatchFutures, windowQueue);
                windowReader.read();
            } catch (Exception e) {
                log.error("Failed to filter", e);
            }
        }, "filter");
        thread.setDaemon(true);
        thread.start();

        WindowProcessor processor = new WindowProcessor("processor", serverPort, properties,
                windowQueue, rsRequester, elasticExecutor, warmUpFinished);
        processor.setDaemon(true);
        processor.start();

        return "ok";
    }
}