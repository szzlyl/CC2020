package htc.code2020.tracefilter;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class BadIdResponse {
    private int windowId;
    private Set<String> badIdsFromOthers;

    public byte[] toBytes() {
        ByteBuf byteBuf = Utils.getBuffer();
        byteBuf.writeInt(windowId);
        Utils.writeSet(byteBuf, badIdsFromOthers);
        return Utils.asBytes(byteBuf);
    }

    public static BadIdResponse fromBytes(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }

        ByteBuf byteBuf = Unpooled.wrappedBuffer(bytes);
        BadIdResponse response = new BadIdResponse();
        response.windowId = byteBuf.readInt();
        response.badIdsFromOthers = Utils.readSet(byteBuf);
        return response;
    }
}
