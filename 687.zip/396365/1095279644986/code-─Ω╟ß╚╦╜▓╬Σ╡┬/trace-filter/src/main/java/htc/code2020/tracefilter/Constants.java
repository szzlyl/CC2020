package htc.code2020.tracefilter;

public interface Constants {
    String ERROR_CODE_STR = "error=1";
    String STATUS_CODE_STR = "http.status_code=";
    String STATUS_CODE_200_STR = STATUS_CODE_STR + "200";
    char[] ERROR_CODE = ERROR_CODE_STR.toCharArray();
    char[] STATUS_CODE = STATUS_CODE_STR.toCharArray();
    int SLEEP_INTERVAL = 50;

    // 11 = 4 (int, lineStartPos) + 4 (int, firstPipeLine) + 2 (short, length) + 1 (boolean, hasError)
    int TRACE_LENGTH = 11;
}
