package htc.code2020.tracefilter;

import org.springframework.util.unit.DataSize;

import java.io.*;

import static htc.code2020.tracefilter.Constants.*;

public class Playground {
    public static void main(String[] args) throws Exception {
        String path = "/home/max/IdeaProjects/htc-code-2020/test-data/trace1.data";
        try (BufferedReader reader = new BufferedReader(new FileReader(path),
                (int) DataSize.ofMegabytes(512).toBytes())) {
            String line;
            int lineCounter = 0, errorCount = 0, correctCount = 0;
            while ((line = reader.readLine()) != null) {
                lineCounter ++;
                boolean problematic = line.lastIndexOf(ERROR_CODE_STR) >= 0
                        || (line.lastIndexOf(STATUS_CODE_STR) >= 0
                        && line.lastIndexOf(STATUS_CODE_200_STR) < 0);
                if (problematic) {
                    errorCount ++;
                } else {
                    correctCount ++;
                }
            }
            System.out.printf("Total %d lines, %d error, %d ok", lineCounter, errorCount, correctCount);
        }
    }
}
