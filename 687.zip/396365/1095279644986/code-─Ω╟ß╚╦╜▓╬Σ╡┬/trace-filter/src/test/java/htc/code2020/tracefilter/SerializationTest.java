package htc.code2020.tracefilter;

import org.junit.jupiter.api.Test;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;

public class SerializationTest {
    @Test
    public void serializeBadIdRequest() {
        BadIdRequest a = new BadIdRequest(12, 34, true, Stream.of("abc", "efg").collect(Collectors.toSet()));
        byte[] bytes = a.toBytes();
        BadIdRequest b = BadIdRequest.fromBytes(bytes);
        assertThat(a.getId()).isEqualTo(b.getId());
        assertThat(a.getFilterId()).isEqualTo(b.getFilterId());
        assertThat(a.isLast()).isEqualTo(b.isLast());
        assertThat(a.getBadIdSet()).hasSameElementsAs(b.getBadIdSet());
    }

    @Test
    public void serializeBadIdResponse() {
        BadIdResponse a = new BadIdResponse(12, Stream.of("abc", "efg").collect(Collectors.toSet()));
        byte[] bytes = a.toBytes();
        BadIdResponse b = BadIdResponse.fromBytes(bytes);
        assertThat(a.getWindowId()).isEqualTo(b.getWindowId());
        assertThat(a.getBadIdsFromOthers()).hasSameElementsAs(b.getBadIdsFromOthers());
    }

    @Test
    public void serializeAggregateRequest() {
        Map<String, List<String>> map = new HashMap<>();
        map.put("1d37a8b17db8568b", Arrays.asList("1d37a8b17db8568b|1589285985482007|3d1e7e1147c1895d|1d37a8b17db8568b|1259|InventoryCenter|/api/traces|192.168.0.2|http.status_code=200&http.url=http://tracing.console.aliyun.com/getOrder&component=java-web-servlet&span.kind=server&http.method=GET"
                , "1d37a8b17db8568b|1589285985482015|4ee98bd6d34500b3|3d1e7e1147c1895d|1251|PromotionCenter|getAppConfig|192.168.0.4|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://localhost:9004/getPromotion?id=1&peer.port=9004&http.method=GET"
                ,"1d37a8b17db8568b|1589285985482023|2a7a4e061ee023c3|3d1e7e1147c1895d|1243|OrderCenter|sls.getLogs|192.168.0.6|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://tracing.console.aliyun.com/getInventory?id=1&peer.port=9005&http.method=GET"));
        map.put("1093e0c1e05431", Arrays.asList("1093e0c1e05431|1589285985482078|1093e0c1e05431|0|1177|InventoryCenter|/nginx_status|192.168.0.20|biz=fxtius&sampler.type=const&sampler.param=1"
                ,"1093e0c1e05431|1589285985482082|2254233fa7bd7c7a|4d3d95fe822bc12a|1179|PromotionCenter|db.AlertDao.listByTitleAndUserId(..)|192.168.0.22|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://tracing.console.aliyun.com/getOrder?id=5&peer.port=9002&http.method=GET"));
        AggregateRequest a = new AggregateRequest(12, true, map);
        byte[] bytes = a.toBytes();
        AggregateRequest b = AggregateRequest.fromBytes(bytes);
        assertThat(a.getFilterId()).isEqualTo(b.getFilterId());
        assertThat(a.isLast()).isEqualTo(b.isLast());
        assertThat(a.getIdLinesMap()).contains(
                new AbstractMap.SimpleEntry<>("1d37a8b17db8568b", Arrays.asList("1d37a8b17db8568b|1589285985482007|3d1e7e1147c1895d|1d37a8b17db8568b|1259|InventoryCenter|/api/traces|192.168.0.2|http.status_code=200&http.url=http://tracing.console.aliyun.com/getOrder&component=java-web-servlet&span.kind=server&http.method=GET"
                        , "1d37a8b17db8568b|1589285985482015|4ee98bd6d34500b3|3d1e7e1147c1895d|1251|PromotionCenter|getAppConfig|192.168.0.4|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://localhost:9004/getPromotion?id=1&peer.port=9004&http.method=GET"
                        ,"1d37a8b17db8568b|1589285985482023|2a7a4e061ee023c3|3d1e7e1147c1895d|1243|OrderCenter|sls.getLogs|192.168.0.6|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://tracing.console.aliyun.com/getInventory?id=1&peer.port=9005&http.method=GET")),
                new AbstractMap.SimpleEntry<>("1093e0c1e05431", Arrays.asList("1093e0c1e05431|1589285985482078|1093e0c1e05431|0|1177|InventoryCenter|/nginx_status|192.168.0.20|biz=fxtius&sampler.type=const&sampler.param=1"
                        ,"1093e0c1e05431|1589285985482082|2254233fa7bd7c7a|4d3d95fe822bc12a|1179|PromotionCenter|db.AlertDao.listByTitleAndUserId(..)|192.168.0.22|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://tracing.console.aliyun.com/getOrder?id=5&peer.port=9002&http.method=GET")));
    }
}
