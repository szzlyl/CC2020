package htc.code2020.tracefilter;

import java.nio.ByteBuffer;

public class StringBytesTest {
    public static void main(String[] args) {
//        String abc = new String("abc");
        byte[] bytes = new byte[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
        String str = new String(bytes, 1, 3);
        System.out.println(str);
        bytes[2] = 'z';
        System.out.println(str);

        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes, 1, 3);
        String str2 = new String(byteBuffer.array(), byteBuffer.arrayOffset(), byteBuffer.remaining());
        System.out.println(str2);

        InDataString inDataString = new InDataString(bytes, 2, 3);
        System.out.println(inDataString.asString());
    }
}
