package com.hsbc.hss.tianchi.firedust.client;


import com.hsbc.hss.tianchi.firedust.common.Package;
import com.hsbc.hss.tianchi.firedust.common.Constants;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;

public class DataDownload {

    private static byte[] cut = new byte[10240];//cut data
    private static int cutLength = 0;//cut data length
    private static int rangeIndex;

    public static void startDownload() throws Exception {
        String path = "http://127.0.0.1:" + Constants.DATA_SOURCE_PORT + (Constants.LISTEN_PORT == 8000 ? "/trace1.data" : "/trace2.data");
        URL url = new URL(path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY);
        InputStream in = conn.getInputStream();

        int n, len;
        byte[] data;
        Range range;
        do {
            //get 1 empty range
            range = BookShelf.getEmptyRange(rangeIndex);
            range.clear();
            range.rangeIndex = rangeIndex;

            //copy cut
            data = range.data;
            System.arraycopy(cut, 0, data, 0, cutLength);
            len = cutLength;

            //read 1 range
            while ((n = in.read(data, len, Range.LEN - len)) != -1) {
                len += n;
                if (len == Range.LEN) {
                    break;
                }
            }

            //find cut
            for (cutLength = 0; cutLength < 10240; cutLength++) {
                if (data[len - 1 - cutLength] == '\n') {//
                    System.arraycopy(data, len - cutLength, cut, 0, cutLength);
                    break;
                }
            }

            BookShelf.moveEmptyToFull(rangeIndex);
            range.len = len - cutLength;

            rangeIndex++;

        } while (n != -1);
        Constants.TOTAL_RANGE_COUNT = rangeIndex;
        Package lastPackage = new Package(1, Constants.ROLE, Package.TYPE_DOWNLOAD_FINISH);
        lastPackage.writeRange(rangeIndex);
        Constants.filter.sendPackage(lastPackage);

    }


}
