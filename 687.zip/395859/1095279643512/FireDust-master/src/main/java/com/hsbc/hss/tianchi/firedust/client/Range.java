package com.hsbc.hss.tianchi.firedust.client;


import com.hsbc.hss.tianchi.firedust.common.Constants;
import com.hsbc.hss.tianchi.firedust.common.Package;

public class Range {
    private static final int SKIP_LEN = 112;

    public static final int LEN = 32 * 1024 * 1024;//32M buffer
    public static int count = 1;//total count
    public static Package errorPackage = new Package(2, Constants.ROLE, Package.TYPE_BAD_TRACE_ID);
    public int rangeIndex = 0;
    public byte[] data = new byte[32 * 1024 * 1024 + 1024];//32M buffer
    public int len = 0;//data length
    public int[][][] hashBucket = new int[1024 * 1024][][];//2M
    public int[][][] bucket = new int[10000][2][200];
    public int p;//bucket index

    public void filterBadTraceId() {
        int i = 0;
        do {
            int hash = (data[i] + (data[i + 1] << 3) + (data[i + 2] << 6) + (data[i + 3] << 9) + (data[i + 4] << 12)) & 0XFFFF;
            int l = filterBadTraceAndGetSpanIndex(data, i);
            put(hash, i, l);
            if (++count % Constants.HANDLED_PER_COUNT == 0) {
                Constants.filter.sendPackage(errorPackage);
                BookShelf.putErrorPackage(errorPackage, rangeIndex);
                errorPackage = new Package(2, Constants.ROLE, Package.TYPE_BAD_TRACE_ID);
            }
            i = i + l;
        } while (i != len);
    }


    private final int filterBadTraceAndGetSpanIndex(byte[] d, int s) {
        try {
            int i = s + SKIP_LEN;
            while (d[++i] != '\n') {
                if (d[i] == '=') {
                    if (d[i - 5] == '_') {
                        if (d[i + 1] != '2') errorPackage.write(d, s, 16);
                        break;
                    } else if (d[i - 6] == '&' || d[i - 6] == '|') {
                        if (d[i + 1] == '1') errorPackage.write(d, s, 16);
                        break;
                    } else {
                        i++;
                    }
                }
            }
            if (d[i] != '\n') {
                if (i - s < 160) i += 85;
                while (d[++i] != '\n') ;
            }
            return i - s + 1;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public void put(int hash, int s, int len) {
        int[][] tmp;
        tmp = hashBucket[hash];
        if (tmp == null) {
            tmp = hashBucket[hash] = bucket[p++];
            tmp[0][0] = hash;
            tmp[1][0] = 1;
        }
        tmp[0][tmp[1][0]] = s;
        tmp[1][tmp[1][0]] = len;
        tmp[1][0]++;
    }

    public int selectByTraceId(byte k[], byte d[][],int s[], int l[], int start) {
        int hash = (k[0] + (k[1] << 3) + (k[2] << 6) + (k[3] << 9) + (k[4] << 12)) & 0XFFFF;
        int bucket[][] = hashBucket[hash];
        if (bucket == null) return 0;
        int p = start;
        int count = bucket[1][0];
        for (int i = 1; i < count; i++) {
            boolean b = startsWith(data, bucket[0][i], k);
            if (b) {
                d[p] = this.data;
                s[p] = bucket[0][i];
                l[p++] = bucket[1][i];
            }
        }
        return p - start;
    }

    private static boolean startsWith(byte[] data, int s, byte[] key) {
        for (int i = 0; i < key.length; i++) {
            if (data[s + i] != key[i]) return false;
        }
        return true;
    }

    public void clear() {
        //clear data
        len = 0;
        //clear index
        for (int i = 0; i < p; i++) {
            hashBucket[bucket[i][0][0]] = null;
        }
        p = 0;
    }

}
