package com.hsbc.hss.tianchi.firedust.common;

public class Package {
    public static final byte TYPE_START = 0;
    public static final byte TYPE_BAD_TRACE_ID = 1;
    public static final byte TYPE_BAD_TRACE_SPANS = 2;
    public static final byte TYPE_DOWNLOAD_FINISH = 3;
    public static final byte TYPE_END = 4;

    public static final int P_LEN = 0;
    public static final int P_ROLE = 3;
    public static final int P_TYPE = 4;
    public static final int P_RANGE = 5;
    public static final int P_DATA = 7;

    static final byte[] HEX_NUM = new byte[127];

    static {
        for (int i = '0'; i <= '9'; i++) {
            HEX_NUM[i] = (byte) (i - '0');
        }
        for (int i = 'A'; i <= 'F'; i++) {
            HEX_NUM[i] = (byte) (i - 'A' + 10);
        }
        for (int i = 'a'; i <= 'f'; i++) {
            HEX_NUM[i] = (byte) (i - 'a' + 10);
        }
    }

    private byte[] bs;
    private int len = 7;//bs header length
    public boolean isHandle;

    public Package(int k) {
        bs = new byte[k * 1024];
    }

    public Package(byte[] bs, int len) {
        this.bs = bs;
        this.len = len;
    }


    public Package(int k, byte role, byte type) {
        bs = new byte[k * 1024];
        this.bs[P_ROLE] = role;
        this.bs[P_TYPE] = type;
    }

    public int getLen() {
        if (len <= 0) {
            len = ((bs[P_LEN] & 0XFF) << 16) + ((bs[P_LEN + 1] & 0XFF) << 8) + (bs[P_LEN + 2] & 0XFF);
        }
        return len;
    }

    public int getRole() {
        return bs[P_ROLE];
    }

    public int getType() {
        return bs[P_TYPE];
    }

    public byte[] getBs() {
        bs[P_LEN + 0] = (byte) ((len >> 16) & 0XFF);
        bs[P_LEN + 1] = (byte) ((len >> 8) & 0XFF);
        bs[P_LEN + 2] = (byte) (len & 0XFF);
        return bs;
    }

    public Package write(byte[] bs, int start, int len) {
        System.arraycopy(bs, start, this.bs, this.len, len);
        this.len += len;
        return this;
    }

    public void reset(byte role, byte type) {
        bs[P_LEN + 0] = 0;
        bs[P_LEN + 1] = 0;
        bs[P_LEN + 2] = 0;
        this.bs[P_ROLE] = role;
        this.bs[P_TYPE] = type;
        len = 7;
    }

    public Package writeWithDataLen(byte[] bs, int start, int len) {
        this.bs[this.len++] = (byte) ((len >> 8) & 0XFF);
        this.bs[this.len++] = (byte) (len & 0XFF);
        System.arraycopy(bs, start, this.bs, this.len, len);
        this.len += len;
        return this;
    }

    public Package writeRange(int range) {
        this.bs[P_RANGE + 0] = (byte) ((range >> 8) & 0XFF);
        this.bs[P_RANGE + 1] = (byte) (range & 0XFF);
        return this;
    }

    public long getLongTraceId() {
        long v = 0;
        for (int i = P_DATA; i < P_DATA + 16; i++) {
            v = (v << 4) | (HEX_NUM[this.bs[i]]);
        }
        return v;
    }

}

