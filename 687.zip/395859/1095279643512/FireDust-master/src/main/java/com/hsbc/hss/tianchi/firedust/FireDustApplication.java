package com.hsbc.hss.tianchi.firedust;

import com.hsbc.hss.tianchi.firedust.common.Constants;
import com.hsbc.hss.tianchi.firedust.backend.Backend;
import com.hsbc.hss.tianchi.firedust.client.BookShelf;
import com.hsbc.hss.tianchi.firedust.client.Client;

public class FireDustApplication {

    public static void main(String[] args) throws Exception {
        Constants.LISTEN_PORT = 8000;
        try {
            Constants.LISTEN_PORT = Integer.valueOf(args[0]);
        } catch (Exception e) {
        }
        if (Constants.LISTEN_PORT == 8002) {
            Constants.ROLE = Constants.BACKEND;
            new Backend().start();
        } else {
            if (Constants.LISTEN_PORT == 8001) {
                Constants.ROLE = Constants.CLIENT2;
            }
            new Thread(() -> BookShelf.handleData()).start();// create client thread handle data
            new Thread(() -> BookShelf.handleErrorPackage()).start();// create client thread handle bad trace
            Constants.filter = new Client();
            Constants.filter.start();// download data
        }
    }

}
