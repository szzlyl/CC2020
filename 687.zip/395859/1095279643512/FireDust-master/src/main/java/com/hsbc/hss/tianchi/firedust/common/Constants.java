package com.hsbc.hss.tianchi.firedust.common;

import com.hsbc.hss.tianchi.firedust.client.Client;

public class Constants {
    public static final int CLIENT1 = 1;
    public static final int CLIENT2 = 2;
    public static final int BACKEND = 3;

    public static final int CLIENT1_PORT = 8000;
    public static final int CLIENT2_PORT = 8001;
    public static final int BACKEND_PORT = 8002;

    public static int LISTEN_PORT = 8000;
    public static int DATA_SOURCE_PORT = 0;
    public static byte ROLE = CLIENT1;

    public static Client filter;

    public static int TOTAL_RANGE_COUNT = 10000;

    public static final int HANDLED_PER_COUNT = 100000;//send error trace id for each 100000 span

}
