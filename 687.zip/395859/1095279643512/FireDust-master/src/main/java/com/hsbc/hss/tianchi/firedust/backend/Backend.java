package com.hsbc.hss.tianchi.firedust.backend;

import com.carrotsearch.hppc.LongObjectHashMap;
import com.hsbc.hss.tianchi.firedust.common.Package;
import com.hsbc.hss.tianchi.firedust.common.Constants;
import com.hsbc.hss.tianchi.firedust.common.MD5;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.*;
import java.util.*;

public class Backend {
    private OutputStream outToClient1;
    private OutputStream outToClient2;
    protected ServerSocket server;

    private MD5 md5 = new MD5();

    private byte[] result = new byte[5 * 1024 * 1024];//5M
    private int resultLength = 0;
    private int resultLineAndHeaderLen = 198;

    private LongObjectHashMap<Package> longObjectMap = new LongObjectHashMap<>(30000);
    private int endClientNumber = 0;


    public Backend() {
        try {
            byte[] bs = ("POST /api/finished HTTP/1.1\r\n" +
                    "Content-Type: multipart/form-data; boundary=--------------------------201765570601401483330524\r\n" +
                    "Host: localhost:" + Constants.DATA_SOURCE_PORT + "\r\n" +
                    "Content-Length:        \r\n" +
                    "Connection: keep-alive\r\n" +
                    "\r\n" +
                    "----------------------------201765570601401483330524\r\n" +
                    "Content-Disposition: form-data; name=\"result\"\r\n" +
                    "\r\n" +
                    "{"
            ).getBytes();
            resultLineAndHeaderLen = bs.length - 104;
            System.arraycopy(bs, 0, result, 0, bs.length);
            resultLength = bs.length;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void handleDataSourceSocket(Socket socket) throws Exception {
        InputStream in = socket.getInputStream();
        OutputStream out = socket.getOutputStream();
        byte bs[] = new byte[1024];
        int len = in.read(bs);
        if (len > 0) {
            String req = new String(bs, 0, len);
            if (req.contains("ready")) {
                out.write("HTTP/1.1 200 OK\r\n\r\nsuccess".getBytes());
                out.flush();
            }
            if (req.contains("setParameter")) {
                int s = req.indexOf('=');
                int e = req.indexOf(' ', s);
                Constants.DATA_SOURCE_PORT = Integer.valueOf(req.substring(s + 1, e));
                out.write("HTTP/1.1 200 OK\r\n\r\nsuccess".getBytes());
                out.flush();
            }
        }
        in.close();
        out.close();
        socket.close();
    }

    public void handleInputStream(Socket socket) {
        InputStream in = null;
        try {
            in = socket.getInputStream();
            while (true) {
                byte bs[] = new byte[3];
                readInputStream(in, bs, 0, 3);
                int totalLen = ((bs[0] & 0XFF) << 16) + ((bs[1] & 0XFF) << 8) + (bs[2] & 0XFF);
                byte data[] = new byte[totalLen];
                data[0] = bs[0];
                data[1] = bs[1];
                data[2] = bs[2];
                readInputStream(in, data, 3, totalLen - 3);
                Package aPackage = new Package(data, data.length);
                handlePackage(aPackage);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                socket.close();
                in.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void readInputStream(InputStream in, byte[] bs, int s, int n) throws Exception {
        int len;
        while ((len = in.read(bs, s, n)) != -1) {
            if (n - len == 0) break;
            s += len;
            n -= len;
        }
    }

    public void start() throws Exception {
        server = new ServerSocket(Constants.LISTEN_PORT);
        while (Constants.DATA_SOURCE_PORT == 0) {
            Socket socket = server.accept();
            int port = socket.getPort();
            if (port == Constants.CLIENT1_PORT) {
                outToClient1 = socket.getOutputStream();
                new Thread(() -> handleInputStream(socket)).start();
            } else if (port == Constants.CLIENT2_PORT) {
                outToClient2 = socket.getOutputStream();
                new Thread(() -> handleInputStream(socket)).start();
            } else {
                handleDataSourceSocket(socket);
            }
        }

        Package aPackage = new Package(1, Constants.ROLE, Package.TYPE_START);
        sendPackage(aPackage, outToClient1);
        sendPackage(aPackage, outToClient2);
    }

    public void handlePackage(Package aPackage) {
        if (aPackage.getType() == Package.TYPE_BAD_TRACE_ID || aPackage.getType() == Package.TYPE_DOWNLOAD_FINISH) {
            if (aPackage.getRole() == Constants.CLIENT1) {
                sendPackage(aPackage, outToClient2);
            } else {
                sendPackage(aPackage, outToClient1);
            }
        } else if (aPackage.getType() == Package.TYPE_BAD_TRACE_SPANS) {
            synchronized (this) {
                calcCheckSum(aPackage);
            }
        } else if (aPackage.getType() == Package.TYPE_END) {
            synchronized (Backend.class) {
                endClientNumber++;
                if (endClientNumber >= 2) {
                    sendResult();
                }
            }
        }
    }

    private void calcCheckSum(Package aPackage) {
        long traceId = aPackage.getLongTraceId();
        Package pack = longObjectMap.get(traceId);
        if (pack == null) {
            longObjectMap.put(traceId,aPackage);
            return;
        }
        if (pack.isHandle || pack.getRole() == aPackage.getRole()) return;
        pack.isHandle = true;
        mergeAndMd5(pack, aPackage);
    }

    private void mergeAndMd5(Package p1, Package p2) {

        byte[] bs1 = p1.getBs();
        int len1 = p1.getLen();
        byte[] bs2 = p2.getBs();
        int len2 = p2.getLen();
        int i = Package.P_DATA + 16, j = Package.P_DATA + 16;

        int offset = 25;
        int traceIdLen;
        if (bs1[Package.P_DATA + 13] == '|') traceIdLen = 13;
        else if (bs1[Package.P_DATA + 14] == '|') traceIdLen = 14;
        else if (bs1[Package.P_DATA + 15] == '|') traceIdLen = 15;
        else traceIdLen = 16;

        md5.reset();
        int dataLen1 = 0, dataLen2 = 0;
        while (i < len1 || j < len2) {
            try {
                if (i < len1) dataLen1 = ((bs1[i] & 0XFF) << 8) + (bs1[i + 1] & 0XFF);
                if (j < len2) dataLen2 = ((bs2[j] & 0XFF) << 8) + (bs2[j + 1] & 0XFF);
                if (j >= len2) {
                    md5.update(bs1, i + 2, dataLen1);
                    i += dataLen1 + 2;
                } else if (i >= len1) {
                    md5.update(bs2, j + 2, dataLen2);
                    j += dataLen2 + 2;
                } else if (compareBytes(bs1, i + offset, bs2, j + offset) < 0) {
                    md5.update(bs1, i + 2, dataLen1);
                    i += dataLen1 + 2;
                } else {
                    md5.update(bs2, j + 2, dataLen2);
                    j += dataLen2 + 2;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        result[resultLength++] = '"';
        System.arraycopy(bs1, Package.P_DATA, result, resultLength, traceIdLen);
        resultLength += traceIdLen;
        result[resultLength++] = '"';
        result[resultLength++] = ':';
        result[resultLength++] = '"';
        md5.digest(result, resultLength);
        resultLength += 32;
        result[resultLength++] = '"';
        result[resultLength++] = ',';

    }

    private int compareBytes(byte[] bs1, int s1, byte[] bs2, int s2) {
        try {
            for (int i = 0; i < 11; i++) {
                if (bs1[s1 + i] == bs2[s2 + i]) continue;
                return bs1[s1 + i] - bs2[s2 + i];
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }


    public void sendPackage(Package aPackage, OutputStream out) {
        try {
            int len = aPackage.getLen();
            byte bs[] = aPackage.getBs();
            out.write(bs, 0, len);
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void sendResult() {
        try {
            result[resultLength - 1] = '}';//the end char
            byte bs[] = "\r\n----------------------------201765570601401483330524--\r\n".getBytes();
            System.arraycopy(bs, 0, result, resultLength, bs.length);
            resultLength += bs.length;
            //set Content-Length
            String cl = String.valueOf(resultLength - resultLineAndHeaderLen);
            for (int i = 0; i < cl.length(); i++) {
                result[162 + i] = (byte) (cl.charAt(i));
            }

            Socket socket = new Socket("127.0.0.1", Constants.DATA_SOURCE_PORT);
            OutputStream out = socket.getOutputStream();
            out.write(result, 0, resultLength);
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
