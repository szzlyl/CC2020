package com.hsbc.hss.tianchi.firedust.client;

import com.hsbc.hss.tianchi.firedust.common.Constants;
import com.hsbc.hss.tianchi.firedust.common.Package;

public class BookShelf {
    private static final int len = 16; //max 16 range

    private static final Range[] EMPTY_RANGES = new Range[len];
    private static final Range[] FULL_RANGES = new Range[len];
    private static final Range[] HANDLE_RANGES = new Range[len];
    public static final Package[] errorPackages = new Package[2048];//save bad trace id
    public static int errorPackageIndex = 0;
    public static int total_error_package = 10000;
    public static final int[] rows_range = new int[1000];//100000 rows in which range

    static {
        for (int i = 0; i < EMPTY_RANGES.length; i++) {
            EMPTY_RANGES[i] = new Range();
        }
    }


    public static void putErrorPackage(Package aPackage, int rangeIndex) {
        synchronized (errorPackages) {
            errorPackages[errorPackageIndex] = aPackage;
            rows_range[errorPackageIndex] = rangeIndex;
            errorPackageIndex++;
            errorPackages.notify();
        }
    }

    public static Package getErrorPackage(int n) {
        synchronized (errorPackages) {
            if (errorPackages[n] == null) {
                try {
                    errorPackages.wait();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return errorPackages[n];
    }

    public static Range getEmptyRange(int i) {
        synchronized (EMPTY_RANGES) {
            Range range = EMPTY_RANGES[i % len];
            while (range == null) {
                try {
                    EMPTY_RANGES.wait();
                    range = EMPTY_RANGES[i % len];
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            range.rangeIndex = i;
            return range;
        }
    }

    public static void moveHandleToEmpty(int i) {
        synchronized (EMPTY_RANGES) {
            if (i < 0) return;
            try {
                EMPTY_RANGES[i % len] = HANDLE_RANGES[i % len];
                HANDLE_RANGES[i % len] = null;
                EMPTY_RANGES.notify();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static Range getFullRange(int i) {
        synchronized (FULL_RANGES) {
            Range range = FULL_RANGES[i % len];
            while (range == null) {
                try {
                    FULL_RANGES.wait();
                    range = FULL_RANGES[i % len];
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return range;
        }
    }

    public static void moveEmptyToFull(int i) {
        synchronized (FULL_RANGES) {
            try {
                FULL_RANGES[i % len] = EMPTY_RANGES[i % len];
                EMPTY_RANGES[i % len] = null;
                FULL_RANGES.notify();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static Range getHandleRange(int i) {
        synchronized (HANDLE_RANGES) {
            if (i >= Constants.TOTAL_RANGE_COUNT || i < 0) return null;
            Range range = HANDLE_RANGES[i % len];
            while (range == null) {
                try {
                    HANDLE_RANGES.wait();
                    range = HANDLE_RANGES[i % len];
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return range;
        }
    }

    public static void moveFullToHandle(int i) {
        synchronized (HANDLE_RANGES) {
            try {
                HANDLE_RANGES[i % len] = FULL_RANGES[i % len];
                FULL_RANGES[i % len] = null;
                HANDLE_RANGES.notify();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void handleData() {
        for (int i = 0; i < Constants.TOTAL_RANGE_COUNT; i++) {
            Range range = BookShelf.getFullRange(i);
            range.filterBadTraceId();
            moveFullToHandle(i);
            if (i == Constants.TOTAL_RANGE_COUNT - 1) {//the last range
                Constants.filter.sendPackage(range.errorPackage);
                putErrorPackage(range.errorPackage, i);
            }
        }
        total_error_package = errorPackageIndex;
    }

    public static void handleErrorPackage() {
        int removeP = 0;
        for (int i = 0; i < total_error_package; i++) {
            Package errorPackage = getErrorPackage(i);
            int start = i == 0 ? 0 : (rows_range[i - 1] == 0 ? 0 : rows_range[i - 1] - 1);
            int end = rows_range[i] + 2;
            handleErrorPackage(start, end, errorPackage);

            for (; removeP < start; removeP++) {
                moveHandleToEmpty(removeP);
            }
        }

        Package endPackage = new Package(1, Constants.ROLE, Package.TYPE_END);
        Constants.filter.sendPackage(endPackage);

    }

    public static void handleErrorPackage(int start, int end, Package aPackage) {
        handleOnePackage(start, end, aPackage);
        //handle another client bad trace id
        handleOnePackage(start, end, Constants.filter.getRemoteErrorPackage());
    }

    public static void handleOnePackage(int start, int end, Package aPackage) {
        byte[] bs = aPackage.getBs();
        int len = aPackage.getLen();
        for (int i = Package.P_DATA; i < len; i += 16) {
            byte[] traceId = new byte[16];
            System.arraycopy(bs, i, traceId, 0, 16);
            Package logsPackage = selectByTraceId(start, end, traceId);
            Constants.filter.sendPackage(logsPackage);
        }
    }

    static Package packet = new Package(64, Constants.ROLE, Package.TYPE_BAD_TRACE_SPANS);

    static int badTraceSpansLength = 0;

    static byte[][] data_s = new byte[500][];
    static int[] starts = new int[500];
    static int[] lengths = new int[500];

    public static Package selectByTraceId(int start, int end, byte[] traceId) {
        packet.reset(Constants.ROLE, Package.TYPE_BAD_TRACE_SPANS);
        packet.writeRange(0);
        packet.write(traceId, 0, traceId.length);
        badTraceSpansLength = 0;
        for (int i = start; i < end; i++) {
            Range range = getHandleRange(i);
            if (range == null) break;
            int len = range.selectByTraceId(traceId, data_s,starts,lengths, badTraceSpansLength);
            badTraceSpansLength += len;
        }

        for (int i = 1; i < badTraceSpansLength; i++) {
            for (int j = i; j > 0; j--) {
                if (compare(data_s[j],starts[j],data_s[j - 1],starts[j-1]) < 0) {
                    byte tmp_d[] = data_s[j - 1];
                    int tmp_s = starts[j - 1];
                    int tmp_l= lengths[j - 1];
                    data_s[j - 1]= data_s[j];
                    starts[j - 1]= starts[j];
                    lengths[j - 1]= lengths[j];
                    data_s[j]= tmp_d;
                    starts[j ]= tmp_s;
                    lengths[j]= tmp_l;
                }
            }
        }

        for (int i = 0; i < badTraceSpansLength; i++) {
            byte[] d = data_s[i];
            int s = starts[i];
            int l = lengths[i];
            packet.writeWithDataLen(d, s, l);
        }
        return packet;
    }

    public static int compare( byte d1[],int s1,  byte d2[],int s2) {
        for (int i = 20; i < 35; i++) {
            if (d1[s1+ i] == d2[s2 + i]) continue;
            return d1[s1 + i] - d2[s2 + i];
        }
        return 0;
    }
}
