package backend

import (
	"emptycart/util"
	"encoding/json"
	"fmt"
	mapset "github.com/deckarep/golang-set"
	md5simd "github.com/minio/md5-simd"
	"github.com/valyala/fasthttp"
	"log"
	"net/http"
	"net/url"
	"sort"
	"strconv"
	"strings"
	"time"
)

type SpanSlice []string
type TraceData map[string]SpanSlice

// Final results
var traceMd5Map = make(map[string]string)
var WrongTraceSet mapset.Set 				// Wrong Trace Set
var FullTraceSet mapset.Set  				// Full Trace
var client1FirstStage bool    				// client1 first stage
var client2FirstStage bool    				// client2 first stage
var client1SecondStage bool   				// client1 second stage
var client2SecondStage bool   				// client2 second stage

//Initialization
func init() {
	WrongTraceSet = mapset.NewSet()
	FullTraceSet = mapset.NewSet()
}

//
func GetWrongTraceList(wrongTraceList []string, node string) {
	for _, v := range wrongTraceList {
		WrongTraceSet.Add(v)
	}
	if node == util.CLIENT_ONE_MODE {
		client1FirstStage = true
	}
	if node == util.CLIENT_TWO_MODE {
		client2FirstStage = true
	}
	// Collections from both clients completed
	if client1FirstStage && client2FirstStage {
		go SendShareWrongTraceSet(util.CLIENT_ONE_PORT_8000)
		go SendShareWrongTraceSet(util.CLIENT_TWO_PORT_8001)
	}
}

func GetAllTraceList(traceList []string, node string) {
	for _, v := range traceList {
		FullTraceSet.Add(v)
	}
	if node == util.CLIENT_ONE_MODE {
		client1SecondStage = true
	}
	if node == util.CLIENT_TWO_MODE {
		client2SecondStage = true
	}
	if client1SecondStage && client2SecondStage {
		LastFinish()
	}
}

// Upload the final results
func LastFinish() {
	fmt.Println("LastFinish Begin")
	var traceData TraceData
	traceData = make(TraceData)
	// Divide full set into MAP for writing efficiency
	it := FullTraceSet.Iterator()
	for elem := range it.C {
		fullStr := elem.(string) // Get span
		firstIndex := strings.Index(fullStr, "|") // Get trace ID
		if firstIndex == -1 {
			continue
		}
		traceId := fullStr[:firstIndex]
		traceData[traceId] = append(traceData[traceId], fullStr)
	}
	// Sorting
	fmt.Println("all client finish ! begin sort and upload result")
	server := md5simd.NewServer()
	defer server.Close()

	md5Hash := server.NewHash()
	defer md5Hash.Close()
	sortBeginTime := time.Now()
	for traceId := range traceData {

		sort.Sort(traceData[traceId])
		md5Hash.Reset()
		for span := range traceData[traceId] {
			md5Hash.Write(util.StrToBytes(traceData[traceId][span]))
		}
		digest := md5Hash.Sum([]byte{}) //Checksum
		traceMd5Map[traceId] = fmt.Sprintf("%x", digest)
	}
	fmt.Println("sort result and md5 use : ", time.Since(sortBeginTime))
	sendMd5Result()
}

func SendShareWrongTraceSet(port string) {
	// Send wrong traceID to Server

	jsonStr, err := json.Marshal(WrongTraceSet)
	if err != nil {
		fmt.Println("SendWrongTraceSet json.Marshal failed", err)
		return
	}

	req := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(req)

	req.SetRequestURI(fmt.Sprintf("http://localhost%s/getShare", port))
	req.Header.SetMethod("POST")
	req.Header.SetContentType("application/json")
	req.SetBody(jsonStr)

	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)

	bodyBytes := resp.Body()
	println(string(bodyBytes))

	client := &fasthttp.Client{}
	if err := client.Do(req, resp); err != nil {
		fmt.Println("SendWrongTraceSet post failed", err)
		return
	}

}

func (s SpanSlice) Len() int {
	return len(s)
}

func (s SpanSlice) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}

//Sorted by timestamp in span
func (s SpanSlice) Less(i, j int) bool {
	return getStartTime(s[i]) < getStartTime(s[j])
}

func getStartTime(span string) int64 {
	var low, high int
	low = strings.Index(span, "|") + 1
	if low == 0 {
		return -1
	}

	high = strings.Index(span[low:], "|")
	if high == -1 {
		return -1
	}
	ret, _ := strconv.ParseInt(
		span[low:low+high], 10, 64)
	return ret
}

func sendMd5Result() bool {
	result, _ := json.Marshal(traceMd5Map)
	data := make(url.Values)
	data.Add("result", util.BytesToStr(result))
	url := fmt.Sprintf("http://localhost:%s/api/finished", util.RESULT_UPLOAD_PORT)
	resp, err := http.PostForm(url, data)
	if err == nil {
		defer resp.Body.Close()
	} else {
		log.Fatalln(err)
	}
	if resp.StatusCode >= 200 && resp.StatusCode < 300 {
		//log.Println("suc to sendCheckSum, result:" + util.BytesToStr(result))
		return true
	}

	log.Println("fail to sendCheckSum:" + resp.Status)
	return false
}
