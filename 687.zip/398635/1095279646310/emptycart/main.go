package main

import (
	"emptycart/backend"
	"emptycart/client"
	"emptycart/util"
	"flag"
	"fmt"
	"github.com/gin-gonic/gin"
	jsoniter "github.com/json-iterator/go"
	"os"
	"runtime"
)

// Expose HTTP Port
var runningPort string

func main() {
	// Get the environment variable to determine whether it is Client or Backend
	envPort := os.Getenv("SERVER_PORT")
	if envPort == "8000" {
		util.Mode = util.CLIENT_ONE_MODE
		runtime.GOMAXPROCS(2)
	} else if envPort == "8001" {
		util.Mode = util.CLIENT_TWO_MODE
		runtime.GOMAXPROCS(2)
	} else {
		util.Mode = util.BACKEND_MODE
	}

	flag.Parse()
	fmt.Println("Run Mode is : ", util.Mode)

	r := gin.Default()
	r.GET("/ping", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"message": "pong",
		})
	})
	r.GET("/ready", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"message": "ready",
		})
	})
	r.GET("/start", func(c *gin.Context) {
		c.JSON(200, gin.H{
			"message": "start",
		})
	})
	r.GET("/setParameter", func(c *gin.Context) {
		util.DATA_SOURCE_PORT = c.Query("port")
		util.RESULT_UPLOAD_PORT = util.DATA_SOURCE_PORT
		fmt.Println(fmt.Sprintf("%s receive parameters start running!", util.Mode))
		c.JSON(200, gin.H{
			"message": "setParameter success",
		})
		// Client start！
		if util.IsClient() {
			go client.Start()
		}
	})

	if util.IsBackend() {
		// Backend obtain wrong TraceID passed from Client side
		r.POST("/getWrong", func(c *gin.Context) {
			bytes, _ := c.GetRawData()
			var WrongTraceList []string
			var json = jsoniter.ConfigCompatibleWithStandardLibrary
			err := json.Unmarshal(bytes, &WrongTraceList)
			if err != nil {
				fmt.Println("json parse error", err)
				c.JSON(500, gin.H{
					"message": "data error",
				})
			}
			go backend.GetWrongTraceList(WrongTraceList, c.Query("node"))
			c.JSON(200, gin.H{
				"message": "connection to client from backend",
			})
		})
		// Backend receive all Trace lists passed from Client side
		r.POST("/all", func(c *gin.Context) {
			bytes, _ := c.GetRawData()
			var traceList []string
			var json = jsoniter.ConfigCompatibleWithStandardLibrary
			err := json.Unmarshal(bytes, &traceList)
			if err != nil {
				fmt.Println("json parse error", err)
				c.JSON(500, gin.H{
					"message": "data error",
				})
			}
			go backend.GetAllTraceList(traceList, c.Query("node"))
			c.JSON(200, gin.H{
				"message": "connection to client from backend",
			})
		})

	}
	if util.IsClient() {
		// Client obtain shared wrong TraceID from Backend
		r.POST("/getShare", func(c *gin.Context) {
			bytes, _ := c.GetRawData()
			var WrongTraceList []string
			var json = jsoniter.ConfigCompatibleWithStandardLibrary
			err := json.Unmarshal(bytes, &WrongTraceList)
			if err != nil {
				fmt.Println("json parse error", err)
				c.JSON(500, gin.H{
					"message": "data error",
				})
			}
			go client.GetShareWrongTraceSet(WrongTraceList)
			c.JSON(200, gin.H{
				"message": "connection to backend from client",
			})
		})
	}

	// Ports of different modes
	switch util.Mode {
	case util.BACKEND_MODE:
		runningPort = util.BACKEND_PORT_8002
	case util.CLIENT_ONE_MODE:
		runningPort = util.CLIENT_ONE_PORT_8000
	case util.CLIENT_TWO_MODE:
		runningPort = util.CLIENT_TWO_PORT_8001
	}
	_ = r.Run(runningPort)
}
