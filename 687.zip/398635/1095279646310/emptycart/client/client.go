package client

import (
	"bufio"
	"bytes"
	"emptycart/util"
	"fmt"
	mapset "github.com/deckarep/golang-set"
	jsoniter "github.com/json-iterator/go"
	"github.com/valyala/fasthttp"
	"io"
	"log"
	"net/http"
	"strconv"
	"sync"
	"time"
)

var WrongTraceSet mapset.Set //bad Trace ID list
var WrongTraceMap sync.Map //bad Trace ID list without duplication
var FullTraceSet mapset.Set // Full set of Trace

//	Initialization
func init() {
	WrongTraceSet = mapset.NewSet()
	FullTraceSet = mapset.NewSet()
}

// Only filter wrong Trace in the 1st retrieval
func Start() {
	//Get data source path
	dataPath := getPath()
	if dataPath == "" {
		fmt.Println("getPath failed")
		return
	}
	fmt.Println("data source path:", dataPath)

	//pool.Start()
	//defer pool.Stop()

	var wg sync.WaitGroup
	var beginTime = time.Now()

	//Initialize wrong status
	var status = []byte{101, 114, 114, 111, 114, 61, 49}
	var status1 = []byte{104, 116, 116, 112, 46, 115, 116, 97, 116, 117, 115, 95, 99, 111, 100, 101, 61}
	var status2 = []byte{104, 116, 116, 112, 46, 115, 116, 97, 116, 117, 115, 95, 99, 111, 100, 101, 61, 50, 48, 48}
	//Initialize split flag
	var spl = byte(124)

    //Get header and calculate the content size
	res, _ := http.Head(dataPath)
	maps := res.Header
	length, _ := strconv.Atoi(maps["Content-Length"][0])
	limit := util.ParaPull
	len_sub := length / limit
	diff := length % limit
	
	//Start to analyse data by range  
	for i := 0; i < limit; i++ {
		wg.Add(1)

		min := len_sub * i
		max := len_sub * (i + 1)

		if i == limit-1 {
			max += diff
		}

		go func(min int, max int, i int) {
			client := &http.Client{}
			req, _ := http.NewRequest("GET", dataPath, nil)
			range_header := "bytes=" + strconv.Itoa(min) + "-" + strconv.Itoa(max-1)
			req.Header.Add("Range", range_header)
			resp, _ := client.Do(req)
			defer resp.Body.Close()
			bufReader := bufio.NewReader(resp.Body)

			for {
				//Read line
				line, err := bufReader.ReadBytes('\n')
				if err != nil && err != io.EOF {
					log.Println("bufReader.ReadBytes meet unsolved error")
					panic(err)
				}
				if len(line) == 0 && err == io.EOF {
					break
				}

				//Get traceID position
				firstIndex := bytes.IndexByte(line, spl)
				if firstIndex == -1 {
					continue
				}
				traceId := line[:firstIndex]

				//Retrieve tags
				lastIndex := bytes.LastIndexByte(line,spl)
				if lastIndex == -1 {
					continue
				}
				tags := line[lastIndex : len(line)-1]

				//  Tags filtering logic
				if len(tags) > 8 {
					if  bytes.Index(tags,status) > 0 ||
						bytes.Index(tags,status1) > 0 &&
							bytes.Index(tags,status2) < 0 {

						go WrongTraceSet.Add(util.BytesToStr(traceId))
					}
				}

			}
			wg.Done()
		}(min, max, i)
	}
	wg.Wait()
	fmt.Println("finish used time: ", time.Since(beginTime))
	//fmt.Println(WrongTraceSet)
	fmt.Println("begin send wrong data")
	SendWrongTraceSet()
}

// Obtain full trace list in the 2nd retrieval
func getSpanList() {
	//Get data source path
	dataPath := getPath()
	if dataPath == "" {
		fmt.Println("getPath failed")
		return
	}
	fmt.Println("data source path:", dataPath)

	var spl = byte(124)
	var wg sync.WaitGroup
	var beginTime = time.Now()
	
	//Get Header and calculate the content size
	res, _ := http.Head(dataPath)
	maps := res.Header
	length, _ := strconv.Atoi(maps["Content-Length"][0])
	limit := util.ParaPull
	len_sub := length / limit
	diff := length % limit
	for i := 0; i < limit; i++ {
		wg.Add(1)

		min := len_sub * i
		max := len_sub * (i + 1)

		if i == limit-1 {
			max += diff
		}

		go func(min int, max int, i int) {
			//Read data by range
			client := &http.Client{}
			req, _ := http.NewRequest("GET", dataPath, nil)
			range_header := "bytes=" + strconv.Itoa(min) + "-" + strconv.Itoa(max-1)
			req.Header.Add("Range", range_header)
			resp, _ := client.Do(req)
			defer resp.Body.Close()
			bufReader := bufio.NewReader(resp.Body)

			for {
				//Read line
				line, err := bufReader.ReadBytes('\n')
				if err != nil && err != io.EOF {
					log.Println("bufReader.ReadBytes meet unsolved error")
					panic(err)
				}
				if len(line) == 0 && err == io.EOF {
					break
				}

                //Get trace ID
				firstIndex := bytes.IndexByte(line, spl)
				if firstIndex == -1 {
					continue
				}
				traceId := line[:firstIndex]
				// Found in wrong set Trace
				_, ok := WrongTraceMap.Load(util.BytesToStr(traceId))
				if ok {
					FullTraceSet.Add(util.BytesToStr(line))
				}
			}
			wg.Done()
		}(min, max, i)
	}
	wg.Wait()
	fmt.Println("finish used time: ", time.Since(beginTime))
	fmt.Println("begin send full trace data ")
	go SendFullTraceSet()
}

// Send wrong traceID to backend
func SendWrongTraceSet() {
	//Translate wrongTraceSet into json format
	var json = jsoniter.ConfigCompatibleWithStandardLibrary
	jsonStr, err := json.Marshal(WrongTraceSet)
	if err != nil {
		fmt.Println("SendWrongTraceSet json.Marshal failed", err)
		return
	}

	req := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(req)
    //Call backend
	req.SetRequestURI(fmt.Sprintf("http://localhost%s/getWrong?node=%s", util.BACKEND_PORT_8002, util.Mode))
	req.Header.SetMethod("POST")
	req.Header.SetContentType("application/json")
	req.SetBody(jsonStr)

	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)

	client := &fasthttp.Client{}
	if err := client.Do(req, resp); err != nil {
		fmt.Println("SendWrongTraceSet post failed", err)
		return
	}

}

// Obtain shared wrong traceID
func GetShareWrongTraceSet(wrongTraceList []string) {
	// Merge wrong traceID set
	for _, v := range wrongTraceList {
		WrongTraceSet.Add(v)
	}
	
	// Remove duplicate wrong trace ID
	fmt.Println("finish GetShareWrongTraceSet", WrongTraceSet)
	for traceId := range WrongTraceSet.Iter() {
		WrongTraceMap.Store(traceId.(string), "")
	}
	
	// Begin 2nd data pulling
	getSpanList()
}

// Send full set of traceID to Backend
func SendFullTraceSet() {
	var json = jsoniter.ConfigCompatibleWithStandardLibrary
	jsonStr, err := json.Marshal(FullTraceSet)
	if err != nil {
		fmt.Println("SendFullTraceSet json.Marshal failed", err)
		return
	}

	req := fasthttp.AcquireRequest()
	defer fasthttp.ReleaseRequest(req)
    //Call backend
	req.SetRequestURI(fmt.Sprintf("http://localhost%s/all?node=%s", util.BACKEND_PORT_8002, util.Mode))
	req.Header.SetMethod("POST")
	req.Header.SetContentType("application/json")
	req.SetBody(jsonStr)

	resp := fasthttp.AcquireResponse()
	defer fasthttp.ReleaseResponse(resp)

	client := &fasthttp.Client{}
	if err := client.Do(req, resp); err != nil {
		fmt.Println("SendFullTraceSet post failed", err)
		return
	}

}

// Local data input directory for testing
func getPath() string {

	if util.Mode == util.CLIENT_ONE_MODE {
		return fmt.Sprintf("http://localhost:%s/trace1.data", util.DATA_SOURCE_PORT)
	}

	if util.Mode == util.CLIENT_TWO_MODE {
		return fmt.Sprintf("http://localhost:%s/trace2.data", util.DATA_SOURCE_PORT)
	}
	return ""

}
