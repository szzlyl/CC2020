package util

// Running mode
var Mode string
// Port of pulling data
var DATA_SOURCE_PORT string
// Port of uploading checksum which should be the same as the one of pulling data
var RESULT_UPLOAD_PORT string

const (
	CLIENT_ONE_MODE string = "client1"
	CLIENT_TWO_MODE string = "client2"
	BACKEND_MODE    string = "backend"
)

// Number of processes pulling data simultaneously
const ParaPull = 15

// Port definition
const CLIENT_ONE_PORT_8000 = ":8000"
const CLIENT_TWO_PORT_8001 = ":8001"
const BACKEND_PORT_8002 = ":8002"
const BACKEND_PORT_8003 = ":8003"
const BACKEND_PORT_8004 = ":8004"