package util

import (
	"strconv"
	"strings"
	"unsafe"
)

// Example of Trace data format
// 74ed065dc42bfd3a -> 74ed065dc42bfd3a|1590216545778589|477790887b801f52|7a6305ae3050d429|985|PromotionCenter|/agent/gRPC|192.168.9.244|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://tracing.console.aliyun.com/getInventory?id=3&peer.port=9005&http.method=GET&error=1

type Span []byte      // One line
type SpanSlice []Span // More lines
type TraceData map[string]SpanSlice

// Cache the last found position
type TraceCache map[string]int64

type TraceDataDim struct {
	TraceId    string
	SpanSlices SpanSlice
}

func (s SpanSlice) Len() int {
	return len(s)
}

func (s SpanSlice) Swap(i, j int) {
	s[i], s[j] = s[j], s[i]
}

//Sorted by timestamp in span
func (s SpanSlice) Less(i, j int) bool {
	return getStartTime(s[i]) < getStartTime(s[j])
}

func getStartTime(span []byte) int64 {
	var low, high int
	low = strings.Index(BytesToStr(span), "|") + 1
	if low == 0 {
		return -1
	}

	high = strings.Index(BytesToStr(span[low:]), "|")
	if high == -1 {
		return -1
	}
	ret, _ := strconv.ParseInt(
		BytesToStr(span[low:low+high]), 10, 64)
	return ret
}

//Convert string to bytes
func StrToBytes(s string) []byte {
	x := (*[2]uintptr)(unsafe.Pointer(&s))
	h := [3]uintptr{x[0], x[1], x[1]}
	return *(*[]byte)(unsafe.Pointer(&h))
}

//Convert bytes to string
func BytesToStr(b []byte) string {
	return *(*string)(unsafe.Pointer(&b))
}
