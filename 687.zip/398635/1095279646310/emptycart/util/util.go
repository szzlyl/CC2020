package util

// Client
func IsClient() bool {
	if Mode == CLIENT_ONE_MODE {
		return true
	}
	if Mode == CLIENT_TWO_MODE {
		return true
	}
	return false
}

// Backend
func IsBackend() bool {
	if Mode == BACKEND_MODE {
		return true
	}
	return false
}

