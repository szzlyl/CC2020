package com.hsbc.tianchi.bean;

public class Position {
    public byte[] d;
    public int s;
    public int l;

    public Position(byte[] d, int s, int l) {
        this.d = d;
        this.s = s;
        this.l = l;
    }
}
