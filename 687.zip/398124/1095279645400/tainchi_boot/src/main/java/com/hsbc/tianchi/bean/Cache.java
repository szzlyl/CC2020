package com.hsbc.tianchi.bean;


import static com.hsbc.tianchi.common.Constants.*;

/**
 * The cache data, read from raw data file.
 */
public class Cache {
    /*
     * indexing data, 16^4 = 64K hash
     * [hash] [i][pos,len]
     * [hash][0] = {hash, count}
     */
    public int index_cache[][][] = new int[0x10000][][];
    // magic number for performance, use to skip check line
    private static final int SKIP_LEN = 112;
    // cache size, 40M TODO: use better value
    public static final int SIZE = 40 * 1024 * 1024;
    // current page index/16, total 16 pages
    public int pageIndex = 0;
    //date cache buffer, 41 each block TODO: use better value
    // make sure end with line
    public byte[] data = new byte[40 * 1024 * 1024 + 1024];
    // actual len of the data
    public int len = 0;

    //each page：4000>traceId，100>traceId numbers，2 line position/length  a=4000,b=100,c=2
    public int link[][][] = new int[10000][2][200];
    public int p;//current link read data position.
    public static int count = 1;//total line number per page.

    private static final byte LINE_BREAK='\n';

    public static ErrorTrace error = new ErrorTrace(2, service_name, ErrorTrace.TYPE_MULTI_TRACE_ID);//500 each

    public void createIndexAndFindError() {
        int i = 0;
        do {
            int hash = (data[i] + (data[i + 1] << 3) + (data[i + 2] << 6) + (data[i + 3] << 9) + (data[i + 4] << 12)) & 0XFFFF;
            int l = getLine(data, i);// read line from cache block.
            put(hash, i, l);
            if (++count % PER_COUNT == 0) {
                filter.sendPacket(error);
                DataHandler.put(error, pageIndex);
                error = new ErrorTrace(2, service_name, ErrorTrace.TYPE_MULTI_TRACE_ID);
            }
            i = i + l;
        } while (i != len);
    }


    private final int getLine(byte[] d, int s) {
        try {
            int i = s + SKIP_LEN;
            while (d[++i] != LINE_BREAK) {
                if (d[i] == '=') {
                    if (d[i - 5] == '_') {
                        if (d[i + 1] != '2') error.write(d, s, 16);
                        break;
                    } else if (d[i - 6] == '&' || d[i - 6] == '|') {
                        if (d[i + 1] == '1') error.write(d, s, 16);
                        break;
                    }
                }
            }
            if (d[i] != LINE_BREAK) {
                if (i - s < 160) i += 85;
                while (d[++i] != LINE_BREAK) ;
            }
            return i - s + 1;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }


    public void put(int hash, int s, int len) {
        int[][] tmp;
        tmp = index_cache[hash];
        if (tmp == null) {
            tmp = index_cache[hash] = link[p++];
            tmp[0][0] = hash;
            tmp[1][0] = 1;
        }
        tmp[0][tmp[1][0]] = s;
        tmp[1][tmp[1][0]] = len;
        tmp[1][0]++;
    }

    public int selectByTraceId(byte k[], Position[] positions, int start) {
        int hash = (k[0] + (k[1] << 3) + (k[2] << 6) + (k[3] << 9) + (k[4] << 12)) & 0XFFFF;
        int link[][] = index_cache[hash];
        if (link == null) return 0;
        int p = start;
        int count = link[1][0];
        for (int i = 1; i < count; i++) {
            //start=link[0][i] len=link[1][i]
            boolean b = startsWith(data, link[0][i], k);
            if (b) {
                positions[p++] = new Position(this.data, link[0][i], link[1][i]);
            }
        }
        return p - start;
    }

    /**
     * byte[] compare to find the start with, the same with String.startwith
     */
    private static boolean startsWith(byte data[], int s, byte key[]) {
        for (int i = 0; i < key.length; i++) {
            if (data[s + i] != key[i]) return false;
        }
        return true;
    }

    /**
     * compare two byte[]
     */
    public static boolean equals(byte data[], int ds, byte key[], int ks) {
        for (int i = 0; i < 16; i++) {
            if (data[ds + i] != key[ks + i]) return false;
        }
        return true;
    }


    public void clear() {
        len = 0;//data clean, reset length
        for (int i = 0; i < p; i++) { // clean index
            index_cache[link[i][0][0]] = null;//reset each index_cache
        }
        p = 0; //reset read position
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("total=").append(p).append('\n');
        for (int i = 0; i < index_cache.length; i++) {
            if (index_cache[i] == null) continue;
            sb.append(i).append(" : \n");
            for (int j = 0; j < index_cache[i].length; j++) {
                for (int k = 0; k < index_cache[i][1][0]; k++) {
                    sb.append(nToStr(index_cache[i][j][k]));
                }
                sb.append('\n');
            }
            sb.append('\n');
        }
        sb.append("\n\n\n\n");
        return sb.toString();
    }

    private String nToStr(int n) {
        String str = n + "          ";
        return str.substring(0, 10);
    }
}
