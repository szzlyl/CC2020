package com.hsbc.tianchi.socket;

import com.hsbc.tianchi.bean.ErrorTrace;
import com.hsbc.tianchi.common.Constants;
import com.hsbc.tianchi.common.Utils;
import lombok.extern.slf4j.Slf4j;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

import static com.hsbc.tianchi.common.Constants.Client0_PORT;
import static com.hsbc.tianchi.common.Constants.Client1_PORT;

@Slf4j
public class ServerSend extends Thread {
	
	ServerSocket server = null;
	OutputStream client0_out = null;
	OutputStream client1_out = null;
	
    
    public ServerSend() {
        try {
            server = new ServerSocket(8004);
            new Thread(()->{
            	while(true) {
            		try {
            			Socket socket = server.accept();
            			InputStream in = socket.getInputStream();
            			byte[] serverName = new byte[1];
            			in.read(serverName);
                        if (Constants.Client0 == serverName[0]) {
                        	log.debug(Client0_PORT + " connect success");
                            client0_out = socket.getOutputStream();
                        } else{
                        	log.debug(Client1_PORT + " connect success");
                            client1_out = socket.getOutputStream();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }finally {
        			}
            	}
            }).start();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void run() {
    	super.run();
    }
    
    //send to client1
    public void sendError0(ErrorTrace errorTracePacket) {
    	while(client0_out == null) {
    		Utils.sleep(1);
    	}
    	sendPacket(errorTracePacket,client0_out );
    }
    //send to client0
    public void sendError1(ErrorTrace errorTracePacket) {
    	while(client1_out == null) {
    		Utils.sleep(1);
    	}
    	sendPacket(errorTracePacket,client1_out );
    }
    
    
    private void sendPacket(ErrorTrace errorTracePacket, OutputStream out) {
        try {
            int len = errorTracePacket.getLen();
            byte bs[] = errorTracePacket.getBytes();
            out.write(bs, 0, len);
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
