package com.hsbc.tianchi.controller;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hsbc.tianchi.common.Constants;
import com.hsbc.tianchi.common.Utils;

import lombok.extern.slf4j.Slf4j;

@Controller
@ConditionalOnProperty(value ="app.type", havingValue = "BACKEND")
@Slf4j
public class BackEndController {
	
	@GetMapping("/ready")
	public ResponseEntity<String> ready() throws InterruptedException{
		return new ResponseEntity<String>(HttpStatus.OK);
	}
	
	@GetMapping("/setParameter")
	public ResponseEntity<String> setParameter(@RequestParam(value="port") Integer port) throws InterruptedException{
		Constants.data_port = port;
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	
}
