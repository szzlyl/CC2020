package com.hsbc.tianchi.socket;

import com.hsbc.tianchi.bean.ErrorTrace;
import lombok.extern.slf4j.Slf4j;

import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;

@Slf4j
public class ClientSend {

	OutputStream out = null;

    public ClientSend() {
        try {
            Socket socket = new Socket();
            socket.connect(new InetSocketAddress("127.0.0.1", 8003));
            log.debug("connect to engine success");
            out = socket.getOutputStream();
        }catch (Exception e) {
			e.printStackTrace();
		}
        
    }
    
    public synchronized void send(ErrorTrace errorTracePacket) {
    	try {
            out.write(errorTracePacket.getBytes(), 0, errorTracePacket.getLen());
            out.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    
    
}
