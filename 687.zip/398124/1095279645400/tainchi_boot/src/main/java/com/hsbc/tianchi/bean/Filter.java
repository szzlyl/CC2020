package com.hsbc.tianchi.bean;


import com.hsbc.tianchi.socket.ClientSend;

import java.net.ServerSocket;

/**
 * list 8000/8001 port, update soring app if ready for test.
 * use soring app pass port to read stream data.
 */
public class Filter {
    protected ServerSocket server;
    private static int remoteCacheCount = 10000;
    private ErrorTrace remoteErrorErrorTracePacket;
    private ClientSend clientSend= null;

    public synchronized void setRemoteErrorPacket(ErrorTrace errorTracePacket) {
        try {
            while (remoteErrorErrorTracePacket != null) {
                this.wait();
            }
            this.remoteErrorErrorTracePacket = errorTracePacket;
            this.notifyAll();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("filter packet error");
        }
    }

    public synchronized ErrorTrace getRemoteErrorPacket() {
        try {
            while (remoteErrorErrorTracePacket == null) {
                this.wait();
            }
            ErrorTrace errorTracePacket = remoteErrorErrorTracePacket;
            remoteErrorErrorTracePacket = null;
            notifyAll();
            return errorTracePacket;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("filter packet error");
        }
    }


    public void start() throws Exception {
    	clientSend = new ClientSend();
    	
    }
    
    public void setRemoteCacheCount(int count) {
    	remoteCacheCount = count;
    }




    public synchronized void sendPacket(ErrorTrace errorTracePacket) {
    	clientSend.send(errorTracePacket);
    }


}
