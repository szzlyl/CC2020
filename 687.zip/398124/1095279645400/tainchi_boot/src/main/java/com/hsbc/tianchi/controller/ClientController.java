package com.hsbc.tianchi.controller;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.hsbc.tianchi.common.Constants;
import com.hsbc.tianchi.common.Utils;

import lombok.extern.slf4j.Slf4j;

@Controller
@ConditionalOnProperty(value ="app.type", havingValue = "CLIENT")
@Slf4j
public class ClientController {
	
	@Value("${offline:false}")
	boolean offline;
	
	
	@GetMapping("/ready")
	public ResponseEntity<String> ready() throws InterruptedException{
		while(!Utils.allhealth()) {
			Utils.sleep(20);
		}
		Constants.ALL_HEALTH = true;
		if(Constants.service_name == Constants.Client0) {
			//give more time for spring ready
			Utils.sleep(100);
		}
		
		return new ResponseEntity<String>(HttpStatus.OK);
	}
	
	@GetMapping("/setParameter")
	public ResponseEntity<String> setParameter(@RequestParam(value="port") Integer port) throws InterruptedException{
		if(offline) {
			Constants.data_port = 8080;
		}else {
			Constants.data_port = port;
		}
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
}
