package com.hsbc.tianchi.bean;

public class ErrorTrace {
    public static final byte TYPE_START = 1;
    public static final byte TYPE_TRACE_ID = 2;//traceId
    public static final byte TYPE_MULTI_TRACE_ID = 3;//pageIndex traceId traceId traceId
    public static final byte TYPE_MULTI_POSITION = 5;//len log len log len log
    public static final byte TYPE_END = 0;
    public static final byte TYPE_READ_END = 10;//indicate sent traceId if end

    public static final byte TRACE_ID_LEN = 16;

    public static final int POS_LEN = 0;
    public static final int POS_WHO = 3;
    public static final int POS_TYPE = 4;
    public static final int POS_PAGE = 5;
    public static final int POS_DATA = 7;
    private byte bs[];//[len0,len1,len2,service_name,type,data] data=len data len data
    private int len = 7;//place holder length. - len0,len1,len2,service_name,type,data
    public boolean isHandle;//indicate if handle, avoid duplicate handle.

    public ErrorTrace(int k) {
        bs = new byte[k * 1024];
    }

    public ErrorTrace(byte bs[], int len) {
        this.bs = bs;
        this.len = len;
    }


    public ErrorTrace(int k, byte service_name, byte type) {
        bs = new byte[k * 1024];
        this.bs[POS_WHO] = service_name;
        this.bs[POS_TYPE] = type;
    }

    public void clear() {
        int len = 0;
    }


    public int getLen() {
        if (len <= 0) {
            len = ((bs[POS_LEN] & 0XFF) << 16) + ((bs[POS_LEN + 1] & 0XFF) << 8) + (bs[POS_LEN + 2] & 0XFF);
        }
        return len;
    }

    public int getWho() {
        return bs[POS_WHO];
    }

    public int getType() {
        return bs[POS_TYPE];
    }

    public int getCache() {
        int page = ((bs[POS_PAGE + 0] & 0XFF) << 8) + (bs[POS_PAGE + 1] & 0XFF);
        return page;
    }

    public byte[] getBytes() {
        bs[POS_LEN + 0] = (byte) ((len >> 16) & 0XFF);
        bs[POS_LEN + 1] = (byte) ((len >> 8) & 0XFF);
        bs[POS_LEN + 2] = (byte) (len & 0XFF);
        return bs;
    }

    public ErrorTrace write(byte bs[], int start, int len) {
        System.arraycopy(bs, start, this.bs, this.len, len);
        this.len += len;
        return this;
    }

    public void reset(byte service_name, byte type) {
        bs[POS_LEN + 0] = 0;
        bs[POS_LEN + 1] = 0;
        bs[POS_LEN + 2] = 0;
        this.bs[POS_WHO] = service_name;
        this.bs[POS_TYPE] = type;
        len = 7;
    }


    /**
     * use 2 byte as index
     * 127-127
     * @param len
     * @return
     */
    public ErrorTrace writeWithDataLen(byte bs[], int start, int len) {
        this.bs[this.len++] = (byte) ((len >> 8) & 0XFF);
        this.bs[this.len++] = (byte) (len & 0XFF);
        System.arraycopy(bs, start, this.bs, this.len, len);
        this.len += len;
        return this;
    }

    /**
     * use 2 byte as index
     *  127-127
     */
    public ErrorTrace writeCache(int page) {
        this.bs[POS_PAGE + 0] = (byte) ((page >> 8) & 0XFF);
        this.bs[POS_PAGE + 1] = (byte) (page & 0XFF);
        return this;
    }


    @Override
    public int hashCode() {
        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        ErrorTrace p = (ErrorTrace) obj;
        for (int s = POS_DATA; s < POS_DATA + 16; s++) {//0-16 means traceId, as traceId possible 14,15,16
            if (this.bs[s] != p.bs[s]) return false;
        }
        return true;
    }

    @Override
    public String toString() {
        int service_name = 8000 + bs[POS_WHO];
        int page = getCache();

        String type = "start";
        switch (bs[POS_TYPE]) {
            case TYPE_START:
                type = "start";
                break;
            case TYPE_TRACE_ID:
                type = "traceId";
                break;
            case TYPE_MULTI_TRACE_ID:
                type = "multi_trace_id";
                break;
            case TYPE_MULTI_POSITION:
                type = "multi_position";
                break;
            case TYPE_END:
                type = "end";
                break;
        }
        if (bs[POS_TYPE] == TYPE_MULTI_POSITION) {

            StringBuilder sb = new StringBuilder("total len:" + len +
                    ", service_name:" + service_name +
                    ", type:" + type +
                    ", page:" + page +
                    ", data len=" + (len - POS_DATA) +
                    ", traceId=" + new String(bs, POS_DATA, TRACE_ID_LEN) +
                    ", data=\n");
            for (int i = POS_DATA + TRACE_ID_LEN; i < this.len; ) {
                int l = ((bs[i] & 0XFF) << 8) + (bs[i + 1] & 0XFF);
                sb.append(l + " " + new String(bs, i + 2, l));
                i = i + 2 + l;
            }
            return sb.toString();
        } else {
            return "total len:" + len +
                    ", service_name:" + service_name +
                    ", type:" + type +
                    ", page:" + page +
                    ", len=" + (len - POS_DATA) +
                    ", data=\n" + new String(bs, POS_DATA, len - POS_DATA);
        }
    }
}

