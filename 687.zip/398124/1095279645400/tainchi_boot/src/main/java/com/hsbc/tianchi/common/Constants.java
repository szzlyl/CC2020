package com.hsbc.tianchi.common;

import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import com.hsbc.tianchi.bean.Filter;

public class Constants {
	public static final RestTemplate REST ;
	
	public static final int Client0 = 0;
    public static final int Client1 = 1;
    public static final int Backend = 2;

    public static final int Client0_PORT = 8000;
    public static final int Client1_PORT = 8001;
   // public static final int Backend_PORT = 8002;

    public static int listen_port = 8000;
    public static int data_port = 0;// data source port .
    public static byte service_name = Client0;//Current server node, client0,client1,Backend
    public static Filter filter;
    
    
    public static int total_page_count = 10000;//fake init value, the true value will be assign after data Stream in
    public static final int PER_COUNT = 100000;//Batch line number each time.
    
	static {
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();  
		requestFactory.setConnectTimeout(100);  
		requestFactory.setReadTimeout(100);
		REST = new RestTemplate(requestFactory);
	}
	
	public static boolean ALL_HEALTH=false;
	
	public static boolean START_READ = false;
}
