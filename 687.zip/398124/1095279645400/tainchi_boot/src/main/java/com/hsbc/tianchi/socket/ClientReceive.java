package com.hsbc.tianchi.socket;

import com.hsbc.tianchi.bean.ErrorTrace;
import com.hsbc.tianchi.bean.Filter;
import com.hsbc.tianchi.common.Constants;

import java.io.InputStream;
import java.net.Socket;

public class ClientReceive {

	Filter filter;

	public ClientReceive(Filter filter) {
		this.filter = filter;
	}

	public void start() {
		new Thread(() -> {
			Socket socket = null;
			try {
				socket = new Socket("localhost", 8004);
				socket.setReuseAddress(true);
				
				socket.getOutputStream().write(new byte[] {Constants.service_name});
				
				InputStream in = socket.getInputStream();
				while (true) {
					byte bs[] = new byte[3];
					readN(in, bs, 0, 3);
					int totalLen = ((bs[0] & 0XFF) << 16) + ((bs[1] & 0XFF) << 8) + (bs[2] & 0XFF);
					byte data[] = new byte[totalLen];
					data[0] = bs[0];
					data[1] = bs[1];
					data[2] = bs[2];
					readN(in, data, 3, totalLen - 3);
					
					ErrorTrace errorTracePacket = new ErrorTrace(data, data.length);
					//System.out.println("received " + errorTracePacket.getWho());

					switch (errorTracePacket.getType()) {
					case ErrorTrace.TYPE_MULTI_TRACE_ID:
						filter.setRemoteErrorPacket(errorTracePacket);
						break;
					case ErrorTrace.TYPE_START:
						Constants.START_READ = true;
						break;
					case ErrorTrace.TYPE_READ_END:
						filter.setRemoteCacheCount(errorTracePacket.getCache());
						break;

					default:
						break;
					}
				}

			} catch (Exception e) {
			} finally {

			}

		}).start();
	}

	/**
	 * read byte from socket stream.
	 */
	public static void readN(InputStream in, byte[] bs, int s, int n) throws Exception {
		int len;
		while ((len = in.read(bs, s, n)) != -1) {
			if (n - len == 0)
				break;
			s += len;
			n -= len;
		}
	}

}
