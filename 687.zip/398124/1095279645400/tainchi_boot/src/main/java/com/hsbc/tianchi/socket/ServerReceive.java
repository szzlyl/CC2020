package com.hsbc.tianchi.socket;

import com.hsbc.tianchi.bean.ErrorTrace;
import com.hsbc.tianchi.service.BackEndService;
import lombok.extern.slf4j.Slf4j;

import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
@Slf4j
public class ServerReceive extends Thread {
	
	ServerSocket server = null;
	BackEndService backEndService;
	
    
    public ServerReceive(BackEndService backEndService) {
    	this.backEndService = backEndService;
        try {
            server = new ServerSocket(8003);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    @Override
    public void run() {
    	super.run();
    	while(true) {
    		try {
    			Socket socket = server.accept();
                new Thread(() ->{
                	handleInputStream(socket);
                }).start();
            } catch (Exception e) {
                e.printStackTrace();
            }
    	}
    }
    
    protected void handleInputStream(Socket socket) {
    	log.debug("listen socket" + socket);
        InputStream in = null;
        try {
            in = socket.getInputStream();
            while (true) {
                byte bs[] = new byte[3];
                read(in, bs, 0, 3);
                int totalLen = ((bs[0] & 0XFF) << 16) + ((bs[1] & 0XFF) << 8) + (bs[2] & 0XFF);
                byte data[] = new byte[totalLen];
                data[0] = bs[0];
                data[1] = bs[1];
                data[2] = bs[2];
                read(in, data, 3, totalLen - 3);
                ErrorTrace errorTracePacket = new ErrorTrace(data, data.length);
                //System.out.println("receive value " + errorTracePacket.getWho() );
                switch (errorTracePacket.getType()) {
				case ErrorTrace.TYPE_MULTI_TRACE_ID:
				case ErrorTrace.TYPE_READ_END:
					backEndService.sendPacket(errorTracePacket);
					break;
				case ErrorTrace.TYPE_MULTI_POSITION:
					backEndService.calcCheckSum(errorTracePacket);
					break;
				case ErrorTrace.TYPE_END:
					log.debug("end");
					backEndService.addEndFilterNum();
					break;
				default:
					break;
				}
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            System.out.println(socket.getPort() + " closed ");
            try {
                socket.close();
                in.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    
    /**
     * read byte from socket stream.
      */
     public static void read(InputStream in, byte[] bs, int s, int n) throws Exception {
         int len;
         while ((len = in.read(bs, s, n)) != -1) {
             if (n - len == 0) break;
             s += len;
             n -= len;
         }
     }
    
}
