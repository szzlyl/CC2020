package com.hsbc.tianchi.service;

import com.hsbc.tianchi.bean.ErrorTrace;
import com.hsbc.tianchi.common.Constants;
import com.hsbc.tianchi.common.MD5;
import com.hsbc.tianchi.common.Utils;
import com.hsbc.tianchi.socket.ServerSend;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.entity.ContentType;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;


@Service
@ConditionalOnProperty(value ="app.type", havingValue = "BACKEND")
@Slf4j
public class BackEndService implements InitializingBean{
	ServerSend serverSend ;

    private MD5 md5 = new MD5();
    private byte[] request = new byte[5 * 1024 * 1024];//100K
    private int requestLen = 0;
    private Map<ErrorTrace, ErrorTrace> map = new HashMap<>(30000);
    private int endFilterNum = 0;
    HttpURLConnection connection = null;

//    public static int emptyLogs = 0;
//    public static int fullLogs = 0;
//    public static long startTime = 0;
    
    boolean sent = false;


    public BackEndService() {
        try {
            byte bs[] = ("result={").getBytes();
            System.arraycopy(bs, 0, request, 0, bs.length);
            requestLen = bs.length;
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        new Thread(() ->{
        	while (Constants.data_port == 0) {
				Utils.sleep(100);
			}
        	try {
        		URL url = new URL(String.format("http://localhost:%s/api/finished", Constants.data_port));
                connection = (HttpURLConnection) url.openConnection();
    			connection.setRequestMethod("POST");
    			connection.setConnectTimeout(60000);
    			connection.setDoOutput(true);
    			connection.setReadTimeout(60000);
    			connection.setRequestProperty("accept", "*/*");
    			connection.setRequestProperty("Content-Type", ContentType.APPLICATION_FORM_URLENCODED.toString());
    			connection.connect();
        	}catch (Exception e) {
				e.printStackTrace();
			}
        }).start();

        new Thread(() -> {//end the program in case hung the thread.
            try {
                Thread.sleep(30000);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if(!sent) {
            	sendResultEmpty();
            }
        }).start();
    }


    public synchronized void addEndFilterNum() {
    	endFilterNum++;
    	if (endFilterNum >= 2) {
            sendResult();
        }
    }

    public synchronized void calcCheckSum(ErrorTrace errorTracePacket) {
        ErrorTrace p = map.get(errorTracePacket);
        if (p == null) {
            map.put(errorTracePacket, errorTracePacket);
            return;
        }
        if (p.isHandle || p.getWho() == errorTracePacket.getWho()) return;
        p.isHandle = true;
        mergeAndMd5(p, errorTracePacket);//Merge sort, and count the checksum and put the final request.
    }

    private void mergeAndMd5(ErrorTrace p1, ErrorTrace p2) {
        byte bs1[] = p1.getBytes();
        int len1 = p1.getLen();
        byte bs2[] = p2.getBytes();
        int len2 = p2.getLen();
        int i = ErrorTrace.POS_DATA + 16, j = ErrorTrace.POS_DATA + 16;//16 means traceId length.

        int offset = 20;
        int traceIdLen;

        //traceId posible length 14，15，16
        if (bs1[ErrorTrace.POS_DATA + 13] == '|') traceIdLen = 13;
        else if (bs1[ErrorTrace.POS_DATA + 14] == '|') traceIdLen = 14;
        else if (bs1[ErrorTrace.POS_DATA + 15] == '|') traceIdLen = 15;
        else traceIdLen = 16;

        md5.reset();
        int dataLen1 = 0, dataLen2 = 0;
        while (i < len1 || j < len2) {
            try {
                if (i < len1) dataLen1 = ((bs1[i] & 0XFF) << 8) + (bs1[i + 1] & 0XFF);
                if (j < len2) dataLen2 = ((bs2[j] & 0XFF) << 8) + (bs2[j + 1] & 0XFF);
                if (j >= len2) {
                    md5.update(bs1, i + 2, dataLen1);
                    i += dataLen1 + 2;
                } else if (i >= len1) {
                    md5.update(bs2, j + 2, dataLen2);
                    j += dataLen2 + 2;
                } else if (compareBytes(bs1, i + offset, bs2, j + offset, 16) < 0) {
                    md5.update(bs1, i + 2, dataLen1);
                    i += dataLen1 + 2;
                } else {
                    md5.update(bs2, j + 2, dataLen2);
                    j += dataLen2 + 2;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        request[requestLen++] = '"';
        System.arraycopy(bs1, ErrorTrace.POS_DATA, request, requestLen, traceIdLen);
        requestLen += traceIdLen;
        request[requestLen++] = '"';
        request[requestLen++] = ':';
        request[requestLen++] = '"';
        md5.digest(request, requestLen);
        requestLen += 32;
        request[requestLen++] = '"';
        request[requestLen++] = ',';
    }

    private int compareBytes(byte bs1[], int s1, byte bs2[], int s2, int len) {
        try {
            for (int i = 0; i < 16; i++) {
                if (bs1[s1 + i] == bs2[s2 + i]) continue;
                return bs1[s1 + i] - bs2[s2 + i];
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    public synchronized void sendPacket(ErrorTrace errorTracePacket) {
    	
    	if(errorTracePacket.getWho() == Constants.Client0) {
    		serverSend.sendError1(errorTracePacket);
    	}else {
    		serverSend.sendError0(errorTracePacket);
    	}
    }
    
    
    
    private void sendResult() {
        try {
        	sent= true;
            request[requestLen - 1] = '}';
            byte[] bs = new byte[requestLen];
            System.arraycopy(request, 0, bs, 0, requestLen);
            String req = new String(bs);
            //log.debug(req);
			OutputStream os = connection.getOutputStream();
			os.write(bs);
			os.close();
			InputStream inStream=connection.getInputStream();
			inStream.close();
			connection.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    private void sendResultEmpty() {
        try {
        	URL url = new URL(String.format("http://localhost:%s/api/finished", Constants.data_port));
        	connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setConnectTimeout(60000);
			connection.setDoOutput(true);
			connection.setReadTimeout(60000);
			connection.setRequestProperty("accept", "*/*");
			connection.setRequestProperty("Content-Type", ContentType.APPLICATION_FORM_URLENCODED.toString());
            String req = "result={\"\":\"\"}";
            //log.debug(req);
			OutputStream os = connection.getOutputStream();
			os.write(req.getBytes());
			os.close();
			InputStream inStream=connection.getInputStream();
			inStream.close();
			connection.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


	@Override
	public void afterPropertiesSet() throws Exception {
		serverSend = new ServerSend();
	}


}
