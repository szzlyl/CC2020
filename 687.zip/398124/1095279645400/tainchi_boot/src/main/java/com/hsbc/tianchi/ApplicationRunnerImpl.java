package com.hsbc.tianchi;





import com.hsbc.tianchi.bean.DataHandler;
import com.hsbc.tianchi.bean.Filter;
import com.hsbc.tianchi.common.Constants;
import com.hsbc.tianchi.common.Utils;
import com.hsbc.tianchi.service.BackEndService;
import com.hsbc.tianchi.service.ClientService;
import com.hsbc.tianchi.socket.ClientReceive;
import com.hsbc.tianchi.socket.ServerReceive;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import static com.hsbc.tianchi.common.Constants.*;



@Component
@Slf4j
public class ApplicationRunnerImpl implements ApplicationRunner{
	
	@Value("${server.port}")
	Integer port;
	
	@Autowired(required = false)
	ClientService clientService;
	
	@Autowired(required = false)
	BackEndService backEndService;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		listen_port = port;
		
		if (listen_port == 8002) {
            service_name = Backend;
            new ServerReceive(backEndService).start();
        } else {
        	if (listen_port == 8001) {service_name = Client1;};
        	while(!Utils.allhealth()) {
    			Utils.sleep(20);
    		}
    		Constants.ALL_HEALTH = true;
        	filter = new Filter();
        	ClientReceive socketListener = new ClientReceive(filter);
            new Thread(() -> DataHandler.handleData()).start();
            new Thread(() -> DataHandler.handleErrorPacket()).start();
            new Thread(() -> {clientService.start();}).start();
            socketListener.start();
            filter.start();
        }
		
		
	}

	

}
