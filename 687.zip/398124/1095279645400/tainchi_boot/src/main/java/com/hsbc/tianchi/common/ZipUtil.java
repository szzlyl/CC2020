package com.hsbc.tianchi.common;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

public class ZipUtil {
	
	public static byte[] gZip(byte[] data) {
		  byte[] b = null;
		  try {
		   ByteArrayOutputStream bos = new ByteArrayOutputStream();
		   GZIPOutputStream gzip = new GZIPOutputStream(bos);
		   gzip.write(data);
		   gzip.finish();
		   gzip.close();
		   b = bos.toByteArray();
		   bos.close();
		  } catch (Exception ex) {
		   ex.printStackTrace();
		  }
		  return b;
		 }

		 /***
		  * 解压GZip
		  * 
		  * @param data
		  * @return
		  */
		 public static byte[] unGZip(byte[] data) {
		  byte[] b = null;
		  try {
		   ByteArrayInputStream bis = new ByteArrayInputStream(data);
		   GZIPInputStream gzip = new GZIPInputStream(bis);
		   byte[] buf = new byte[1024];
		   int num = -1;
		   ByteArrayOutputStream baos = new ByteArrayOutputStream();
		   while ((num = gzip.read(buf, 0, buf.length)) != -1) {
		    baos.write(buf, 0, num);
		   }
		   b = baos.toByteArray();
		   baos.flush();
		   baos.close();
		   gzip.close();
		   bis.close();
		  } catch (Exception ex) {
		   ex.printStackTrace();
		  }
		  return b;
		 }

    // 压缩
    public static String compress(String str) throws IOException {
        if (str == null || str.length() == 0) {
            return str;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        GZIPOutputStream gzip = new GZIPOutputStream(out);
        gzip.write(str.getBytes());
        gzip.close();
        return out.toString("ISO-8859-1");
    }

    // 解压缩
    public static String uncompress(String str) throws IOException {
        if (str == null || str.length() == 0) {
            return str;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayInputStream in = new ByteArrayInputStream(str.getBytes("ISO-8859-1"));
        GZIPInputStream gunzip = new GZIPInputStream(in);
        byte[] buffer = new byte[256];
        int n;
        while ((n = gunzip.read(buffer)) >= 0) {
            out.write(buffer, 0, n);
        }
        // toString()使用平台默认编码，也可以显式的指定如toString("GBK")
        return out.toString();
    }

    // 测试方法
    public static void main(String[] args) throws IOException {

        //测试字符串
        String str="1d37a8b17db8568b|1589285985482007|3d1e7e1147c1895d|1d37a8b17db8568b|1259|InventoryCenter|/api/traces|192.168.0.2|http.status_code=200&http.url=http://tracing.console.aliyun.com/getOrder&component=java-web-servlet&span.kind=server&http.method=GET\r\n"
        		+ "1d37a8b17db8568b|1589285985482015|4ee98bd6d34500b3|3d1e7e1147c1895d|1251|PromotionCenter|getAppConfig|192.168.0.4|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://localhost:9004/getPromotion?id=1&peer.port=9004&http.method=GET\r\n"
        		+ "1d37a8b17db8568b|1589285985482023|2a7a4e061ee023c3|3d1e7e1147c1895d|1243|OrderCenter|sls.getLogs|192.168.0.6|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://tracing.console.aliyun.com/getInventory?id=1&peer.port=9005&http.method=GET\r\n"
        		+ "1d37a8b17db8568b|1589285985482031|243a3d3ca6115a4d|3d1e7e1147c1895d|1235|InventoryCenter|checkAndRefresh|192.168.0.8|http.status_code=200&component=java-spring-rest-template&span.kind=client&peer.port=9005&http.method=GET\r\n"
        		+ "1d37a8b17db8568b|1589285985482039|58f8a2c6b229e0c9|3d1e7e1147c1895d|1227|PromotionCenter|DoGetDatas|192.168.0.10|db.instance=db&component=java-jdbc&db.type=h2&span.kind=client&__sql_id=mb7w54&peer.address=localhost:8082\r\n"
        		+ "1d37a8b17db8568b|1589285985482047|7f290c7b476fba31|3d1e7e1147c1895d|1219|OrderCenter|noToName2|192.168.0.12|db.instance=db&component=java-jdbc&db.type=h2&span.kind=client&__sql_id=1x7lx2l&peer.address=localhost:8082\r\n"
        		+ "1d37a8b17db8568b|1589285985482055|56bd30e2ec84b236|3d1e7e1147c1895d|1211|InventoryCenter|Register/doEndpointRegister|192.168.0.14|db.instance=db&component=java-jdbc&db.type=h2&span.kind=client&__sql_id=1af9zkk&peer.address=localhost:8082\r\n"
        		+ "1d37a8b17db8568b|1589285985482063|5ac24275abbc87a6|1d37a8b17db8568b|1203|PromotionCenter|/api/v2/spans|192.168.0.16|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://tracing.console.aliyun.com/getOrder?id=1&peer.port=9002&http.method=GET\r\n"
        		+ "1d37a8b17db8568b|1589285985482071|23a19dcb2768db5f|5ac24275abbc87a6|1195|OrderCenter|db.ArmsAppDao.getAppListByUserIdAllRegion(..)|192.168.0.18|http.status_code=200&component=java-web-servlet&span.kind=server&sampler.type=const&sampler.param=1&http.url=http://localhost:8081/buyItem&http.method=GET\r\n"
        		+ "1093e0c1e05431|1589285985482078|1093e0c1e05431|0|1177|InventoryCenter|/nginx_status|192.168.0.20|biz=fxtius&sampler.type=const&sampler.param=1\r\n"
        		+ "1093e0c1e05431|1589285985482082|2254233fa7bd7c7a|4d3d95fe822bc12a|1179|PromotionCenter|db.AlertDao.listByTitleAndUserId(..)|192.168.0.22|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://tracing.console.aliyun.com/getOrder?id=5&peer.port=9002&http.method=GET\r\n"
        		+ "1093e0c1e05431|1589285985482086|28528b35a0051359|4d3d95fe822bc12a|1181|OrderCenter|DoQueryStatData|192.168.0.24|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://localhost:9001/getItem?id=5&peer.port=9001&http.method=GET\r\n"
        		+ "1093e0c1e05431|1589285985482090|41aef8920d51bed9|4d3d95fe822bc12a|1183|InventoryCenter|sls.getHistograms|192.168.0.26|http.status_code=200&component=java-spring-rest-template&span.kind=client&http.url=http://localhost:9003/getAddress?id=5&peer.port=9003&http.method=GET\r\n"
        		+ "1093e0c1e05431|1589285985482094|546fa046a3f8d30e|4d3d95fe822bc12a|1185|PromotionCenter|db.ResourceConfigDao.getByParentkeyUserId(..)|192.168.0.28|db.instance=db&component=java-jdbc&db.type=h2&span.kind=client&__sql_id=bx9jth&peer.address=localhost:8082\r\n"
        		+ "1093e0c1e05431|1589285985482098|7dd325f3072de7db|4d3d95fe822bc12a|1187|";
        byte[] b = str.getBytes();
        System.out.println("原长度："+b.length);

        System.out.println("压缩后："+ZipUtil.gZip(b).length);
       // System.out.println("解压缩："+ZipUtil.uncompress(ZipUtil.compress(str)));
    }
    
    
    
}
