package com.hsbc.tianchi.common;

import org.springframework.http.ResponseEntity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Utils {

	public static void sleep(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public static boolean allhealth() {
		Integer[] ports = new Integer[] { 8000, 8001, 8002 };
		if (Constants.ALL_HEALTH == false) {
			try {
				for (Integer port : ports) {
					ResponseEntity<String> response = Constants.REST
							.getForEntity("http://localhost:" + port + "/health", String.class);
					// log.debug(response.getStatusCode() + ":" +port);
				}
				log.debug("all health");
				Constants.ALL_HEALTH = true;
				return true;
			} catch (Exception e) {}
		}
		// log.debug("health check again");
		return Constants.ALL_HEALTH;
	}
	
	
	 
	
	private static String getPath(int port) {
		if (Constants.Client0 == Constants.service_name) {
			return "http://localhost:" + port + "/trace1.data";
		} else if (Constants.Client1 == Constants.service_name) {
			return "http://localhost:" + port + "/trace2.data";
		} else {
			return null;
		}
	}
}
