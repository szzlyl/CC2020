package com.hsbc.tianchi.bean;

import static com.hsbc.tianchi.common.Constants.filter;
import static com.hsbc.tianchi.common.Constants.service_name;
import static com.hsbc.tianchi.common.Constants.total_page_count;

/**
 * Cache Window
 */
public class DataHandler {
    private static final int len = 16;
    private static final Cache[] emptyCaches = new Cache[len]; // read data from raw file
    private static final Cache[] fullCaches = new Cache[len]; // indexing and find error
    private static final Cache[] handleCaches = new Cache[len]; // for searching by id
    public static final ErrorTrace errors[] = new ErrorTrace[1024];
    public static int errorIndex = 0;
    public static int totalError = 10000;
    public static final int pageErrorIndex[] = new int[1000];
    
    static ErrorTrace errorTracePacket = new ErrorTrace(64, service_name, ErrorTrace.TYPE_MULTI_POSITION);
    static Position[] positions = new Position[500];
    static int pLen = 0;

    static {
        // init
        for (int i = 0; i < emptyCaches.length; i++) {
            emptyCaches[i] = new Cache();
        }
    }

    public static void put(ErrorTrace errorTrace, int pageIndex) {
        synchronized (errors) {
            errors[errorIndex] = errorTrace;
            pageErrorIndex[errorIndex++] = pageIndex;
            errors.notify();
        }
    }

    public static ErrorTrace get(int n) {
        synchronized (errors) {
            if (errors[n] == null) {
                try {
                    errors.wait();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return errors[n];
    }

    public static Cache getEmptyCache(int i) {
        synchronized (emptyCaches) {
            Cache page = emptyCaches[i % len];
            while (page == null) {
                try {
                    emptyCaches.wait();
                    page = emptyCaches[i % len]; // find page buckets
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            page.pageIndex = i;
            return page;
        }
    }

    public static void moveHandleToEmpty(int i) {
        synchronized (emptyCaches) {
            if (i < 0) return;
            try {
                emptyCaches[i % len] = handleCaches[i % len];
                handleCaches[i % len] = null;
                emptyCaches.notify();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static Cache getFullCache(int i) {
        synchronized (fullCaches) {
            Cache page = fullCaches[i % len];
            while (page == null) {
                try {
                    fullCaches.wait();
                    page = fullCaches[i % len];
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return page;
        }
    }

    public static void moveEmptyToFull(int i) {
        synchronized (fullCaches) {
            try {
                fullCaches[i % len] = emptyCaches[i % len];
                emptyCaches[i % len] = null;
                fullCaches.notify();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static Cache getHandleCache(int i) {
        synchronized (handleCaches) {
            if (i >= total_page_count || i < 0) return null;
            Cache page = handleCaches[i % len];
            while (page == null) {
                try {
                    handleCaches.wait();
                    page = handleCaches[i % len];
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return page;
        }
    }

    public static void moveFullToHandle(int i) {
        synchronized (handleCaches) {
            try {
                handleCaches[i % len] = fullCaches[i % len];
                fullCaches[i % len] = null;
                handleCaches.notify();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * create index for traces->locate error trace->sent error trace.
     */
    public static void handleData() {
        for (int i = 0; i < total_page_count; i++) {
            Cache page = DataHandler.getFullCache(i);
            page.createIndexAndFindError();
            moveFullToHandle(i);//indicate which page is handled.
            if (i == total_page_count - 1) {// last page handle
                filter.sendPacket(page.error);
                put(page.error, i);
            }
        }
        totalError = errorIndex;
    }

    public static void handleErrorPacket() {
        int pos = 0;
        for (int i = 0; i < totalError; i++) {
            ErrorTrace errPkt = get(i);
            int start = i == 0 ? 0 : (pageErrorIndex[i - 1] == 0 ? 0 : pageErrorIndex[i - 1] - 1);
            int end = pageErrorIndex[i] + 2;
            handleErrorPacket(start, end, errPkt);
            for (; pos < start; pos++) {
                moveHandleToEmpty(pos);
            }
        }
        ErrorTrace endErrorTracePacket = new ErrorTrace(1, service_name, ErrorTrace.TYPE_END);
        filter.sendPacket(endErrorTracePacket);
    }

    public static void handleErrorPacket(int start, int end, ErrorTrace errorTracePacket) {
        long startTime = System.currentTimeMillis();
        handelOnePacket(start, end, errorTracePacket);
        //handle client2 sent traceId
        errorTracePacket = filter.getRemoteErrorPacket();
        handelOnePacket(start, end, errorTracePacket);
    }

    public static void handelOnePacket(int start, int end, ErrorTrace errorTracePacket) {
        byte[] bs = errorTracePacket.getBytes();
        int len = errorTracePacket.getLen();
        for (int i = ErrorTrace.POS_DATA; i < len; i += 16) {
            byte traceId[] = new byte[16];
            System.arraycopy(bs, i, traceId, 0, 16);
            ErrorTrace logsErrorTracePacket = selectByTraceId(start, end, traceId);
            filter.sendPacket(logsErrorTracePacket);
        }
    }

    public static ErrorTrace selectByTraceId(int start, int end, byte traceId[]) {
        errorTracePacket.reset(service_name, ErrorTrace.TYPE_MULTI_POSITION);
        errorTracePacket.writeCache(0);
        //record traceId, traceId possible 14,15,16
        errorTracePacket.write(traceId, 0, traceId.length);
        pLen = 0;
        for (int i = start; i < end; i++) {
            Cache page = getHandleCache(i);
            if (page == null) break;
            int len = page.selectByTraceId(traceId, positions, pLen);
            pLen += len;
        }

        for (int i = 1; i < pLen; i++) {
            for (int j = i; j > 0; j--) {
                if (compare(positions[j], positions[j - 1]) < 0) {
                    Position tmp = positions[j - 1];
                    positions[j - 1] = positions[j];
                    positions[j] = tmp;
                }
            }
        }

        for (int i = 0; i < pLen; i++) {//encapsulation traceId as Packet
            Position pos = positions[i];
            errorTracePacket.writeWithDataLen(pos.d, pos.s, pos.l);
            positions[i] = null;
        }
        return errorTracePacket;
    }

    /**
     * sorting compare unit.
     * @param l1
     * @param l2
     * @return
     */
    public static int compare(Position l1, Position l2) {
        for (int i = 20; i < 35; i++) {
            if (l1.d[l1.s + i] == l2.d[l2.s + i]) continue;
            return l1.d[l1.s + i] - l2.d[l2.s + i];
        }
        return 0;
    }
}
