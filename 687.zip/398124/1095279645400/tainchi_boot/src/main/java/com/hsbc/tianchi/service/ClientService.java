package com.hsbc.tianchi.service;

import com.hsbc.tianchi.bean.Cache;
import com.hsbc.tianchi.bean.DataHandler;
import com.hsbc.tianchi.bean.ErrorTrace;
import com.hsbc.tianchi.common.Utils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.Proxy;
import java.net.URL;

import static com.hsbc.tianchi.common.Constants.*;

@Service
@Slf4j
public class ClientService {


    private static long startTime;
    private static byte[] tail = new byte[10240];//tail data as split thread handle.
    private static int tailLen = 0;//Tail data length.
    private static int pageIndex;//page location
    private final static byte lineBreak = '\n';// int 10

    public void start() {
        try {
            dataProcess();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void dataProcess() throws Exception {
        startTime = System.currentTimeMillis();
        while (data_port == 0) {
            Utils.sleep(3);
        }

        String path = "http://127.0.0.1:" + data_port + (listen_port == 8000 ? "/trace1.data" : "/trace2.data");
        System.out.println(path);
        URL url = new URL(path);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection(Proxy.NO_PROXY);

        try (InputStream in = conn.getInputStream();) {

            int n, len;
            byte[] data;
            Cache cache;
            do {
                long l = System.currentTimeMillis();
                cache = DataHandler.getEmptyCache(pageIndex);
                cache.clear();
                cache.pageIndex = pageIndex;
                //log.debug("read " + pageIndex);
                data = cache.data;//copy the previous tail data as start data.
                System.arraycopy(tail, 0, data, 0, tailLen);
                len = tailLen;

                //read each cache data
                while ((n = in.read(data, len, Cache.SIZE - len)) != -1) {
                    len += n;
                    if (len == Cache.SIZE) break;
                }

                //locate the break line.
                for (tailLen = 0; tailLen < 10240; tailLen++) {
                    if (data[len - 1 - tailLen] == lineBreak) {//
                        System.arraycopy(data, len - tailLen, tail, 0, tailLen);
                        break;
                    }
                }

                DataHandler.moveEmptyToFull(pageIndex);
                cache.len = len - tailLen;//cache page length.

                pageIndex++;

            } while (n != -1);
            total_page_count = pageIndex;
            ErrorTrace readEndErrorTracePacket = new ErrorTrace(1, service_name, ErrorTrace.TYPE_READ_END);
            readEndErrorTracePacket.writeCache(pageIndex);
            filter.sendPacket(readEndErrorTracePacket);
        } finally {
            conn.disconnect();
        }

        log.debug("read data total time" + (System.currentTimeMillis() - startTime));

    }
}
